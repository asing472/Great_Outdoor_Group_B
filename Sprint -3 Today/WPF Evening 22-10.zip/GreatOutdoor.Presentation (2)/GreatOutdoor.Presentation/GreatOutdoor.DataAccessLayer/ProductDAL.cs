﻿using System;
using System.Collections.Generic;
using System.Linq;
using Capgemini.GreatOutdoor.Entities;
using Capgemini.GreatOutdoor.Helpers;
using Capgemini.GreatOutdoor.Contracts.DALContracts;
using System.Data;
using System.Data.SqlClient;

namespace Capgemini.GreatOutdoor.DataAccessLayer
{

    /// <summary>
    /// Contains data access layer methods for inserting, updating or deleting products from Products collection.
    /// </summary>
    public class ProductDAL : ProductDALBase, IDisposable
    {
        SqlConnection sqlConn = new SqlConnection(Properties.Settings.Default.dbCon);
        /// <summary>
        /// Gets all the products from the collection.
        /// </summary>
        /// <returns>Returns the list of all products</returns>
        public override List<Product> GetAllProductsDAL()
        {

            List<Product> tempProductList = new List<Product>();

            try
            {
                sqlConn.Open();
                string query = "TeamB.GetAllProducts";
                DataSet dtSet = new DataSet();
                SqlDataAdapter sqlAdp = new SqlDataAdapter(query, sqlConn);
                SqlCommandBuilder sqlBld = new SqlCommandBuilder(sqlAdp);
                sqlAdp.Fill(dtSet);
                for (int i = 0; i < dtSet.Tables[0].Rows.Count; i++)
                {
                    Product tempProduct = new Product();
                    tempProduct.ProductID = (Guid)(dtSet.Tables[0].Rows[i]["ProductID"]);
                    tempProduct.ProductName = Convert.ToString(dtSet.Tables[0].Rows[i]["ProductName"]);
                    tempProduct.ProductNumber = Convert.ToInt32(dtSet.Tables[0].Rows[i]["ProductNumber"]);
                    tempProduct.ProductColor = Convert.ToString(dtSet.Tables[0].Rows[i]["ProductColor"]);
                    tempProduct.ProductSize = Convert.ToString(dtSet.Tables[0].Rows[i]["ProductSize"]);
                    tempProduct.ProductMaterial = Convert.ToString(dtSet.Tables[0].Rows[i]["ProductMaterial"]);
                    tempProduct.ProductPrice = Convert.ToDouble(dtSet.Tables[0].Rows[i]["ProductPrice"]);
                    tempProduct.CreationDateTime = Convert.ToDateTime(dtSet.Tables[0].Rows[i]["CreationDateTime"]);
                    tempProduct.LastModifiedDateTime = Convert.ToDateTime(dtSet.Tables[0].Rows[i]["LastModifiedDateTime"]);
                    string category = Convert.ToString(dtSet.Tables[0].Rows[i]["ProductCategory"]);
                    if (category == "Camping Equipment")
                    {
                        tempProduct.productCategory = Category.CampingEquipment;
                    }
                    else if (category == "Golf Equipment")
                    {
                        tempProduct.productCategory = Category.GolfEquipment;
                    }
                    else if (category == "Mountaineering Equipment")
                    {
                        tempProduct.productCategory = Category.MountaineeringEquipment;
                    }
                    else if (category == "Outdoor Protection")
                    {
                        tempProduct.productCategory = Category.OutdoorProtection;
                    }
                    else if (category == "Personal Accessories")
                    {
                        tempProduct.productCategory = Category.PersonalAccessories;
                    }
                    else
                    {
                        tempProduct.productCategory = Category.CampingEquipment;
                    }

                    tempProductList.Add(tempProduct);
                }
            }
            catch (Exception)
            {
                throw;
            }

            sqlConn.Close();

            return tempProductList;
        }

        /// <summary>
        /// Gets the product based on the product ID
        /// </summary>
        /// <param name="productID">Represents the product number to be searched</param>
        /// <returns>Returns the product with the given product ID</returns>
        public override Product GetProductByProductIDDAL(Guid productID)
        {
            Product matchingProduct = new Product();
            try
            {
                //creating object of sql Command
                string query = "TeamB.GetProductByProductID";
                SqlCommand sqlcmd = new SqlCommand(query, sqlConn);
                sqlcmd.CommandType = CommandType.StoredProcedure;
                SqlParameter sqlParameter = new SqlParameter("@ProductID", productID);
                sqlParameter.DbType = DbType.Guid;
                sqlcmd.Parameters.Add(sqlParameter);

                sqlConn.Open();

                //creating object of sql data reader
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlcmd);
                DataSet ds = new DataSet();
                sqlDataAdapter.Fill(ds);

                //loading into object
                if (ds.Tables[0].Rows.Count > 0)
                {
                    matchingProduct.ProductID = (Guid)ds.Tables[0].Rows[0]["ProductID"];
                    matchingProduct.ProductName = Convert.ToString(ds.Tables[0].Rows[0]["ProductName"]);
                    matchingProduct.ProductNumber = Convert.ToInt32(ds.Tables[0].Rows[0]["ProductNumber"]);
                    matchingProduct.ProductColor = Convert.ToString(ds.Tables[0].Rows[0]["ProductColor"]);
                    matchingProduct.ProductSize = Convert.ToString(ds.Tables[0].Rows[0]["ProductSize"]);
                    matchingProduct.ProductMaterial = Convert.ToString(ds.Tables[0].Rows[0]["ProductMaterial"]);
                    matchingProduct.ProductPrice = Convert.ToDouble(ds.Tables[0].Rows[0]["ProductPrice"]);
                    matchingProduct.CreationDateTime = Convert.ToDateTime(ds.Tables[0].Rows[0]["CreationDateTime"]);
                    matchingProduct.LastModifiedDateTime = Convert.ToDateTime(ds.Tables[0].Rows[0]["LastModifiedDateTime"]);
                    string category = Convert.ToString(ds.Tables[0].Rows[0]["ProductCategory"]);
                    if (category == "Camping Equipment")
                    {
                        matchingProduct.productCategory = Category.CampingEquipment;
                    }
                    else if (category == "Golf Equipment")
                    {
                        matchingProduct.productCategory = Category.GolfEquipment;
                    }
                    else if (category == "Mountaineering Equipment")
                    {
                        matchingProduct.productCategory = Category.MountaineeringEquipment;
                    }
                    else if (category == "Outdoor Protection")
                    {
                        matchingProduct.productCategory = Category.OutdoorProtection;
                    }
                    else if (category == "Personal Accessories")
                    {
                        matchingProduct.productCategory = Category.PersonalAccessories;
                    }
                    else
                    {
                        matchingProduct.productCategory = Category.CampingEquipment;
                    }
                }
                sqlConn.Close();
            }
            catch (Exception)
            {
                throw;
            }

            return matchingProduct;
        }

        /// <summary>
        /// Gets the product based on the product ID
        /// </summary>
        /// <param name="productNumber">Represents the product number to be searched</param> 
        /// <returns>Returns the product with the given product ID</returns>
        public override Product GetProductByProductNumberDAL(int productNumber)
        {
            Product matchingProduct = new Product();
            try
            {
                //creating object of sql Command
                string query = "TeamB.GetProductByProductNumber";
                SqlCommand sqlcmd = new SqlCommand(query, sqlConn);
                sqlcmd.CommandType = CommandType.StoredProcedure;
                SqlParameter sqlParameter = new SqlParameter("@ProductNumber", productNumber);
                sqlParameter.DbType = DbType.Int32;
                sqlcmd.Parameters.Add(sqlParameter);

                sqlConn.Open();

                //creating object of sql data reader
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlcmd);
                DataSet ds = new DataSet();
                sqlDataAdapter.Fill(ds);

                //loading into object
                if (ds.Tables[0].Rows.Count > 0)
                {
                    matchingProduct.ProductID = (Guid)ds.Tables[0].Rows[0]["ProductID"];
                    matchingProduct.ProductName = Convert.ToString(ds.Tables[0].Rows[0]["ProductName"]);
                    matchingProduct.ProductNumber = Convert.ToInt32(ds.Tables[0].Rows[0]["ProductNumber"]);
                    matchingProduct.ProductColor = Convert.ToString(ds.Tables[0].Rows[0]["ProductColor"]);
                    matchingProduct.ProductSize = Convert.ToString(ds.Tables[0].Rows[0]["ProductSize"]);
                    matchingProduct.ProductMaterial = Convert.ToString(ds.Tables[0].Rows[0]["ProductMaterial"]);
                    matchingProduct.ProductPrice = Convert.ToDouble(ds.Tables[0].Rows[0]["ProductPrice"]);
                    matchingProduct.CreationDateTime = Convert.ToDateTime(ds.Tables[0].Rows[0]["CreationDateTime"]);
                    matchingProduct.LastModifiedDateTime = Convert.ToDateTime(ds.Tables[0].Rows[0]["LastModifiedDateTime"]);
                    string category = Convert.ToString(ds.Tables[0].Rows[0]["ProductCategory"]);
                    if (category == "Camping Equipment")
                    {
                        matchingProduct.productCategory = Category.CampingEquipment;
                    }
                    else if (category == "Golf Equipment")
                    {
                        matchingProduct.productCategory = Category.GolfEquipment;
                    }
                    else if (category == "Mountaineering Equipment")
                    {
                        matchingProduct.productCategory = Category.MountaineeringEquipment;
                    }
                    else if (category == "Outdoor Protection")
                    {
                        matchingProduct.productCategory = Category.OutdoorProtection;
                    }
                    else if (category == "Personal Accessories")
                    {
                        matchingProduct.productCategory = Category.PersonalAccessories;
                    }
                    else
                    {
                        matchingProduct.productCategory = Category.CampingEquipment;
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return matchingProduct;
        }

        /// <summary>
        /// Gets all the products of a particular product category
        /// </summary>
        /// <param name="productCategory">Represents the product category whose products are to be fetched</param>
        /// <returns>The list of products of the given product category</returns>
        public override List<Product> GetProductsByProductCategoryDAL(Category givenCategory)
        {
            List<Product> tempProductList = new List<Product>();

            try
            {

                string query = "TeamB.GetProductsByProductCategory";
                SqlCommand sqlcmd = new SqlCommand(query, sqlConn);
                sqlcmd.CommandType = CommandType.StoredProcedure;
                string category;
                if (givenCategory == Category.CampingEquipment)
                {
                    category = "Camping Equipment";
                }
                else if (givenCategory == Category.GolfEquipment)
                {
                    category = "Golf Equipment";
                }
                else if (givenCategory == Category.MountaineeringEquipment)
                {
                    category = "Mountaineering Equipment";
                }
                else if (givenCategory == Category.OutdoorProtection)
                {
                    category = "Outdoor Protection";
                }
                else if (givenCategory == Category.PersonalAccessories)
                {
                    category = "Personal Accessories";
                }
                else
                {
                    category = "Camping Equipment";
                }
                SqlParameter sqlParameter = new SqlParameter("@ProductCategory", category);
                sqlParameter.DbType = DbType.String;
                sqlcmd.Parameters.Add(sqlParameter);
                sqlConn.Open();

                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlcmd);
                DataSet dtSet = new DataSet();
                sqlDataAdapter.Fill(dtSet);
                for (int i = 0; i < dtSet.Tables[0].Rows.Count; i++)
                {
                    Product tempProduct = new Product();
                    tempProduct.ProductID = (Guid)(dtSet.Tables[0].Rows[i]["ProductID"]);
                    tempProduct.ProductName = Convert.ToString(dtSet.Tables[0].Rows[i]["ProductName"]);
                    tempProduct.ProductNumber = Convert.ToInt32(dtSet.Tables[0].Rows[i]["ProductNumber"]);
                    tempProduct.ProductColor = Convert.ToString(dtSet.Tables[0].Rows[i]["ProductColor"]);
                    tempProduct.ProductSize = Convert.ToString(dtSet.Tables[0].Rows[i]["ProductSize"]);
                    tempProduct.ProductMaterial = Convert.ToString(dtSet.Tables[0].Rows[i]["ProductMaterial"]);
                    tempProduct.ProductPrice = Convert.ToDouble(dtSet.Tables[0].Rows[i]["ProductPrice"]);
                    tempProduct.CreationDateTime = Convert.ToDateTime(dtSet.Tables[0].Rows[i]["CreationDateTime"]);
                    tempProduct.LastModifiedDateTime = Convert.ToDateTime(dtSet.Tables[0].Rows[i]["LastModifiedDateTime"]);
                    string receivedcategory = Convert.ToString(dtSet.Tables[0].Rows[i]["ProductCategory"]);
                    if (receivedcategory == "Camping Equipment")
                    {
                        tempProduct.productCategory = Category.CampingEquipment;
                    }
                    else if (receivedcategory == "Golf Equipment")
                    {
                        tempProduct.productCategory = Category.GolfEquipment;
                    }
                    else if (receivedcategory == "Mountaineering Equipment")
                    {
                        tempProduct.productCategory = Category.MountaineeringEquipment;
                    }
                    else if (receivedcategory == "Outdoor Protection")
                    {
                        tempProduct.productCategory = Category.OutdoorProtection;
                    }
                    else if (receivedcategory == "Personal Accessories")
                    {
                        tempProduct.productCategory = Category.PersonalAccessories;
                    }
                    else
                    {
                        tempProduct.productCategory = Category.CampingEquipment;
                    }

                    tempProductList.Add(tempProduct);
                }
            }
            catch (Exception)
            {
                throw;
            }

            return tempProductList;

        }

        /// <summary>
        /// Gets the list of all products with a particular product name. 
        /// </summary>
        /// <param name="productName">Represents the product name by which products are to be fetched</param>
        /// <returns>The list of products of the given product name</returns>
        public override List<Product> GetProductsByProductNameDAL(string productName)
        {
            List<Product> tempProductList = new List<Product>();

            try
            {

                string query = "TeamB.GetProductsByProductName";
                SqlCommand sqlcmd = new SqlCommand(query, sqlConn);
                sqlcmd.CommandType = CommandType.StoredProcedure;
                SqlParameter sqlParameter = new SqlParameter("@ProductName", productName);
                sqlParameter.DbType = DbType.String;
                sqlcmd.Parameters.Add(sqlParameter);
                sqlConn.Open();

                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlcmd);
                DataSet dtSet = new DataSet();
                sqlDataAdapter.Fill(dtSet);
                for (int i = 0; i < dtSet.Tables[0].Rows.Count; i++)
                {
                    Product tempProduct = new Product();
                    tempProduct.ProductID = (Guid)(dtSet.Tables[0].Rows[i]["ProductID"]);
                    tempProduct.ProductName = Convert.ToString(dtSet.Tables[0].Rows[i]["ProductName"]);
                    tempProduct.ProductNumber = Convert.ToInt32(dtSet.Tables[0].Rows[i]["ProductNumber"]);
                    tempProduct.ProductColor = Convert.ToString(dtSet.Tables[0].Rows[i]["ProductColor"]);
                    tempProduct.ProductSize = Convert.ToString(dtSet.Tables[0].Rows[i]["ProductSize"]);
                    tempProduct.ProductMaterial = Convert.ToString(dtSet.Tables[0].Rows[i]["ProductMaterial"]);
                    tempProduct.ProductPrice = Convert.ToDouble(dtSet.Tables[0].Rows[i]["ProductPrice"]);
                    tempProduct.CreationDateTime = Convert.ToDateTime(dtSet.Tables[0].Rows[i]["CreationDateTime"]);
                    tempProduct.LastModifiedDateTime = Convert.ToDateTime(dtSet.Tables[0].Rows[i]["LastModifiedDateTime"]);
                    string receivedcategory = Convert.ToString(dtSet.Tables[0].Rows[i]["ProductCategory"]);
                    if (receivedcategory == "Camping Equipment")
                    {
                        tempProduct.productCategory = Category.CampingEquipment;
                    }
                    else if (receivedcategory == "Golf Equipment")
                    {
                        tempProduct.productCategory = Category.GolfEquipment;
                    }
                    else if (receivedcategory == "Mountaineering Equipment")
                    {
                        tempProduct.productCategory = Category.MountaineeringEquipment;
                    }
                    else if (receivedcategory == "Outdoor Protection")
                    {
                        tempProduct.productCategory = Category.OutdoorProtection;
                    }
                    else if (receivedcategory == "Personal Accessories")
                    {
                        tempProduct.productCategory = Category.PersonalAccessories;
                    }
                    else
                    {
                        tempProduct.productCategory = Category.CampingEquipment;
                    }

                    tempProductList.Add(tempProduct);
                }
            }
            catch (Exception)
            {
                throw;
            }

            sqlConn.Close();

            return tempProductList;

        }

        /// <summary>
        /// Updates the description of the product
        /// </summary>
        /// <param name="updateProduct">Represents only the product description detail of the product</param>
        /// <returns>Returns whether the product description is updated</returns>
        public override bool UpdateProductDescriptionDAL(Product updateProduct)
        {
            bool descriptionUpdated = false;

            try
            {
                //creating object of sql Command
                string query = "TeamB.UpdateProductDescription";
                SqlCommand sqlcmd = new SqlCommand(query, sqlConn);
                sqlcmd.CommandType = CommandType.StoredProcedure;
                SqlParameter sqlParameter1 = new SqlParameter("@ProductID", updateProduct.ProductID);
                sqlParameter1.DbType = DbType.Guid;
                sqlcmd.Parameters.Add(sqlParameter1);
                SqlParameter sqlParameter2 = new SqlParameter("@ProductName", updateProduct.ProductName);
                sqlParameter2.DbType = DbType.String;
                sqlcmd.Parameters.Add(sqlParameter2);
                SqlParameter sqlParameter3 = new SqlParameter("@ProductNumber", updateProduct.ProductNumber);
                sqlParameter3.DbType = DbType.Int32;
                sqlcmd.Parameters.Add(sqlParameter3);
                string category;
                if (updateProduct.productCategory == Category.CampingEquipment)
                {
                    category = "Camping Equipment";
                }
                else if (updateProduct.productCategory == Category.GolfEquipment)
                {
                    category = "Golf Equipment";
                }
                else if (updateProduct.productCategory == Category.MountaineeringEquipment)
                {
                    category = "Mountaineering Equipment";
                }
                else if (updateProduct.productCategory == Category.OutdoorProtection)
                {
                    category = "Outdoor Protection";
                }
                else if (updateProduct.productCategory == Category.PersonalAccessories)
                {
                    category = "Personal Accessories";
                }
                else
                {
                    category = "Camping Equipment";
                }
                SqlParameter sqlParameter4 = new SqlParameter("@ProductCategory", category);
                sqlParameter4.DbType = DbType.String;
                sqlcmd.Parameters.Add(sqlParameter4);
                SqlParameter sqlParameter5 = new SqlParameter("@ProductColor", updateProduct.ProductColor);
                sqlParameter5.DbType = DbType.String;
                sqlcmd.Parameters.Add(sqlParameter5);
                SqlParameter sqlParameter6 = new SqlParameter("@ProductSize", updateProduct.ProductSize);
                sqlParameter6.DbType = DbType.String;
                sqlcmd.Parameters.Add(sqlParameter6);
                SqlParameter sqlParameter7 = new SqlParameter("@ProductMaterial", updateProduct.ProductMaterial);
                sqlParameter7.DbType = DbType.String;
                sqlcmd.Parameters.Add(sqlParameter7);
                SqlParameter sqlParameter8 = new SqlParameter("@ProductPrice", updateProduct.ProductPrice);
                sqlParameter8.DbType = DbType.Double;
                sqlcmd.Parameters.Add(sqlParameter8);


                //opening the sql connection
                sqlConn.Open();

                //executing the delete query
                sqlcmd.ExecuteNonQuery();

                //set the productdeleted to true if deleted
                descriptionUpdated = true;

                //close the sql database conbection
                sqlConn.Close();
            }
            catch (Exception)
            {
                throw;
            }

            return descriptionUpdated;

        }

        /// <summary>
        /// Adds a new product to the product list collection
        /// </summary>
        /// <param name="addProduct">Contains the product details to be added</param>
        /// <returns>Tells whether the new product is added</returns>
        public override bool AddProductDAL(Product addProduct)
        {
            bool productAdded = false;

            try
            {
                //creating object of sql Command
                sqlConn.Open();
                string query = "TeamB.AddProduct";
                SqlCommand sqlcmd = new SqlCommand(query, sqlConn);
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@ProductID", addProduct.ProductID).DbType = DbType.Guid;
                sqlcmd.Parameters.AddWithValue("@ProductName", addProduct.ProductName).DbType = DbType.String;
                string category;
                if (addProduct.productCategory == Category.CampingEquipment)
                {
                    category = "Camping Equipment";
                }
                else if (addProduct.productCategory == Category.GolfEquipment)
                {
                    category = "Golf Equipment";
                }
                else if (addProduct.productCategory == Category.MountaineeringEquipment)
                {
                    category = "Mountaineering Equipment";
                }
                else if (addProduct.productCategory == Category.OutdoorProtection)
                {
                    category = "Outdoor Protection";
                }
                else if (addProduct.productCategory == Category.PersonalAccessories)
                {
                    category = "Personal Accessories";
                }
                else
                {
                    category = "Camping Equipment";
                }
                sqlcmd.Parameters.AddWithValue("@ProductCategory", category).DbType = DbType.String;
                sqlcmd.Parameters.AddWithValue("@ProductColor", addProduct.ProductColor).DbType = DbType.String;
                sqlcmd.Parameters.AddWithValue("@ProductSize", addProduct.ProductSize).DbType = DbType.String;
                sqlcmd.Parameters.AddWithValue("@ProductMaterial", addProduct.ProductMaterial).DbType = DbType.String;
                sqlcmd.Parameters.AddWithValue("@ProductPrice", addProduct.ProductPrice).DbType = DbType.Double;


                //opening the sql connection


                //executing the delete query
                sqlcmd.ExecuteNonQuery();

                //set the productdeleted to true if deleted
                productAdded = true;

                //close the sql database conbection
                sqlConn.Close();
            }
            catch (Exception)
            {
                throw;
            }

            return productAdded;


        }

        /// <summary>
        /// Deletes Product based on ProductID
        /// </summary>
        /// <param name="productID">Represents the productID to be deleted</param>
        /// <returns>Tells whether the product is deleted</returns>
        public override bool DeleteProductDAL(Guid deleteProductID)
        {
            bool productDeleted = false;

            try
            {
                //creating object of sql Command
                string query = "TeamB.DeleteProduct";
                SqlCommand sqlcmd = new SqlCommand(query, sqlConn);
                sqlcmd.CommandType = CommandType.StoredProcedure;
                SqlParameter sqlParameter = new SqlParameter("@ProductID", deleteProductID);
                sqlParameter.DbType = DbType.Guid;
                sqlcmd.Parameters.Add(sqlParameter);

                //opening the sql connection
                sqlConn.Open();

                //executing the delete query
                sqlcmd.ExecuteNonQuery();

                //set the productdeleted to true if deleted
                productDeleted = true;

                //close the sql database conbection
                sqlConn.Close();
            }
            catch (Exception)
            {
                throw;
            }

            return productDeleted;



        }

        /// <summary>
        /// Updates the price of the product
        /// </summary>
        /// <param name="updateProduct">Represents only the product price detail of the product</param>
        /// <returns>Returns whether the product price is updated</returns>
        public override bool UpdateProductPriceDAL(Product updateProduct)
        {
            bool priceUpdated = false;

            try
            {
                //creating object of sql Command
                string query = "TeamB.UpdateProductDescription";
                SqlCommand sqlcmd = new SqlCommand(query, sqlConn);
                sqlcmd.CommandType = CommandType.StoredProcedure;
                SqlParameter sqlParameter1 = new SqlParameter("@ProductID", updateProduct.ProductID);
                sqlParameter1.DbType = DbType.Guid;
                sqlcmd.Parameters.Add(sqlParameter1);
                SqlParameter sqlParameter2 = new SqlParameter("@ProductName", updateProduct.ProductName);
                sqlParameter2.DbType = DbType.String;
                sqlcmd.Parameters.Add(sqlParameter2);
                SqlParameter sqlParameter3 = new SqlParameter("@ProductNumber", updateProduct.ProductNumber);
                sqlParameter3.DbType = DbType.Int32;
                sqlcmd.Parameters.Add(sqlParameter3);
                string category;
                if (updateProduct.productCategory == Category.CampingEquipment)
                {
                    category = "Camping Equipment";
                }
                else if (updateProduct.productCategory == Category.GolfEquipment)
                {
                    category = "Golf Equipment";
                }
                else if (updateProduct.productCategory == Category.MountaineeringEquipment)
                {
                    category = "Mountaineering Equipment";
                }
                else if (updateProduct.productCategory == Category.OutdoorProtection)
                {
                    category = "Outdoor Protection";
                }
                else if (updateProduct.productCategory == Category.PersonalAccessories)
                {
                    category = "Personal Accessories";
                }
                else
                {
                    category = "Camping Equipment";
                }
                SqlParameter sqlParameter4 = new SqlParameter("@ProductCategory", category);
                sqlParameter4.DbType = DbType.String;
                sqlcmd.Parameters.Add(sqlParameter4);
                SqlParameter sqlParameter5 = new SqlParameter("@ProductColor", updateProduct.ProductColor);
                sqlParameter5.DbType = DbType.String;
                sqlcmd.Parameters.Add(sqlParameter5);
                SqlParameter sqlParameter6 = new SqlParameter("@ProductSize", updateProduct.ProductSize);
                sqlParameter6.DbType = DbType.String;
                sqlcmd.Parameters.Add(sqlParameter6);
                SqlParameter sqlParameter7 = new SqlParameter("@ProductMaterial", updateProduct.ProductMaterial);
                sqlParameter7.DbType = DbType.String;
                sqlcmd.Parameters.Add(sqlParameter7);
                SqlParameter sqlParameter8 = new SqlParameter("@ProductPrice", updateProduct.ProductPrice);
                sqlParameter8.DbType = DbType.Double;
                sqlcmd.Parameters.Add(sqlParameter8);


                //opening the sql connection
                sqlConn.Open();

                //executing the delete query
                sqlcmd.ExecuteNonQuery();

                //set the productdeleted to true if deleted
                priceUpdated = true;

                //close the sql database conbection
                sqlConn.Close();
            }
            catch (Exception)
            {
                throw;
            }

            return priceUpdated;

        }

        /// <summary>
        /// Clears unmanaged resources suc as db connections or file streams
        /// </summary>
        public void Dispose()
        {
            //No unmanaged resources currently!
        }
    }
}
