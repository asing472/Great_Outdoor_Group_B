﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using Capgemini.GreatOutdoor.Contracts.DALContracts;
using Capgemini.GreatOutdoor.DALCommon;
using Capgemini.GreatOutdoor.Entities;
using Capgemini.GreatOutdoor.Exceptions;
using Capgemini.GreatOutdoor.Helpers;

namespace Capgemini.GreatOutdoor.DataAccessLayer
{
    /// <summary>
    /// Developed by Prafull Sharma
    /// Contains data access layer methods for inserting, updating, deleting addresss from Addresss collection.
    /// </summary>
    public class AddressDAL : AddressDALBase, IDisposable
    {
        //Connection String Definition
        SqlConnection sqlConn = new SqlConnection(Properties.Settings.Default.dbCon);
        /// <summary>
        /// Adds new address to Addresss collection.
        /// </summary>
        /// <param name="newAddress">Contains the address details to be added.</param>
        /// <returns>Determinates whether the new address is added.</returns>
        public override (bool,Guid) AddAddressDAL(Address newAddress)
        {
            sqlConn.Open();
            Guid AddressGuid = default(Guid);
            bool addressAdded = false;
            try
            {
                 AddressGuid = Guid.NewGuid();
                newAddress.AddressID = AddressGuid;
                newAddress.CreationDateTime = DateTime.Now;
                newAddress.LastModifiedDateTime = DateTime.Now;
                SqlCommand sqlCmd = new SqlCommand("TeamB.AddAddress", sqlConn);
                //creating object of sql Command
                sqlCmd.CommandType = System.Data.CommandType.StoredProcedure;
                sqlCmd.Parameters.AddWithValue("@addressID", AddressGuid);
                sqlCmd.Parameters.AddWithValue("@addressLine1", newAddress.AddressLine1);
                sqlCmd.Parameters.AddWithValue("@addressLine2", newAddress.AddressLine2);
                sqlCmd.Parameters.AddWithValue("@landmark", newAddress.Landmark);
                sqlCmd.Parameters.AddWithValue("@city", newAddress.City);
                sqlCmd.Parameters.AddWithValue("@state", newAddress.State);
                sqlCmd.Parameters.AddWithValue("@pinCode", newAddress.PinCode);
                sqlCmd.Parameters.AddWithValue("@retailerID", newAddress.RetailerID);
                sqlCmd.Parameters.AddWithValue("@CreationDateTime", newAddress.CreationDateTime);
                sqlCmd.Parameters.AddWithValue("@LastModifiedDateTime", newAddress.LastModifiedDateTime);
                //creating object of sql data reader
                Int16 isadded = Convert.ToInt16(sqlCmd.ExecuteScalar());
                if (isadded > 0)
                { addressAdded = true; }
                else
                { addressAdded = false; }
                sqlConn.Close();
            }
            catch (Exception)
            {
                throw;
            }
            return (addressAdded, AddressGuid);
        }

        /// <summary>
        /// Gets all addresss from the collection.
        /// Developed By Prafull Sharma
        /// </summary>
        /// <returns>Returns list of all addresss.</returns>
        public override List<Address> GetAllAddresssDAL()
        {
            List<Address> matchingAddress = new List<Address>();
            sqlConn.Open();
            try
            {
                //Connection String Definition
                SqlCommand sqlCmd = new SqlCommand("Select * from TeamB.Addresses", sqlConn);
                //creating object of sql Command
                sqlCmd.CommandType = System.Data.CommandType.StoredProcedure;
                SqlDataReader reader = sqlCmd.ExecuteReader();
                //creating object of sql data reader
                while (reader.Read())
                {
                    Address maddress = new Address();
                    maddress.AddressID = new Guid(reader["AddressID"].ToString());
                    maddress.AddressLine1 = reader["AddressLine1"].ToString();
                    maddress.AddressLine2 = reader["AddressLine2"].ToString();
                    maddress.Landmark = reader["LandMark"].ToString();
                    maddress.City = reader["City"].ToString();
                    maddress.State = reader["State"].ToString();
                    maddress.RetailerID = new Guid(reader["RetailerID"].ToString());
                    maddress.CreationDateTime = DateTime.Parse(reader["CreationDateTime"].ToString());
                    maddress.LastModifiedDateTime = DateTime.Parse(reader["LastModifiedDateTime"].ToString());
                    matchingAddress.Add(maddress);
                }
                sqlConn.Close();
            }
            catch (Exception)
            {
                throw;
            }
            return matchingAddress;
        }

        /// <summary>
        /// Gets address based on AddressID.
        /// Developed by Prafull Sharma
        /// </summary>
        /// <param name="searchAddressID">Represents AddressID to search.</param>
        /// <returns>Returns Address object.</returns>
        public override Address GetAddressByAddressIDDAL(Guid searchAddressID)
        {
            Address matchingAddress = null;
            sqlConn.Open();
            try
            {
                //DbCommand command = DataConnection.CreateCommand();
                //command.CommandText = "uspAddGuest";

                //DbParameter param = command.CreateParameter();
                //param.ParameterName = "@ipv_iGuestID";
                //param.DbType = DbType.Int32;
                //param.Value = newGuest.GuestID;
                //command.Parameters.Add(param);


                //param = command.CreateParameter();
                //param.ParameterName = "@ipv_vcGuestName";
                //param.DbType = DbType.String;
                //param.Value = newGuest.GuestName;
                //command.Parameters.Add(param);
                SqlCommand sqlCmd = new SqlCommand("TeamB.GetAddressesByAddressID", sqlConn);
                //creating object of sql Command
                sqlCmd.Parameters.AddWithValue("@addressID", searchAddressID);
                sqlCmd.CommandType = System.Data.CommandType.StoredProcedure;
                SqlDataReader reader = sqlCmd.ExecuteReader();
                //creating object of sql data reader
                while (reader.Read())
                {
                    Address maddress = new Address();
                    maddress.AddressID = new Guid(reader["AddressID"].ToString());
                    maddress.AddressLine1 = reader["AddressLine1"].ToString();
                    maddress.AddressLine2 = reader["AddressLine2"].ToString();
                    maddress.Landmark = reader["LandMark"].ToString();
                    maddress.City = reader["City"].ToString();
                    maddress.State = reader["State"].ToString();
                    maddress.PinCode = reader["PinCode"].ToString();
                    maddress.RetailerID = new Guid(reader["RetailerID"].ToString());
                    maddress.CreationDateTime = DateTime.Parse(reader["CreationDateTime"].ToString());
                    maddress.LastModifiedDateTime = DateTime.Parse(reader["LastModifiedDateTime"].ToString());
                    matchingAddress = maddress;
                }
                sqlConn.Close();

            }
            catch (Exception)
            {
                throw;
            }
            return matchingAddress;
        }


        /// <summary>
        /// Gets address based on email.
        /// Developed By Prafull Sharma
        /// </summary>
        /// <param name="email">Represents Address's Email Address.</param>
        /// <returns>Returns Address object.</returns>
        public override List<Address> GetAddressByRetailerIDDAL(Guid RetailerID)
        {
            List<Address> matchingAddress = new List<Address>();
            sqlConn.Open();
            try
            {
                SqlCommand sqlCmd = new SqlCommand("TeamB.GetAddressesByRetailerID", sqlConn);
                //creating object of sql Command
                sqlCmd.Parameters.AddWithValue("@retailerID", RetailerID);
                sqlCmd.CommandType = System.Data.CommandType.StoredProcedure;
                SqlDataReader reader = sqlCmd.ExecuteReader();
                //creating object of sql data reader
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Address maddress = new Address();
                        maddress.AddressID = new Guid(reader["AddressID"].ToString());
                        maddress.AddressLine1 = reader["AddressLine1"].ToString();
                        maddress.AddressLine2 = reader["AddressLine2"].ToString();
                        maddress.Landmark = reader["LandMark"].ToString();
                        maddress.City = reader["City"].ToString();
                        maddress.State = reader["State"].ToString();
                        maddress.PinCode = reader["PinCode"].ToString();
                        maddress.RetailerID = new Guid(reader["RetailerID"].ToString());
                        maddress.CreationDateTime = DateTime.Parse(reader["CreationDateTime"].ToString());
                        maddress.LastModifiedDateTime = DateTime.Parse(reader["LastModifiedDateTime"].ToString());
                        matchingAddress.Add(maddress);
                    }
                }

                sqlConn.Close();
            }
            catch (Exception)
            {
                throw;
            }
            return matchingAddress;
        }


        /// <summary>
        /// Updates address based on AddressID.
        /// Developed by - Prafull Sharma
        /// </summary>
        /// <param name="updateAddress">Represents Address details including AddressID, AddressName etc.</param>
        /// <returns>Determinates whether the existing address is updated.</returns>
        public override bool UpdateAddressDAL(Address updateAddress)
        {
            
            bool addressUpdated = false;
            try
            {
                //Find Address based on AddressID
                Address matchingAddress = GetAddressByAddressIDDAL(updateAddress.AddressID);

                if (matchingAddress != null)
                {
                    //Update address details
                    ReflectionHelpers.CopyProperties(updateAddress, matchingAddress, new List<string>() { "AddressLine1", "AddressLine2", "Landmark", "City", "State", "PinCode" });
                    matchingAddress.LastModifiedDateTime = DateTime.Now;
                    SqlCommand sqlCmd = new SqlCommand("TeamB.UpdateAddress", sqlConn);
                    //creating object of sql Command
                    sqlCmd.CommandType = System.Data.CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("@addressID",matchingAddress.AddressID);
                    sqlCmd.Parameters.AddWithValue("@addressLine1", matchingAddress.AddressLine1);
                    sqlCmd.Parameters.AddWithValue("@addressLine2", matchingAddress.AddressLine2);
                    sqlCmd.Parameters.AddWithValue("@landmark", matchingAddress.Landmark);
                    sqlCmd.Parameters.AddWithValue("@city", matchingAddress.City);
                    sqlCmd.Parameters.AddWithValue("@state", matchingAddress.State);
                    sqlCmd.Parameters.AddWithValue("@pinCode", matchingAddress.PinCode);
                    sqlCmd.Parameters.AddWithValue("@retailerID", matchingAddress.RetailerID);
                    sqlCmd.Parameters.AddWithValue("@CreationDateTime", matchingAddress.CreationDateTime);
                    sqlCmd.Parameters.AddWithValue("@LastModifiedDateTime", matchingAddress.LastModifiedDateTime);
                    sqlConn.Open();
                    Int16 isadded = Convert.ToInt16(sqlCmd.ExecuteScalar());
                    if (isadded > 0)
                    { addressUpdated = true; }
                    else
                    { addressUpdated = false; }
                    sqlConn.Close();
                }
               
            }
            catch (Exception)
            {
                throw;
            }
            return addressUpdated;
        }

        /// <summary>
        /// Deletes address based on AddressID.
        /// Developed By - Prafull Sharma
        /// </summary>
        /// <param name="deleteAddressID">Represents AddressID to delete.</param>
        /// <returns>Determinates whether the existing address is updated.</returns>
        public override bool DeleteAddressDAL(Guid deleteAddressID)
        {
            sqlConn.Open();
            bool addressDeleted = false;
            try
            {
                SqlCommand sqlCmd = new SqlCommand("TeamB.DeleteAddress", sqlConn);
                //creating object of sql Command
                sqlCmd.CommandType = System.Data.CommandType.StoredProcedure;
                sqlCmd.Parameters.AddWithValue("@addressID", deleteAddressID);
                Int16 isdeleted = Convert.ToInt16(sqlCmd.ExecuteScalar());
                if (isdeleted > 0)
                { addressDeleted = true; }
                else
                { addressDeleted = false; }
                sqlConn.Close();
            }
            catch (Exception)
            {
                throw;
            }
            return addressDeleted;
        }



        /// <summary>
        /// Clears unmanaged resources such as db connections or file streams.
        /// </summary>
        public void Dispose()
        {
            //No unmanaged resources currently
        }
    }
}



