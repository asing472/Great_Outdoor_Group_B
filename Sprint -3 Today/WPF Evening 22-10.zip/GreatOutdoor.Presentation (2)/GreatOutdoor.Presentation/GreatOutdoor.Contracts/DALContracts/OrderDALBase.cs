﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using Capgemini.GreatOutdoor.Entities;
using Newtonsoft.Json;
namespace Capgemini.GreatOutdoor.Contracts.DALContracts
{
    //Developed By C AKhil Chowdary
    /// <summary>
    /// This abstract class acts as a base for OrderDAL class
    /// </summary>
    public abstract class OrderDALBase
    {
        //Collection of Orders
        protected static List<Order> ordersList = new List<Order>();

        //Methods
        public abstract Order GetOrderByOrderNumberDAL(int orderNumber);
        public abstract (bool,Guid) AddOrderDAL(Order newOrder);
        public abstract Order GetOrderByOrderIDDAL(Guid searchOrderID);
        public abstract bool UpdateOrderDAL(Order updateOrder);
        public abstract bool DeleteOrderDAL(Guid deleteOrderID);
        public abstract List<Order> GetOrdersByRetailerIDDAL(Guid retailerID);
        
    }
}
