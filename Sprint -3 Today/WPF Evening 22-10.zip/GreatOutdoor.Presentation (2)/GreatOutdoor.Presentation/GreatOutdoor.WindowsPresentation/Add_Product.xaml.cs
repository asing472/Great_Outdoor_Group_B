﻿using Capgemini.GreatOutdoor.BusinessLayer;
using Capgemini.GreatOutdoor.Contracts.BLContracts;
using Capgemini.GreatOutdoor.Entities;
using Capgemini.GreatOutdoor.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GreatOutdoor.WindowsPresentation
{
    /// <summary>
    /// Interaction logic for Add_Product.xaml
    /// </summary>
    public partial class Add_Product : Window
    {
        public Add_Product()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Event that adds a product to the database table on clciking of a button
        /// </summary>
        private async void BtnAdd_Click(object sender, RoutedEventArgs e)
        {

            //Initializing of Parent class with a child object to use the business logic layer
            IProductBL productBL = new ProductBL();
            Product addProduct = new Product();
            bool isAdded;

            //add user enetered values the the product object
            addProduct.ProductID = Guid.NewGuid();
            addProduct.ProductName = Convert.ToString(txtName.Text);
            addProduct.ProductNumber = default(int);
            //convert the product category to enum format before sending as an argument
            Category category;
            if (cmbType.Text == "Camping Equipment")
            {
                category = Category.CampingEquipment;
            }
            else if (cmbType.Text == "Golf Equipment")
            {
                category = Category.GolfEquipment;
            }
            else if (cmbType.Text == "Mountaineering Equipment")
            {
                category = Category.MountaineeringEquipment;
            }
            else if (cmbType.Text == "Outdoor Protection")
            {
                category = Category.OutdoorProtection;
            }
            else if (cmbType.Text == "Personal Accessories")
            {
                category = Category.PersonalAccessories;
            }
            else
            {
                category = Category.CampingEquipment;
            }
            addProduct.productCategory = category;
            addProduct.ProductColor = Convert.ToString(txtColor.Text);
            addProduct.ProductSize = Convert.ToString(txtSize.Text);
            addProduct.ProductMaterial = Convert.ToString(txtMaterial.Text);
            addProduct.ProductPrice = Convert.ToDouble(txtPrice.Text);
            isAdded = await productBL.AddProductBL(addProduct);

            //display a message if the product is added successfully!
            if (isAdded)
            {
                MessageBox.Show("Product is successfully added!");
            }
        }

        private void BtnGet_Click(object sender, RoutedEventArgs e)
        {
            //code to move to another window on the click of a button
            Window window = new MainWindow();
            window.Show();
        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

    }
}
