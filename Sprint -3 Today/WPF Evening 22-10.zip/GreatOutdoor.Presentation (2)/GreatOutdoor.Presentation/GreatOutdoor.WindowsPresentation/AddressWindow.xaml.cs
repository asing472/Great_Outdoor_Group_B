﻿using Capgemini.GreatOutdoor.BusinessLayer;
using Capgemini.GreatOutdoor.Entities;
using Capgemini.GreatOutdoor.Exceptions;
using Capgemini.GreatOutdoor.PresentationLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GreatOutdoor.WindowsPresentation
{
    /// <summary>
    /// Interaction logic for AddressWindow.xaml
    /// </summary>
    public partial class AddressWindow : Window
    {
        Guid AddressID = default(Guid);
        public AddressWindow()
        {
            //Initialize Object
            InitializeComponent();
            loaddata();
        }
        //method to give input to load Data
        private async void loaddata()
        {
            RetailerBL retailerBL = new RetailerBL();
            Retailer retailer = await retailerBL.GetRetailerByEmailBL(CommonData.CurrentUser.Email);
            try
            {
                DataTable addresstable = new DataTable();
                List<Address> addresses = new List<Address>();
                using (AddressBL addressBL = new AddressBL())
                {     
                    addresses= await addressBL.GetAddressByRetailerIDBL(retailer.RetailerID);
                    addresstable = ConvertToDataTable<Address>(addresses);
                }
                dgvAddress.ItemsSource = addresstable.DefaultView;
            }
            catch (Exception)
            {
                throw;
            }
            

        }


        private void Menu_Address_Click(object sender, RoutedEventArgs e)
        {


        }
        //method to give  input to btnADD Click
        private async void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                //Read inputs
                Address address = new Address();
                RetailerBL retailerBL = new RetailerBL();
                Retailer retailer = await retailerBL.GetRetailerByEmailBL(CommonData.CurrentUser.Email);
                address.RetailerID = retailer.RetailerID;
                address.AddressLine1 = txtAddressLine1.Text;
                address.AddressLine2 = txtAddressLine2.Text;
                address.Landmark = txtLandMark.Text;
                address.City = txtCity.Text;
                address.State = txtState.Text;
                address.PinCode = txtPinCode.Text;
                //Invoke AddAddressBL method to add
                using (AddressBL addressBL = new AddressBL())
                {
                    bool isAdded = false;
                    Guid Address = default(Guid);
                    (isAdded,Address) = await addressBL.AddAddressBL(address);
                    if (isAdded)
                    {
                        MessageBox.Show("Address Added");
                    }
                    loaddata();
                }
            }
            catch (Exception ex)
            {
                ExceptionLogger.LogException(ex);
                MessageBox.Show(ex.Message);
            }
        }
        //method tocovert to data table
        public DataTable ConvertToDataTable<Address>(IList<Address> data)
        {
            PropertyDescriptorCollection properties =
               TypeDescriptor.GetProperties(typeof(Address));
            DataTable table = new DataTable();
            foreach (PropertyDescriptor prop in properties)
                table.Columns.Add(prop.Name, Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType);
            foreach (Address item in data)
            {
                DataRow row = table.NewRow();
                foreach (PropertyDescriptor prop in properties)
                    row[prop.Name] = prop.GetValue(item) ?? DBNull.Value;
                table.Rows.Add(row);
            }
            return table;

        }
        //method to bt update Click
        private async void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                //Read inputs
                Address address = new Address();
                RetailerBL retailerBL = new RetailerBL();
                Retailer retailer = await retailerBL.GetRetailerByEmailBL(CommonData.CurrentUser.Email);
                address.AddressID = AddressID;
                address.RetailerID = retailer.RetailerID;
                address.AddressLine1 = txtAddressLine1.Text;
                address.AddressLine2 = txtAddressLine2.Text;
                address.Landmark = txtLandMark.Text;
                address.City = txtCity.Text;
                address.State = txtState.Text;
                address.PinCode = txtPinCode.Text;
                //Invoke AddAddressBL method to add
                using (AddressBL addressBL = new AddressBL())
                {
                    bool isUpdated = false;
                 
                    isUpdated = await addressBL.UpdateAddressBL(address);
                    if (isUpdated)
                    {
                        MessageBox.Show("Address Updated");
                    }
                    loaddata();

                }
            }
            catch (Exception ex)
            {
                ExceptionLogger.LogException(ex);
                MessageBox.Show(ex.Message);
            }
        }
        //method to input to Delete Click
        private async void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using (AddressBL addressBL = new AddressBL())
                {
                    if (MessageBox.Show("Are you sure do you want to delete?", "Great Outdoors", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                    {
                        bool isDeleted = false;
                        isDeleted = await addressBL.DeleteAddressBL(AddressID);
                        loaddata();
                        if (isDeleted)
                        {
                            MessageBox.Show("Address Deleted");
                        }
                    }
                    
                }

            }
            catch (Exception)
            {
                throw;
            }
        }
        //method to giveto Address Combobox
        private void dgvAddress_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int rowindex = dgvAddress.SelectedIndex;
            if (rowindex < 0)
            {
                return;
            }
            AddressID = new Guid(getCellData(dgvAddress, rowindex,0));
            txtAddressLine1.Text = getCellData(dgvAddress, rowindex, 1);
            txtAddressLine2.Text = getCellData(dgvAddress, rowindex, 2);
            txtLandMark.Text = getCellData(dgvAddress, rowindex, 3);
            txtCity.Text= getCellData(dgvAddress, rowindex, 4);
            txtState.Text= getCellData(dgvAddress, rowindex,5 );
            txtPinCode.Text = getCellData(dgvAddress, rowindex, 6);

        }
        private string getCellData(DataGrid dgv, int rowindex, int cellindex)
        {
            DataGridRow drow =
                dgv.ItemContainerGenerator.ContainerFromIndex(rowindex) as DataGridRow;
            var cellContent =
                dgv.Columns[cellindex].GetCellContent(drow) as TextBlock;
            return cellContent.Text;
        }


        //method to give input to online Return menu
        private void OnlineReturn_Click(object sender, RoutedEventArgs e)
        {
            Hide();
            Window window = new SalesPersonWindow();
            window.Show();
        }
    }
}
