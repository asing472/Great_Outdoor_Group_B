﻿using Capgemini.GreatOutdoor.BusinessLayer;
using Capgemini.GreatOutdoor.Entities;
using Capgemini.GreatOutdoor.PresentationLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GreatOutdoor.WindowsPresentation
{
    /// <summary>
    /// Developed by - Ayush Agrawal
    /// Interaction logic for OnlineReturnsWindow.xaml
    /// </summary>
    public partial class OnlineReturnsWindow : Window
    {
        public OnlineReturnsWindow()
        {
            InitializeComponent();
            loadData();
        }

        //Creating load Data Mthod
        private async void loadData()
        {
            try
            {
                RetailerBL retailerBL = new RetailerBL();
                Retailer retailer = await retailerBL.GetRetailerByEmailBL(CommonData.CurrentUser.Email);
                List<Order> orders = await orderBL.GetOrdersByRetailerIDBL(retailer.RetailerID);
                DataTable dataTable = ConvertToDataTable<Order>(orders);

                cmbOrderNumber.ItemsSource = dataTable.DefaultView;
                cmbOrderNumber.DisplayMemberPath = "OrderNumber";
                cmbOrderNumber.SelectedValuePath = "OrderNumber";
            }
            catch (Exception)
            {

                throw;
            }
           
        }

        OnlineReturnBL onlineReturnBL = new OnlineReturnBL();
        OnlineReturn onlineReturn1 = new OnlineReturn();
        OrderBL orderBL = new OrderBL();
        OrderDetail orderDetail = new OrderDetail();
        OrderDetailBL orderDetailBL = new OrderDetailBL();

        // Creating OrderNumber Selection Changed Method 
        private async void OrderNumber_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                int ordernumber = Convert.ToInt32(cmbOrderNumber.SelectedValue);
                onlineReturn1.OrderNumber = ordernumber;
                Order order = await orderBL.GetOrderByOrderNumberBL(ordernumber);
                List<OrderDetail> orderdetails = await orderDetailBL.GetOrderDetailsByOrderIDBL(order.OrderId);
                onlineReturn1.OrderID = order.OrderId;
                onlineReturn1.RetailerID = order.RetailerID;
                onlineReturn1.ProductNumber = 0;

                //DataTable dataTable = ConvertToDataTable<OrderDetail>(orderdetails);
                cmbProductID.ItemsSource = orderdetails;
                cmbProductID.DisplayMemberPath = "ProductName";
                cmbProductID.SelectedValuePath = "ProductID";


            }
            catch (Exception)
            {

                throw;
            }

        }
        //Creating Method for Converting to Data Table

        public DataTable ConvertToDataTable<Order>(IList<Order> data)
        {
            try
            {
                PropertyDescriptorCollection properties =
              TypeDescriptor.GetProperties(typeof(Order));
                DataTable table = new DataTable();
                foreach (PropertyDescriptor prop in properties)
                    table.Columns.Add(prop.Name, Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType);
                foreach (Order item in data)
                {
                    DataRow row = table.NewRow();
                    foreach (PropertyDescriptor prop in properties)
                        row[prop.Name] = prop.GetValue(item) ?? DBNull.Value;
                    table.Rows.Add(row);
                }
                return table;
            }
            catch (Exception)
            {

                throw;
            }
           

        }
        //Creating Method for ProductName selection Combo box  

        private async void ProductID_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                onlineReturn1.ProductID = new Guid(Convert.ToString(cmbProductID.SelectedValue));
                ProductBL productBL = new ProductBL();
                Product product = await productBL.GetProductByProductIDBL(onlineReturn1.ProductID);
                ProductPrice1.Text = Convert.ToString(product.ProductPrice);
                onlineReturn1.ProductPrice = product.ProductPrice;
            }
            catch (Exception)
            {

                throw;
            }
            
            
            
        }
        //Creating Method for Purpose selection Combo box  
        private void PurposeOfReturn_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            onlineReturn1.Purpose = Convert.ToString(cmbPurposeOfReturn.SelectedValue);
        }

        private void Reset_Click(object sender, RoutedEventArgs e)
        {

        }
        //Creating Method for Apply For online Return Combo box  

        private async void ApplyForReturn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                onlineReturn1.QuantityOfReturn = Convert.ToInt32(txtQuantityOfReturn1.Text);
                onlineReturn1.TotalAmount = onlineReturn1.QuantityOfReturn * Convert.ToDouble(ProductPrice1.Text);
                bool isAdded = false;
                Guid onlineReturnGuid = default(Guid);
                (isAdded, onlineReturnGuid) = await onlineReturnBL.AddOnlineReturnBL(onlineReturn1);
                if (isAdded)
                {
                    MessageBox.Show("Return Added");
                }
                else
                {
                    MessageBox.Show("Return Failed");
                }
                MessageBox.Show($"Online Return Confirmed \n Online Return ID ={onlineReturn1.OnlineReturnID} \n ReturnAmount ={onlineReturn1.TotalAmount}");
                List<OnlineReturn> onlineDetails = await onlineReturnBL.GetOnlineReturnByRetailerIDBL(onlineReturn1.RetailerID);
                dgvDetails.ItemsSource = onlineDetails;
            }
            catch (Exception)
            {

                throw;
            }
           
        }

        private void TabControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }


        private void TxtQuantityOfReturn1_TextChanged(object sender, TextChangedEventArgs e)
        {
           // txtReturnAmount.Text = Convert.ToString(Convert.ToInt32(txtQuantityOfReturn1.Text) * onlineReturn1.ProductPrice);
        }

        private void DgvDetails_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
