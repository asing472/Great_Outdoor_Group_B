﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using Capgemini.GreatOutdoor.Entities;
using Newtonsoft.Json;

namespace Capgemini.GreatOutdoor.Contracts
{
    /// <summary>
    /// This abstract class acts as a base for OrderDetailDAL class
    /// </summary>
    public abstract class OrderDetailDALBase
    {
        //Collection of OrderDetails
        protected static List<OrderDetail> orderDetailsList = new List<OrderDetail>();

        private static string fileName = "orderDetails.json";

        //Methods
        public abstract (bool,Guid) AddOrderDetailsDAL(OrderDetail newOrder);
        public abstract List<OrderDetail> GetOrderDetailsByOrderIDDAL(Guid searchOrderID);
        public abstract OrderDetail GetOrderDetailByOrderDetailIDDAL(Guid searchOrderID);
        public abstract bool UpdateOrderDetailsDAL(OrderDetail updateOrder);
        public abstract bool DeleteOrderDetailsDAL(Guid deleteOrderID);
        public abstract bool UpdateOrderDeliveredStatusDAL(Guid orderID);
        public abstract bool UpdateOrderShippedStatusDAL(Guid orderID);
        public abstract bool UpdateOrderDispatchedStatusDAL(Guid orderID);

    }
}
