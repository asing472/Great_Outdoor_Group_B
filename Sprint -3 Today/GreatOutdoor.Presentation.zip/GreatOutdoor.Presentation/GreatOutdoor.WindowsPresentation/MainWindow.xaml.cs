﻿using Capgemini.GreatOutdoor.BusinessLayer;
using Capgemini.GreatOutdoor.Contracts.BLContracts;
using Capgemini.GreatOutdoor.Entities;
using Capgemini.GreatOutdoor.Helpers;
using Capgemini.GreatOutdoor.PresentationLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace GreatOutdoor.WindowsPresentation
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        
        static async void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int internalChoice = -2;
                //Invoke Login Screen
                 string enail = txt
                (UserType userType, IUser currentUser) = await ShowLoginScreen();

                //Set current user details into CommonData (global data)
                CommonData.CurrentUser = currentUser;
                CommonData.CurrentUserType = userType;

                //Invoke User's Menu
                if (userType == UserType.Admin)
                {
                    internalChoice = await AdminPresentation.AdminUserMenu();
                }
                else if (userType == UserType.SalesPerson)
                {
                    internalChoice = await SalesPersonPresentation.SalesPersonMenu();
                }
                else if (userType == UserType.Retailer)
                {
                    internalChoice = await RetailerPresentation.RetailerUserMenu();
                }
                else if (userType == UserType.Anonymous)
                {
                }
            }
            catch(Exception)
            {
                throw;
            }

           

        }

        static async Task<(UserType, IUser)> ShowLoginScreen()
        {
            
            using (IAdminBL adminBL = new AdminBL())
            {
                //Invoke GetAdminByEmailAndPasswordBL for checking email and password of Admin
                Admin admin = await adminBL.GetAdminByEmailAndPasswordBL(email, password);
                if (admin != null)
                {
                    return (UserType.Admin, admin);
                }
            }

            using (ISalesPersonBL SalesPersonBL = new SalesPersonBL())
            {
                //Invoke GetAdminByEmailAndPasswordBL for checking email and password of Admin
                SalesPerson SalesPerson = await SalesPersonBL.GetSalesPersonByEmailAndPasswordBL(email, password);
                if (SalesPerson != null)
                {
                    return (UserType.SalesPerson, SalesPerson);
                }
            }
            using (IRetailerBL RetailerBL = new RetailerBL())
            {
                //Invoke GetAdminByEmailAndPasswordBL for checking email and password of Admin
                Retailer retailer = await RetailerBL.GetRetailerByEmailAndPasswordBL(email, password);
                if (retailer != null)
                {
                    return (UserType.Retailer, retailer);
                }
            }
            return (UserType.Anonymous, null);
        }
    }
}
