﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Capgemini.GreatOutdoor.Contracts.DALContracts;
using Capgemini.GreatOutdoor.Entities;
using Capgemini.GreatOutdoor.Exceptions;
using Capgemini.GreatOutdoor.Helpers;
using System.Data.SqlClient;
using System.Data;


namespace Capgemini.GreatOutdoor.DataAccessLayer
{
    /// <summary>
    /// Contains data access layer methods for inserting, updating, deleting onlineReturn from OnlineReturn collection.
    /// </summary>
    public class OnlineReturnDAL : OnlineReturnDALBase, IDisposable
    {
        /// <summary>
        /// Adds new onlineReturn to OnlineReturn collection.
        /// </summary>
        /// <param name="newOnlineReturn">Contains the onlineReturn details to be added.</param>
        /// <returns>Determinates whether the new OnlineReturn is added.</returns>
        public override (bool, Guid) AddOnlineReturnDAL(OnlineReturn newOnlineReturn)
        {
            bool onlineReturnAdded = false;
            try
            {
                //Order order = new Order();
                //    Retailer retailer = new Retailer();
                //    Product product = new Product();
                //    OrderDetail orderDetail = new OrderDetail(); 

                newOnlineReturn.OnlineReturnID = Guid.NewGuid();
                newOnlineReturn.CreationDateTime = DateTime.Now;
                newOnlineReturn.LastModifiedDateTime = DateTime.Now;
                SqlConnection sqlConnection = new SqlConnection(Properties.Settings.Default.dbCon);
                sqlConnection.Open();
                string query = "TeamB.AddOnlineReturn";
                SqlCommand sqlCmd = new SqlCommand(query, sqlConnection);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                //sqlCmd.Parameters.AddWithValue("@onlineReturnID", newOnlineReturn.OnlineReturnID).DbType = DbType.Guid;

                SqlParameter paramOnlineReturnID = new SqlParameter();
                paramOnlineReturnID.ParameterName = "@onlineReturnID";
                paramOnlineReturnID.Value = newOnlineReturn.OnlineReturnID;
                paramOnlineReturnID.DbType = DbType.Guid;
                sqlCmd.Parameters.Add(paramOnlineReturnID);

                //sqlCmd.Parameters.AddWithValue("@orderID", newOnlineReturn.OrderID).DbType = DbType.Guid; ;

                SqlParameter paramOrderID = new SqlParameter();
                paramOrderID.ParameterName = "@orderID";
                paramOrderID.Value = newOnlineReturn.OrderID;
                paramOrderID.DbType = DbType.Guid;
                sqlCmd.Parameters.Add(paramOrderID);
                //  sqlCmd.Parameters.AddWithValue("@productID", newOnlineReturn.ProductID).DbType = DbType.Guid; ;

                SqlParameter paramProductID = new SqlParameter();
                paramProductID.ParameterName = "@productID";
                paramProductID.Value = newOnlineReturn.ProductID;
                paramProductID.DbType = DbType.Guid;
                sqlCmd.Parameters.Add(paramProductID);
                // sqlCmd.Parameters.AddWithValue("@retailerID", newOnlineReturn.RetailerID).DbType = DbType.Guid; ;

                SqlParameter paramRetailerID = new SqlParameter();
                paramRetailerID.ParameterName = "@retailerID";
                paramRetailerID.Value = newOnlineReturn.RetailerID;
                paramRetailerID.DbType = DbType.Guid;
                sqlCmd.Parameters.Add(paramRetailerID);

                sqlCmd.Parameters.AddWithValue("@orderNumber", newOnlineReturn.OrderNumber);
                sqlCmd.Parameters.AddWithValue("@productNumber", newOnlineReturn.ProductNumber);
                sqlCmd.Parameters.AddWithValue("@totalAmount", newOnlineReturn.TotalAmount);
                sqlCmd.Parameters.AddWithValue("@productPrice", newOnlineReturn.ProductPrice);
                sqlCmd.Parameters.AddWithValue("@purpose", newOnlineReturn.Purpose);
                sqlCmd.Parameters.AddWithValue("@quantityOfReturn", newOnlineReturn.QuantityOfReturn);
                sqlCmd.Parameters.AddWithValue("@lastModifiedDateTime", newOnlineReturn.LastModifiedDateTime);
                sqlCmd.Parameters.AddWithValue("@creationDateTime", newOnlineReturn.CreationDateTime);

                Int16 isadded = Convert.ToInt16(sqlCmd.ExecuteScalar());
                if (isadded > 0)
                {
                    onlineReturnAdded = true;
                }
                else
                {
                    onlineReturnAdded = false;

                }
                sqlConnection.Close();
                return (onlineReturnAdded, newOnlineReturn.OnlineReturnID);
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        /// <summary>
        /// Gets all onlineReturn from the collection.
        /// </summary>
        /// <returns>Returns list of all onlineReturn.</returns>
        public override List<OnlineReturn> GetAllOnlineReturnsDAL()
        {
            try
            {
                List<OnlineReturn> onlineReturns = new List<OnlineReturn>();
                SqlConnection sqlConnection = new SqlConnection(Properties.Settings.Default.dbCon);
                string query = "TeamB.GetAllOnlineReturns";
                // SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
                DataSet dataSet = new DataSet();
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(query, sqlConnection);
                SqlCommandBuilder sqlCommandBuilder = new SqlCommandBuilder(sqlDataAdapter);
                sqlDataAdapter.Fill(dataSet);
                DataRow dataRow;
                for (int i = 0; i < dataSet.Tables[0].Rows.Count; i++)
                {
                    dataRow = dataSet.Tables[0].Rows[i];
                    OnlineReturn onlineReturn = new OnlineReturn();
                    onlineReturn.OnlineReturnID = new Guid(Convert.ToString(dataRow["OnlineReturnId"]));
                    onlineReturn.OrderID = new Guid(Convert.ToString(dataRow["OrderId"]));
                    onlineReturn.ProductID = new Guid(Convert.ToString(dataRow["ProductId"]));
                    onlineReturn.OrderNumber = Convert.ToInt32(dataRow["OrderNumber"]);
                    onlineReturn.ProductNumber = Convert.ToInt32(dataRow["ProductNumber"]);
                    onlineReturn.QuantityOfReturn = Convert.ToInt32(dataRow["QuantityOfReturn"]);
                    onlineReturn.TotalAmount = Convert.ToDouble(dataRow["TotalAmount"]);
                    onlineReturn.ProductPrice = Convert.ToDouble(dataRow["ProductPrice"]);
                    onlineReturn.RetailerID = new Guid(Convert.ToString(dataRow["RetailerId"]));
                    onlineReturn.Purpose = Convert.ToString(dataRow["Purpose"]);
                    onlineReturn.LastModifiedDateTime = Convert.ToDateTime(dataRow["LastModifiedDateTime"]);
                    onlineReturn.CreationDateTime = Convert.ToDateTime(dataRow["CreationDateTime"]);
                    onlineReturns.Add(onlineReturn);
                }
                return onlineReturns;
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// Gets onlineReturn based on OnlineReturnID.
        /// </summary>
        /// <param name="searchOnlineReturnID">Represents OnlineReturnID to search.</param>
        /// <returns>Returns onlineReturn object.</returns>
        public override OnlineReturn GetOnlineReturnByOnlineReturnIDDAL(Guid searchOnlineReturnID)
        {
            SqlConnection sqlConn = new SqlConnection(Properties.Settings.Default.dbCon);
            sqlConn.Open();
            OnlineReturn matchingOnlineReturn = null;
            try
            {
                SqlCommand sqlCmd = new SqlCommand("TeamB.GetOnlineReturnByOnlineReturnID", sqlConn);
                sqlCmd.Parameters.AddWithValue("@onlineReturnID", searchOnlineReturnID);
                sqlCmd.CommandType = System.Data.CommandType.StoredProcedure;
                SqlDataReader reader = sqlCmd.ExecuteReader();
                while (reader.Read())
                {
                    OnlineReturn onlineReturns = new OnlineReturn();
                    onlineReturns.OnlineReturnID = new Guid(Convert.ToString(reader["OnlineReturnID"]));
                    onlineReturns.OrderID = new Guid(Convert.ToString(reader["OrderID"]));
                    onlineReturns.ProductID = new Guid(Convert.ToString(reader["ProductID"]));
                    onlineReturns.OrderNumber = Convert.ToInt32(reader["OrderNumber"]);
                    onlineReturns.ProductNumber = Convert.ToInt32(reader["ProductNumber"]);
                    onlineReturns.Purpose = reader["Purpose"].ToString();
                    onlineReturns.QuantityOfReturn = Convert.ToInt32(reader["QuantityOfReturn"]);
                    onlineReturns.RetailerID = new Guid(Convert.ToString(reader["RetailerID"]));
                    onlineReturns.TotalAmount = Convert.ToInt32(reader["TotalAmount"]);
                    onlineReturns.ProductPrice = Convert.ToDouble(reader["ProductPrice"]);
                    onlineReturns.CreationDateTime = DateTime.Parse(reader["CreationDateTime"].ToString());
                    onlineReturns.LastModifiedDateTime = DateTime.Parse(reader["LastModifiedDateTime"].ToString());
                    matchingOnlineReturn = onlineReturns;
                }
                sqlConn.Close();

            }
            catch (Exception)
            {

                throw;
            }
            return matchingOnlineReturn;
        }

        /// <summary>
        /// Gets onlineReturn based on Purpose.
        /// </summary>
        /// <param name="Purpose">Represents Purpose to search.</param>
        /// <returns>Returns OnlineReturn object.</returns>
        public override List<OnlineReturn> GetOnlineReturnsByPurposeDAL(string purpose)
        {
            List<OnlineReturn> matchingOnlineReturns = new List<OnlineReturn>();
            SqlConnection sqlConn = new SqlConnection(Properties.Settings.Default.dbCon);
            sqlConn.Open();
            OnlineReturn matchingOnlineReturn = null;
            try
            {
                SqlCommand sqlCmd = new SqlCommand("TeamB.GetOnlineReturnsByPurpose", sqlConn);
                sqlCmd.Parameters.AddWithValue("@purpose", purpose);
                sqlCmd.CommandType = System.Data.CommandType.StoredProcedure;
                SqlDataReader reader = sqlCmd.ExecuteReader();
                while (reader.Read())
                {
                    OnlineReturn onlineReturns = new OnlineReturn();
                    onlineReturns.OnlineReturnID = new Guid(Convert.ToString(reader["OnlineReturnID"]));
                    onlineReturns.OrderID = new Guid(Convert.ToString(reader["OrderID"]));
                    onlineReturns.ProductID = new Guid(Convert.ToString(reader["ProductID"]));
                    onlineReturns.OrderNumber = Convert.ToInt32(reader["OrderNumber"]);
                    onlineReturns.ProductNumber = Convert.ToInt32(reader["ProductNumber"]);
                    onlineReturns.Purpose = reader["Purpose"].ToString();
                    onlineReturns.QuantityOfReturn = Convert.ToInt32(reader["QuantityOfReturn"]);
                    onlineReturns.RetailerID = new Guid(Convert.ToString(reader["RetailerID"]));
                    onlineReturns.TotalAmount = Convert.ToInt32(reader["TotalAmount"]);
                    onlineReturns.ProductPrice = Convert.ToDouble(reader["ProductPrice"]);
                    onlineReturns.CreationDateTime = DateTime.Parse(reader["CreationDateTime"].ToString());
                    onlineReturns.LastModifiedDateTime = DateTime.Parse(reader["LastModifiedDateTime"].ToString());
                    matchingOnlineReturn = onlineReturns;
                }
                sqlConn.Close();

            }
            catch (Exception)
            {

                throw;
            }
            return matchingOnlineReturns;
        }

        /// <summary>
        /// Updates Order based on OrderID.
        /// </summary>
        /// <param name="OnlineReturn">Represents Order details like OrderID</param>
        /// <returns>Determinates whether the existing Order is updated.</returns>

        public override List<OnlineReturn> GetOnlineReturnByRetailerIDDAL(Guid searchRetailerID)
        {
            List<OnlineReturn> matchingOnlineReturn = new List<OnlineReturn>();
            SqlConnection sqlConn = new SqlConnection(Properties.Settings.Default.dbCon);
            sqlConn.Open();
            OnlineReturn matchingOnlineReturn1 = null;
            try
            {
                SqlCommand sqlCmd = new SqlCommand("TeamB.GetOnlineReturnByRetailerID", sqlConn);
                sqlCmd.Parameters.AddWithValue("@retailerID", searchRetailerID);
                sqlCmd.CommandType = System.Data.CommandType.StoredProcedure;
                SqlDataReader reader = sqlCmd.ExecuteReader();
                while (reader.Read())
                {
                    OnlineReturn onlineReturns = new OnlineReturn();
                    onlineReturns.OnlineReturnID = new Guid(Convert.ToString(reader["OnlineReturnID"]));
                    onlineReturns.OrderID = new Guid(Convert.ToString(reader["OrderID"]));
                    onlineReturns.ProductID = new Guid(Convert.ToString(reader["ProductID"]));
                    onlineReturns.OrderNumber = Convert.ToInt32(reader["OrderNumber"]);
                    onlineReturns.ProductNumber = Convert.ToInt32(reader["ProductNumber"]);
                    onlineReturns.Purpose = reader["Purpose"].ToString();
                    onlineReturns.QuantityOfReturn = Convert.ToInt32(reader["QuantityOfReturn"]);
                    onlineReturns.RetailerID = new Guid(Convert.ToString(reader["RetailerID"]));
                    onlineReturns.TotalAmount = Convert.ToInt32(reader["TotalAmount"]);
                    onlineReturns.ProductPrice = Convert.ToDouble(reader["ProductPrice"]);
                    onlineReturns.CreationDateTime = DateTime.Parse(reader["CreationDateTime"].ToString());
                    onlineReturns.LastModifiedDateTime = DateTime.Parse(reader["LastModifiedDateTime"].ToString());
                    matchingOnlineReturn1 = onlineReturns;
                }
                sqlConn.Close();

            }
            catch (Exception)
            {

                throw;
            }
            return matchingOnlineReturn;
        }



        /// <summary>
        /// Updates onllineReturn based on OnlineReturnID.
        /// </summary>
        /// <param name="updateOnlineReturn">Represents OnlineReturn details including OnlineReturnID, PurposeOfReturn etc.</param>
        /// <returns>Determinates whether the existing onlineReturn is updated.</returns>
        public override bool UpdateOnlineReturnDAL(OnlineReturn updateOnlineReturn)
        {
            bool onlineReturnUpdated = false;
            try
            {
                //Find OnlineReturn based on OnlineReturnID
                OnlineReturn matchingOnlineReturn = GetOnlineReturnByOnlineReturnIDDAL(updateOnlineReturn.OnlineReturnID);

                if (matchingOnlineReturn != null)
                {
                    //Update onlineReturn details
                    ReflectionHelpers.CopyProperties(updateOnlineReturn, matchingOnlineReturn, new List<string>());
                    matchingOnlineReturn.LastModifiedDateTime = DateTime.Now;

                    SqlConnection sqlConn = new SqlConnection(Properties.Settings.Default.dbCon);
                    try
                    {
                        sqlConn.Open();
                        try
                        {
                            SqlCommand sqlCmd = new SqlCommand("TeamB.UpdateOnlineReturn", sqlConn);


                            sqlCmd.CommandType = CommandType.StoredProcedure;
                            sqlCmd.Parameters.AddWithValue("@onlineReturnID", matchingOnlineReturn.OnlineReturnID);
                            sqlCmd.Parameters.AddWithValue("@orderID", matchingOnlineReturn.OrderID);
                            sqlCmd.Parameters.AddWithValue("@orderNumber", matchingOnlineReturn.OrderNumber);
                            sqlCmd.Parameters.AddWithValue("@productID", matchingOnlineReturn.ProductID);
                            sqlCmd.Parameters.AddWithValue("@productNumber", matchingOnlineReturn.ProductNumber);
                            sqlCmd.Parameters.AddWithValue("@productPrice", matchingOnlineReturn.ProductPrice);
                            sqlCmd.Parameters.AddWithValue("@purpose", matchingOnlineReturn.Purpose);
                            sqlCmd.Parameters.AddWithValue("@quantityOfReturn", matchingOnlineReturn.QuantityOfReturn);
                            sqlCmd.Parameters.AddWithValue("@retailerID", matchingOnlineReturn.RetailerID);
                            sqlCmd.Parameters.AddWithValue("@totalAmount", matchingOnlineReturn.TotalAmount);
                            sqlCmd.Parameters.AddWithValue("@creationDateTime", matchingOnlineReturn.CreationDateTime);
                            sqlCmd.Parameters.AddWithValue("@lastModifiedDateTime", matchingOnlineReturn.LastModifiedDateTime);
                            Int32 isadded = Convert.ToInt32(sqlCmd.ExecuteScalar());
                            if (isadded > 0)
                            {
                                onlineReturnUpdated = true;
                            }
                            else
                            {
                                onlineReturnUpdated = false;

                            }

                            sqlConn.Close();

                        }
                        catch (Exception)
                        {
                            throw;
                        }
                        return (onlineReturnUpdated);
                    }
                    catch (Exception)
                    {
                        throw;
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
            return onlineReturnUpdated;
        }

        /// <summary>
        /// Deletes onlineReturn based on OnlineReturnID.
        /// </summary>
        /// <param name="deleteOnlineReturnID">Represents OnlineReturnID to delete.</param>
        /// <returns>Determinates whether the existing onlineReturn is updated.</returns>
        public override bool DeleteOnlineReturnDAL(Guid deleteOnlineReturnID)
        {
            bool onlineReturnDeleted = false;
            try
            {
                //Find OnlineReturn based on searchOnlineReturnID
                OnlineReturn matchingOnlineReturn = onlineReturnList.Find(
                    (item) => { return item.OnlineReturnID == deleteOnlineReturnID; }
                );

                if (matchingOnlineReturn != null)
                {
                    //Delete OnlineReturn from the collection
                    onlineReturnList.Remove(matchingOnlineReturn);
                    SqlConnection sqlConn = new SqlConnection(Properties.Settings.Default.dbCon);
                    try
                    {
                        sqlConn.Open();
                        try
                        {
                            SqlCommand sqlCmd = new SqlCommand("TeamB.DeleteOnlineReturn", sqlConn);
                            //@salesPersonID,

                            sqlCmd.CommandType = CommandType.StoredProcedure;
                            sqlCmd.Parameters.AddWithValue("@onlineReturnID", matchingOnlineReturn.OnlineReturnID);

                            Int32 isdeleted = Convert.ToInt32(sqlCmd.ExecuteScalar());
                            if (isdeleted > 0)
                            {
                                onlineReturnDeleted = true;
                            }
                            else
                            {
                                onlineReturnDeleted = false;

                            }
                            sqlConn.Close();

                        }
                        catch (Exception)
                        {
                            throw;
                        }
                        return (onlineReturnDeleted);
                    }

                    catch (Exception)
                    {
                        throw;
                    }
                }

            }
            catch (Exception)
            {
                throw;
            }
            return onlineReturnDeleted;
        }


        /// <summary>
        /// Clears unmanaged resources such as db connections or file streams.
        /// </summary>
        public void Dispose()
        {
            //No unmanaged resources currently
        }
    }
}
