﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using Capgemini.GreatOutdoor.Entities;
using Capgemini.GreatOutdoor.Contracts.DALContracts;
using System.Data;

namespace Capgemini.GreatOutdoor.DataAccessLayer
{
    /// <summary>
    /// Contains data access layer methods for inserting, updating orders from ordersList collection.
    /// </summary>
    public class OrderDAL : OrderDALBase, IDisposable
    {
        /// <summary>
        /// Adds new order to ordersList collection.
        /// </summary>
        /// <param name="newOrder">Contains the order details to be added.</param>
        /// <returns>Determinates whether the new order is added.</returns>
        public override (bool, Guid) AddOrderDAL(Order newOrder)
        {
            bool orderAdded = false;
            try
            {
                newOrder.OrderId = Guid.NewGuid();
                newOrder.OrderNumber = ordersList.Count + 1;
                newOrder.DateOfOrder = DateTime.Now;
                newOrder.LastModifiedDateTime = DateTime.Now;
                ordersList.Add(newOrder);
                orderAdded = true;
                SqlConnection sqlConnection = new SqlConnection(Properties.Settings.Default.dbCon);
                sqlConnection.Open();
                string query = "TeamB.AddOrder";
                SqlCommand sqlCommand = new SqlCommand(query);
                sqlCommand.CommandType = CommandType.StoredProcedure;

                //OrderId parameter adding
                SqlParameter paramOrderId = new SqlParameter();
                paramOrderId.ParameterName = "@orderId";
                paramOrderId.Value = newOrder.OrderId;
                paramOrderId.SqlDbType = SqlDbType.UniqueIdentifier;
                sqlCommand.Parameters.Add(paramOrderId);

                //RetailerId parameter adding
                SqlParameter paramRetailerId = new SqlParameter("@retailerId", newOrder.RetailerID);
                paramRetailerId.SqlDbType = SqlDbType.UniqueIdentifier;
                sqlCommand.Parameters.Add(paramRetailerId);

                //adding date of order, total quantity, order amount, last modified date parameters
                sqlCommand.Parameters.AddWithValue("@dateOfOrder", newOrder.DateOfOrder);
                sqlCommand.Parameters.AddWithValue("@totalQuantity", newOrder.TotalQuantity);
                sqlCommand.Parameters.AddWithValue("@orderAmount", newOrder.OrderAmount);
                sqlCommand.Parameters.AddWithValue("@lastModifiedDate", newOrder.LastModifiedDateTime);

                SqlParameter sqlParameter = new SqlParameter();
                sqlParameter.SqlDbType = SqlDbType.Int;
                sqlParameter.Direction = ParameterDirection.ReturnValue;
                sqlCommand.Parameters.Add(sqlParameter);

                sqlConnection.Close();
            }
            catch (Exception)
            {
                throw;
            }
            return (orderAdded, newOrder.OrderId);
        }

        /// <summary>
        /// Constructor for OrderDAL
        /// </summary>
        public OrderDAL()
        {

        }


        /// <summary>
        /// Gets Order based on OrderID.
        /// </summary>
        /// <param name="searchOrderID">Represents OrderID to search.</param>
        /// <returns>Returns Order object.</returns>
        public override Order GetOrderByOrderIDDAL(Guid searchOrderID)
        {
            Order order = null;
            try
            {
                //Find Order based on searchOrderID
                SqlConnection sqlConnection = new SqlConnection(Properties.Settings.Default.dbCon);
                sqlConnection.Open();
                string query = "ViewOrderByOrderID";
                SqlCommand sqlCommand = new SqlCommand(query);
                sqlCommand.Connection = sqlConnection;

                //adding searchOrderId parameter
                SqlParameter paramOrderId = new SqlParameter("@orderId", searchOrderID);
                paramOrderId.SqlDbType = SqlDbType.UniqueIdentifier;
                sqlCommand.Parameters.Add(paramOrderId);

                //sql datareader
                SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
                while (sqlDataReader.Read())
                {
                    order.OrderId = sqlDataReader.GetGuid(0);
                    order.DateOfOrder = sqlDataReader.GetDateTime(1);
                    order.TotalQuantity = sqlDataReader.GetInt32(2);
                    order.OrderAmount = sqlDataReader.GetDouble(3);
                    order.LastModifiedDateTime = sqlDataReader.GetDateTime(4);
                    order.OrderNumber = sqlDataReader.GetInt32(5);
                }
                sqlDataReader.Close();
                sqlConnection.Close();
            }
            catch (Exception)
            {
                throw;
            }
            return order;
        }

        public override Order GetOrderByOrderNumberDAL(double orderNumber)
        {
            Order order = null;
            try
            {
                //Find Order based on searchOrderID
                SqlConnection sqlConnection = new SqlConnection(Properties.Settings.Default.dbCon);
                sqlConnection.Open();
                string query = "ViewOrderByOrderNumber";
                SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
                sqlCommand.Parameters.AddWithValue("@orderNumber", orderNumber);
                SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
                while (sqlDataReader.Read())
                {
                    order.OrderId = sqlDataReader.GetGuid(0);
                    order.DateOfOrder = sqlDataReader.GetDateTime(1);
                    order.TotalQuantity = sqlDataReader.GetInt32(2);
                    order.OrderAmount = sqlDataReader.GetDouble(3);
                    order.LastModifiedDateTime = sqlDataReader.GetDateTime(4);
                    order.OrderNumber = sqlDataReader.GetInt32(5);
                }
                sqlDataReader.Close();
                sqlConnection.Close();
            }
            catch (Exception)
            {
                throw;
            }
            return order;
        }

        public List<Order> GetAllOrders()
        {
            try
            {
                List<Order> orders = new List<Order>();
                SqlConnection sqlConnection = new SqlConnection(Properties.Settings.Default.dbCon);
                string query = "exec GetAllOrders";
                SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
                DataSet dataSet = new DataSet();
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(query, sqlConnection);
                SqlCommandBuilder sqlCommandBuilder = new SqlCommandBuilder(sqlDataAdapter);
                sqlDataAdapter.Fill(dataSet);
                DataRow dataRow;
                for (int i = 0; i < dataSet.Tables[0].Rows.Count; i++)
                {
                    dataRow = dataSet.Tables[0].Rows[i];
                    Order order = new Order();
                    //order.OrderId = dataRow["OrderId"];
                    order.OrderAmount = Convert.ToDouble(dataRow["OrderAmount"]);
                    order.TotalQuantity = Convert.ToInt32(dataRow["TotalQuantity"]);
                    order.DateOfOrder = Convert.ToDateTime(dataRow["DateOfOrder"]);
                    order.LastModifiedDateTime = Convert.ToDateTime(dataRow["LastModifiedDate"]);
                    order.OrderNumber = Convert.ToInt32(dataRow["OrderNumber"]);
                    orders.Add(order);
                }
                return orders;
            }
            catch (Exception)
            {
                throw;
            }
        }

        //to be completed
        public override List<Order> GetOrdersByRetailerIDDAL(Guid searchRetailerID)
        {
            List<Order> matchingOrder = null;
            try
            {
                //Find Order based on searchOrderID
                SqlConnection sqlConnection = new SqlConnection(Properties.Settings.Default.dbCon);
                string query = "exec ViewRetailerOrders";
                SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);

                //RetailerId parameter adding
                SqlParameter paramRetailerId = new SqlParameter("@retailerId", searchRetailerID);
                paramRetailerId.SqlDbType = SqlDbType.UniqueIdentifier;
                sqlCommand.Parameters.Add(paramRetailerId);

                DataSet dataSet = new DataSet();
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(query, sqlConnection);
                SqlCommandBuilder sqlCommandBuilder = new SqlCommandBuilder(sqlDataAdapter);
                sqlDataAdapter.Fill(dataSet);
                DataRow dataRow;
                for (int i = 0; i < dataSet.Tables[0].Rows.Count; i++)
                {
                    dataRow = dataSet.Tables[0].Rows[i];
                    Order order = new Order();
                    //order.OrderId = dataRow["OrderId"];
                    order.OrderAmount = Convert.ToDouble(dataRow["OrderAmount"]);
                    order.TotalQuantity = Convert.ToInt32(dataRow["TotalQuantity"]);
                    order.DateOfOrder = Convert.ToDateTime(dataRow["DateOfOrder"]);
                    order.LastModifiedDateTime = Convert.ToDateTime(dataRow["LastModifiedDate"]);
                    order.OrderNumber = Convert.ToInt32(dataRow["OrderNumber"]);
                    matchingOrder.Add(order);
                }
                return matchingOrder;

            }
            catch (Exception)
            {
                throw;
            }

        }

        /// <summary>
        /// Updates Order based on OrderID.
        /// </summary>
        /// <param name="updateOrder">Represents Order details like OrderID</param>
        /// <returns>Determinates whether the existing Order is updated.</returns>


        public override bool UpdateOrderDAL(Order updateOrder)
        {
            bool orderUpdated = false;
            try
            {
                //Find Order based on OrderID
                Order order = GetOrderByOrderIDDAL(updateOrder.OrderId);

                if (order != null)
                {
                    //Update order details
                    SqlConnection sqlConnection = new SqlConnection(Properties.Settings.Default.dbCon);
                    sqlConnection.Open();
                    string query = "UpdateOrder";
                    SqlCommand sqlCommand = new SqlCommand(query);
                    sqlCommand.Connection = sqlConnection;
                    sqlCommand.CommandType = CommandType.StoredProcedure;

                    //adding OrderId parameter
                    SqlParameter paramOrderId = new SqlParameter("@orderId", updateOrder.OrderId);
                    paramOrderId.SqlDbType = SqlDbType.UniqueIdentifier;
                    sqlCommand.Parameters.Add(paramOrderId);

                    sqlCommand.Parameters.AddWithValue("@totalAmount", order.OrderAmount);
                    sqlCommand.Parameters.AddWithValue("@totalQuantity", order.TotalQuantity);
                    sqlCommand.Parameters.AddWithValue("@lastModifiedDate", order.LastModifiedDateTime);
                    sqlConnection.Close();
                    orderUpdated = true;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return orderUpdated;
        }



        /// <summary>
        /// Deletes order based on OrderID.
        /// </summary>
        /// <param name="deleteOrderID">Represents OrderID to delete.</param>
        /// <returns>Determinates whether the existing order is updated.</returns>
        public override bool DeleteOrderDAL(Guid deleteOrderID)
        {
            bool orderDeleted = false;
            try
            {
                //Find Order based on orderID
                //Order matchingOrder = ordersList.Find(
                //    (item) => { return item.OrderId == deleteOrderID; }
                //);

                //if (matchingOrder != null)
                //{
                //Delete order from the collection
                SqlConnection sqlConnection = new SqlConnection(Properties.Settings.Default.dbCon);
                sqlConnection.Open();
                string query = "DeleteOrder";
                SqlCommand sqlCommand = new SqlCommand(query);
                sqlCommand.CommandType = CommandType.StoredProcedure;

                //adding OrderId parameter
                SqlParameter paramOrderId = new SqlParameter("@orderId", deleteOrderID);
                paramOrderId.SqlDbType = SqlDbType.UniqueIdentifier;
                sqlCommand.Parameters.Add(paramOrderId);

                sqlConnection.Close();
                //}
            }
            catch (Exception)
            {
                throw;
            }
            return orderDeleted;
        }

        /// <summary>
        /// Clears unmanaged resources such as db connections or file streams.
        /// </summary>
        public void Dispose()
        {
            //No unmanaged resources currently
        }
    }
}