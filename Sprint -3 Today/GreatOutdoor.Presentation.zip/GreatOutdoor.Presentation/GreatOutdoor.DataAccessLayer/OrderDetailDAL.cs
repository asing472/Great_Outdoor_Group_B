﻿using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;
using Capgemini.GreatOutdoor.Entities;
using Capgemini.GreatOutdoor.Contracts;
using Capgemini.GreatOutdoor.Helpers;
using System.Data.SqlClient;
using System.Data;

namespace Capgemini.GreatOutdoor.DataAccessLayer
{

    /// <summary>
    /// Contains data access layer methods for inserting, updating order details from orderDetails collection.
    /// </summary>
    public class OrderDetailDAL : OrderDetailDALBase, IDisposable
    {
        // Adding Connection to database
        private SqlConnection sqlConn = new SqlConnection(Properties.Settings.Default.dbCon);


        /// <summary>
        /// Adds new orderdetails to orderdetails List collection.
        /// </summary>
        /// <param name="newOrder">Contains the order details to be added.</param>
        /// <returns>Determinates whether the new order is added.</returns>
        public override (bool, Guid) AddOrderDetailsDAL(OrderDetail newOrderDetail)
        {
            bool orderDetailAdded = false;
            try
            {
                newOrderDetail.OrderDetailId = Guid.NewGuid();
                newOrderDetail.DateOfOrder = DateTime.Now;
                newOrderDetail.LastModifiedDateTime = DateTime.Now;
                sqlConn.Open();
                string query;

                query = "TeamB.AddOrderDetails";
                SqlCommand sqlcmd = new SqlCommand(query, sqlConn);
                sqlcmd.CommandType = CommandType.StoredProcedure;

                //assigning order id address id
                SqlParameter paramOrderId = new SqlParameter();
                paramOrderId.ParameterName = "@orderId";
                paramOrderId.Value = newOrderDetail.OrderId;
                paramOrderId.DbType = DbType.Guid;
                sqlcmd.Parameters.Add(paramOrderId);
                //Assigning OrderDetailID
                //sqlcmd.Parameters.AddWithValue("@orderDetailID", newOrderDetail.OrderDetailId).DbType = DbType.Guid;
                SqlParameter paramOrderDetailId = new SqlParameter();
                paramOrderDetailId.ParameterName = "@orderDetailID";
                paramOrderDetailId.Value = newOrderDetail.OrderId;
                paramOrderDetailId.SqlDbType = SqlDbType.UniqueIdentifier;
                sqlcmd.Parameters.Add(paramOrderDetailId);

                SqlParameter paramProductId = new SqlParameter("@productId", newOrderDetail.ProductID);
                paramProductId.SqlDbType = SqlDbType.UniqueIdentifier;
                sqlcmd.Parameters.Add(paramProductId);
                //assigning other parameters
                sqlcmd.Parameters.AddWithValue("@productQuantityOrdered", newOrderDetail.ProductQuantityOrdered);
                sqlcmd.Parameters.AddWithValue("@productPrice", newOrderDetail.ProductPrice);
                //adding address id
                SqlParameter addressIdParam = new SqlParameter("@addressId", newOrderDetail.AddressId);
                addressIdParam.SqlDbType = SqlDbType.UniqueIdentifier;
                sqlcmd.Parameters.Add(addressIdParam);
                sqlcmd.Parameters.AddWithValue("@totalAmount", newOrderDetail.TotalAmount);
                sqlcmd.Parameters.AddWithValue("@dateOfOrder", newOrderDetail.DateOfOrder);
                sqlcmd.Parameters.AddWithValue("@lastModifiedDate", newOrderDetail.LastModifiedDateTime);
                sqlcmd.ExecuteNonQuery();
                orderDetailAdded = true;
            }
            catch (Exception)
            {
                throw;
            }
            return (orderDetailAdded, newOrderDetail.OrderDetailId);
        }

        /// <summary>
        /// Constructor for OrderDetailsDAL
        /// </summary>
        public OrderDetailDAL()
        {

        }


        /// <summary>
        /// Gets OrderDetail based on OrderID.
        /// </summary>
        /// <param name="searchOrderID">Represents OrderID to search.</param>
        /// <returns>Returns OrderDetail object.</returns>
        public override List<OrderDetail> GetOrderDetailsByOrderIDDAL(Guid searchOrderID)
        {
            List<OrderDetail> matchingOrderDetail = new List<OrderDetail>();
            try
            {
                ///Create object of sqlCommand
                SqlCommand sqlCommand = new SqlCommand("ViewOrderDetailsByOrderID", sqlConn);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.Parameters.AddWithValue("@orderId", searchOrderID).DbType = DbType.Guid;
                //Create object of sqlAdapter
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
                sqlDataAdapter.SelectCommand = sqlCommand;

                //Create DataSet
                DataSet dataSet = new DataSet();
                sqlDataAdapter.Fill(dataSet);

                //Load into Collection
                DataRow dataRow;
                for (int i = 0; i < dataSet.Tables[0].Rows.Count; i++)
                {
                    dataRow = dataSet.Tables[0].Rows[i];
                    OrderDetail orderDetail = new OrderDetail();

                    orderDetail.OrderDetailId = new Guid(Convert.ToString(dataRow["OrderDetailID"]));
                    orderDetail.OrderId = new Guid(Convert.ToString(dataRow["OrderID"]));
                    orderDetail.ProductID = new Guid(Convert.ToString(dataRow["ProductID"]));
                    orderDetail.AddressId = new Guid(Convert.ToString(dataRow["AddressId"]));
                    orderDetail.ProductQuantityOrdered = Convert.ToInt32(dataRow["ProductQuantityOrdered"]);
                    orderDetail.ProductPrice = Convert.ToDouble(dataRow["ProductPrice"]);
                    orderDetail.TotalAmount = Convert.ToDouble(dataRow["TotalAmount"]);
                    matchingOrderDetail.Add(orderDetail);

                }

            }
            catch (Exception)
            {
                throw;
            }
            return matchingOrderDetail;
        }

        public override OrderDetail GetOrderDetailByOrderDetailIDDAL(Guid searchOrderDetailID)
        {
            OrderDetail matchingOrderDetail = null;
            try
            {
                //Create object of sqlCommand
                SqlCommand sqlCommand = new SqlCommand("ViewOrderDetailByOrderDetailID", sqlConn);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.Parameters.AddWithValue("@orderDetailsId", searchOrderDetailID);
                //Create object of sqlAdapter
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
                sqlDataAdapter.SelectCommand = sqlCommand;
                //Create DataBase
                DataSet dataSet = new DataSet();
                sqlDataAdapter.Fill(dataSet);

                DataRow dataRow;
                dataRow = dataSet.Tables[0].Rows[0];

                matchingOrderDetail.OrderDetailId = new Guid(Convert.ToString(dataRow["OfflineOrderDetailID"]));
                matchingOrderDetail.OrderId = new Guid(Convert.ToString(dataRow["OfflineOrderID"]));
                matchingOrderDetail.ProductID = new Guid(Convert.ToString(dataRow["ProductID"]));
                matchingOrderDetail.AddressId = new Guid(Convert.ToString(dataRow["AddressId"]));
                matchingOrderDetail.ProductQuantityOrdered = Convert.ToInt32(dataRow["ProductQuantityOrdered"]);
                matchingOrderDetail.ProductPrice = Convert.ToDouble(dataRow["ProductPrice"]);
                matchingOrderDetail.TotalAmount = Convert.ToDouble(dataRow["TotalAmount"]);

            }
            catch (Exception)
            {
                throw;
            }
            return matchingOrderDetail;
        }

        /// <summary>
        /// Updates OrderDetail based on OrderID.
        /// </summary>
        /// <param name="updateOrderDetail">Represents Order details like OrderID</param>
        /// <returns>Determinates whether the existing OrderDetail is updated.</returns>


        public override bool UpdateOrderDetailsDAL(OrderDetail updateOrderDetail)
        {
            bool orderDetailUpdated = false;
            try
            {
                //Find OrderDetail based on OrderID
                OrderDetail matchingOrderDetail = GetOrderDetailByOrderDetailIDDAL(updateOrderDetail.OrderDetailId);

                if (matchingOrderDetail != null)
                {
                    sqlConn.Open();
                    string query;

                    query = "UpdateOrderDetails";
                    SqlCommand sqlcmd = new SqlCommand(query, sqlConn);
                    sqlcmd.CommandType = CommandType.StoredProcedure;

                    //Assigning OfflineOrderDetailID
                    sqlcmd.Parameters.AddWithValue("@orderDetailid", updateOrderDetail.OrderDetailId).DbType = DbType.Guid;
                    sqlcmd.Parameters.AddWithValue("@productQuantityOrdered", updateOrderDetail.ProductQuantityOrdered);
                    sqlcmd.Parameters.AddWithValue("@addressId", updateOrderDetail.AddressId);
                    sqlcmd.Parameters.AddWithValue("@totalAmount", updateOrderDetail.TotalAmount);
                    sqlcmd.Parameters.AddWithValue("@lastModifiedDate", updateOrderDetail.LastModifiedDateTime);
                    sqlcmd.ExecuteNonQuery();
                    orderDetailUpdated = true;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return orderDetailUpdated;
        }

        /// <summary>
        /// gives wheather the order is dispatched or not
        /// </summary>
        /// <param name="orderId"></param>
        /// <returns>determines wheather the order is dispatched</returns>
        public override bool UpdateOrderDispatchedStatusDAL(Guid orderId)
        {
            bool orderDispatched = false;
            try
            {
                //Find OrderDetail based on orderID
                OrderDetail matchingOrder = orderDetailsList.Find(
                    (item) => { return item.OrderId == orderId; }
                );
                if (matchingOrder != null)
                {
                    //order is dispatched
                    if (matchingOrder.DateOfOrder.AddDays(2) >= DateTime.Now)
                        orderDispatched = true;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return orderDispatched;
        }


        /// <summary>
        /// gives wheather the order is shipped or not
        /// </summary>
        /// <param name="orderId"></param>
        /// <returns>determines wheather the order is shipped</returns
        public override bool UpdateOrderShippedStatusDAL(Guid orderId)
        {
            bool orderShipped = false;
            try
            {
                //Find OrderDetail based on orderID
                OrderDetail matchingOrder = orderDetailsList.Find(
                    (item) => { return item.OrderId == orderId; }
                );
                if (matchingOrder != null)
                {
                    //order is shipped
                    if (matchingOrder.DateOfOrder.AddDays(5) >= DateTime.Now && matchingOrder.DateOfOrder.AddDays(2) < DateTime.Now)
                        orderShipped = true;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return orderShipped;
        }


        /// <summary>
        /// gives wheather the order is delivered or not
        /// </summary>
        /// <param name="orderId"></param>
        /// <returns>determines wheather the order is delivered</returns
        public override bool UpdateOrderDeliveredStatusDAL(Guid orderId)
        {
            bool orderDelivered = false;
            try
            {
                //Find OrderDetail based on orderID
                OrderDetail matchingOrder = orderDetailsList.Find(
                    (item) => { return item.OrderId == orderId; }
                );
                if (matchingOrder != null)
                {
                    //order is delivered
                    if (matchingOrder.DateOfOrder.AddDays(6) >= DateTime.Now)
                        orderDelivered = true;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return orderDelivered;
        }

        /// <summary>
        /// Deletes OrderDetail based on OrderID.
        /// </summary>
        /// <param name="deleteOrderID">Represents OrderID to delete.</param>
        /// <returns>Determinates whether the existing OrderDetail is updated.</returns>
        public override bool DeleteOrderDetailsDAL(Guid deleteOrderDetailID)
        {
            bool orderDetailDeleted = false;
            try
            {
                sqlConn.Open();
                string query;

                query = "DeleteOrderDetails";
                SqlCommand sqlcmd = new SqlCommand(query, sqlConn);
                sqlcmd.CommandType = CommandType.StoredProcedure;

                //Assigning OrderDetailID

                sqlcmd.Parameters.AddWithValue("@orderDetailID", deleteOrderDetailID).DbType = DbType.Guid;
                sqlcmd.ExecuteNonQuery();
                orderDetailDeleted = true;

            }
            catch (Exception)
            {
                throw;
            }
            return orderDetailDeleted;
        }

        /// <summary>
        /// Clears unmanaged resources such as db connections or file streams.
        /// </summary>
        public void Dispose()
        {
            //No unmanaged resources currently
        }
    }
}