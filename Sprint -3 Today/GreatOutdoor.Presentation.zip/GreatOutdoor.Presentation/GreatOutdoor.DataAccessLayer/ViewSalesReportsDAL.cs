﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Capgemini.GreatOutdoor.Entities;
using System.Data.SqlClient;
using System.Data;

namespace Capgemini.GreatOutdoor.DataAccessLayer
{
    public class ViewSalesReportsDAL
    {
        /// <summary>
        /// lists all the sales persons reports
        /// </summary>
        /// <returns></returns>
        public async Task<List<ViewSalesReports>> ViewAllSalesReportsDAL()
        {
            List<ViewSalesReports> viewSales;
            SqlConnection sqlConn = new SqlConnection(Properties.Settings.Default.dbCon);
            try
            {
                //create object of sql command
                SqlCommand sqlcmd = new SqlCommand();
                sqlcmd.CommandText = "TeamB.ViewsalesReportsproc";
                sqlcmd.Connection = sqlConn;
                sqlcmd.CommandType = CommandType.StoredProcedure;

                //create object of sql data adapter
                SqlDataAdapter sqladap = new SqlDataAdapter();
                sqladap.SelectCommand = sqlcmd;

                //create database
                DataSet ds = new DataSet();
                sqladap.Fill(ds);

                //loading into collection

                List<ViewSalesReports> viewSaleslist = new List<ViewSalesReports>();
                DataRow dataRow;
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    dataRow = ds.Tables[0].Rows[i];
                    Guid sid = (Guid)(dataRow[0]);
                    string sname = Convert.ToString(dataRow[1]);
                    int custcount = Convert.ToInt32(dataRow[2]);
                    int itemcount = Convert.ToInt32(dataRow[3]);
                    decimal Amount = Convert.ToDecimal(dataRow[4]);
                    ViewSalesReports salesreport = new ViewSalesReports();
                    salesreport.SalespersonID = sid;
                    salesreport.SalespersonName = sname;
                    salesreport.OfflinesalesCount = custcount;
                    salesreport.Totalitemquantity = itemcount;
                    salesreport.TotalAmount = Amount;
                    if (salesreport.TotalAmount > 10000)
                    {
                        salesreport.Target = "exceeded";
                    }
                    else if ((salesreport.TotalAmount < 10000) && (salesreport.TotalAmount > 1000))
                    {
                        salesreport.Target = "Met";
                    }
                    else { salesreport.Target = "NotMet"; }

                    viewSaleslist.Add(salesreport);
                }
                viewSales = viewSaleslist;
            }
            catch (Exception)
            {
                throw;
            }
            return viewSales;

        }

    }
}
