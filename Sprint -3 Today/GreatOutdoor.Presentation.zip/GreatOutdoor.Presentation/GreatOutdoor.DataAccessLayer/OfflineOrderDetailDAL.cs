﻿using System;
using System.Collections.Generic;
using System.Text;
using Capgemini.GreatOutdoor.Contracts.DALContracts;
using Capgemini.GreatOutdoor.Entities;
using Capgemini.GreatOutdoor.Exceptions;
using Capgemini.GreatOutdoor.Helpers;
using System.Data;
using System.Data.SqlClient;


namespace Capgemini.GreatOutdoor.DataAccessLayer
{   //Developed by Abhishek




    /// <summary>
    /// Contains data access layer methods for inserting, updating, deleting systemUsers from OfflineOrderDetail collection.
    /// </summary>
    public class OfflineOrderDetailDAL : OfflineOrderDetailDALBase, IDisposable

    {
        // Adding Connection to database
        SqlConnection sqlConn = new SqlConnection(Properties.Settings.Default.dbCon);
        public static List<OfflineOrderDetail> OfflineOrderDetailList1 = new List<OfflineOrderDetail>();

        /// <summary>
        /// Adds new Offline Order to OfflineOrderDetail collection.
        /// </summary>
        /// <param name="newOfflineOrderDetail">Contains the Offline Orders Detail to be added.</param>
        /// <returns>Determinates whether the new Offline Order is added.</returns>


        public (bool, Guid) AddOfflineOrderDetailDAL(OfflineOrderDetail newOfflineOrderDetail)
        {
            bool OfflineOrderDetailAdded = false;
            Guid offlineOrderDetailID;
            try
            {
                //opening connection
                offlineOrderDetailID = Guid.NewGuid();
                sqlConn.Open();
                string query;

                query = "TeamB.AddOfflineOrderDetail";
                SqlCommand sqlcmd = new SqlCommand(query, sqlConn);
                sqlcmd.CommandType = CommandType.StoredProcedure;

                //Assigning OfflineOrderDetailID

                sqlcmd.Parameters.AddWithValue("offlineOrderDetailID", offlineOrderDetailID).DbType = DbType.Guid;

                SqlParameter offlineOrderIDParam = new SqlParameter("@offlineOrderID", newOfflineOrderDetail.OfflineOrderID);
                offlineOrderIDParam.DbType = DbType.Guid;
                sqlcmd.Parameters.Add(offlineOrderIDParam);

                SqlParameter productIDParam = new SqlParameter("@productID", newOfflineOrderDetail.ProductID);
                productIDParam.DbType = DbType.Guid;
                sqlcmd.Parameters.Add(productIDParam);



                sqlcmd.Parameters.AddWithValue("@productName", newOfflineOrderDetail.ProductName);
                sqlcmd.Parameters.AddWithValue("@Quantity", newOfflineOrderDetail.Quantity);
                sqlcmd.Parameters.AddWithValue("@unitPrice", newOfflineOrderDetail.UnitPrice);
                sqlcmd.Parameters.AddWithValue("@totalPrice", newOfflineOrderDetail.TotalPrice);

                sqlcmd.ExecuteNonQuery();

                OfflineOrderDetailAdded = true;
            }
            catch (SystemException ex)
            {
                throw new OfflineOrderException(ex.Message);
            }
            finally
            {
                //Connection closed
                sqlConn.Close();
            }
            return (OfflineOrderDetailAdded, offlineOrderDetailID);

        }
        // <summary>
        /// Gets all offline orders from the collection.
        /// </summary>
        /// <returns>OrderDetails list of all offline order.</returns>
        public List<OfflineOrderDetail> GetAllOfflineOrderDetailDAL()
        {
            //Create object of sqlCommand
            SqlCommand sqlCommand = new SqlCommand("GetAllOfflineOrderDetail", sqlConn);
            sqlCommand.CommandType = CommandType.StoredProcedure;

            //Create object of sqlAdapter
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
            sqlDataAdapter.SelectCommand = sqlCommand;

            //Create DataBase
            DataSet dataSet = new DataSet();
            sqlDataAdapter.Fill(dataSet);

            //Load into Collection
            List<OfflineOrderDetail> offlineOrderDetailList = new List<OfflineOrderDetail>();
            DataRow dataRow;
            for (int i = 0; i < dataSet.Tables[0].Rows.Count; i++)
            {
                dataRow = dataSet.Tables[0].Rows[i];
                Guid oodID = new Guid(Convert.ToString(dataRow["OfflineOrderDetailID"]));
                Guid ooID = new Guid(Convert.ToString(dataRow["OfflineOrderID"]));
                Guid proID = new Guid(Convert.ToString(dataRow["ProductID"]));
                string proName = Convert.ToString(dataRow["ProductName"]);
                int quant = Convert.ToInt32(dataRow["Quantity"]);
                double unitpri = Convert.ToDouble(dataRow["UnitPrice"]);
                double totalpri = Convert.ToDouble(dataRow["TotalPrice"]);

                OfflineOrderDetail tempofflineOrderDetail = new OfflineOrderDetail();
                tempofflineOrderDetail.OfflineOrderDetailID = oodID;
                tempofflineOrderDetail.OfflineOrderID = ooID;
                tempofflineOrderDetail.ProductID = proID;
                tempofflineOrderDetail.ProductName = proName;
                tempofflineOrderDetail.Quantity = quant;
                tempofflineOrderDetail.UnitPrice = unitpri;
                tempofflineOrderDetail.TotalPrice = totalpri;

                offlineOrderDetailList.Add(tempofflineOrderDetail);

            }

            return offlineOrderDetailList;
        }
        /// <summary>
        /// Gets Offline Order based on OfflineOrderDetailID.
        /// </summary>
        /// <param name="searchOfflineOrderDetailID">Represents OfflineOrderDetailID to search.</param>
        /// <returns>OrderDetails SystemUser object.</returns>
        public OfflineOrderDetail GetOfflineOrderDetailByOfflineOrderDetailIDDAL(Guid searchOfflineOrderDetailID)
        {
            OfflineOrderDetail tempofflineOrderDetail = new OfflineOrderDetail();
            try
            {
                //Create object of sqlCommand
                SqlCommand sqlCommand = new SqlCommand("GetOfflineOrderDetailByOfflineOrderDetailID", sqlConn);
                sqlCommand.CommandType = CommandType.StoredProcedure;



                //Create object of sqlAdapter
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
                sqlDataAdapter.SelectCommand = sqlCommand;

                //Create DataBase
                DataSet dataSet = new DataSet();
                sqlDataAdapter.Fill(dataSet);

                //Load into Collection

                DataRow dataRow;

                dataRow = dataSet.Tables[0].Rows[0];
                Guid oodID = new Guid(Convert.ToString(dataRow["OfflineOrderDetailID"]));
                Guid ooID = new Guid(Convert.ToString(dataRow["OfflineOrderID"]));
                Guid proID = new Guid(Convert.ToString(dataRow["ProductID"]));
                string proName = Convert.ToString(dataRow["ProductName"]);
                int quant = Convert.ToInt32(dataRow["Quantity"]);
                double unitpri = Convert.ToDouble(dataRow["UnitPrice"]);
                double totalpri = Convert.ToDouble(dataRow["TotalPrice"]);


                SqlParameter offlineOrderIDParam = new SqlParameter("@offlineOrderID", searchOfflineOrderDetailID);
                offlineOrderIDParam.DbType = DbType.Guid;
                sqlCommand.Parameters.Add(offlineOrderIDParam);


                tempofflineOrderDetail.OfflineOrderDetailID = oodID;
                tempofflineOrderDetail.OfflineOrderID = ooID;
                tempofflineOrderDetail.ProductID = proID;
                tempofflineOrderDetail.ProductName = proName;
                tempofflineOrderDetail.Quantity = quant;
                tempofflineOrderDetail.UnitPrice = unitpri;
                tempofflineOrderDetail.TotalPrice = totalpri;






            }
            catch (Exception)
            {
                throw;
            }
            return tempofflineOrderDetail;
        }


        public List<OfflineOrderDetail> GetOfflineOrderDetailByOfflineOrderIDDAL(Guid offlineOrderID)
        {
            List<OfflineOrderDetail> offlineOrderDetailList = new List<OfflineOrderDetail>();
            try
            {
                //Create object of sqlCommand
                SqlCommand sqlCommand = new SqlCommand("GetOfflineOrderDetailByOfflineOrderID", sqlConn);
                sqlCommand.CommandType = CommandType.StoredProcedure;



                //Create object of sqlAdapter
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
                sqlDataAdapter.SelectCommand = sqlCommand;

                //Create DataBase
                DataSet dataSet = new DataSet();
                sqlDataAdapter.Fill(dataSet);

                SqlParameter offlineOrderIDParam = new SqlParameter("@offlineOrderID", offlineOrderID);
                offlineOrderIDParam.DbType = DbType.Guid;
                sqlCommand.Parameters.Add(offlineOrderIDParam);


                //Load into Collection

                DataRow dataRow;
                for (int i = 0; i < dataSet.Tables[0].Rows.Count; i++)
                {
                    dataRow = dataSet.Tables[0].Rows[i];
                    Guid oodID = new Guid(Convert.ToString(dataRow["OfflineOrderDetailID"]));
                    Guid ooID = new Guid(Convert.ToString(dataRow["OfflineOrderID"]));
                    Guid proID = new Guid(Convert.ToString(dataRow["ProductID"]));
                    string proName = Convert.ToString(dataRow["ProductName"]);
                    int quant = Convert.ToInt32(dataRow["Quantity"]);
                    double unitpri = Convert.ToDouble(dataRow["UnitPrice"]);
                    double totalpri = Convert.ToDouble(dataRow["TotalPrice"]);

                    OfflineOrderDetail tempofflineOrderDetail = new OfflineOrderDetail();


                    tempofflineOrderDetail.OfflineOrderDetailID = oodID;
                    tempofflineOrderDetail.OfflineOrderID = ooID;
                    tempofflineOrderDetail.ProductID = proID;
                    tempofflineOrderDetail.ProductName = proName;
                    tempofflineOrderDetail.Quantity = quant;
                    tempofflineOrderDetail.UnitPrice = unitpri;
                    tempofflineOrderDetail.TotalPrice = totalpri;

                    offlineOrderDetailList.Add(tempofflineOrderDetail);

                }


            }
            catch (SystemException ex)
            {
                throw new OfflineOrderException(ex.Message);
            }
            return offlineOrderDetailList;
        }


        public bool UpdateOfflineOrderDetailDAL(OfflineOrderDetail updateOfflineOrderDetail)
        {
            bool OfflineOrderDetailUpdated = false;
            try
            {
                sqlConn.Open();
                string query;

                query = "UpdateOfflineOrderDetail";
                SqlCommand sqlcmd = new SqlCommand(query, sqlConn);
                sqlcmd.CommandType = CommandType.StoredProcedure;

                //Assigning OfflineOrderDetailID

                sqlcmd.Parameters.AddWithValue("@offlineOrderDetailID", updateOfflineOrderDetail.OfflineOrderDetailID).DbType = DbType.Guid;
                sqlcmd.Parameters.AddWithValue("@Quantity", updateOfflineOrderDetail.Quantity);
                sqlcmd.Parameters.AddWithValue("@totalPrice", updateOfflineOrderDetail.TotalPrice);

                sqlcmd.ExecuteNonQuery();

                OfflineOrderDetailUpdated = true;
            }
            catch (SystemException ex)
            {
                throw new OfflineOrderException(ex.Message);
            }
            finally
            {
                sqlConn.Close();
            }
            return OfflineOrderDetailUpdated;

        }
        /// <summary>
        /// Deletes OfflineOrderDetail based on OfflineOrderDetailID.
        /// </summary>
        /// <param name="deleteOfflineOrderDetailID">Represents OfflineOrderDetailID to delete.</param>
        /// <returns>Determinates whether the existing OfflineOrderDetail is deleted.</returns>
        public bool DeleteOfflineOrderDetailDAL(Guid deleteOfflineOrderDetailID)
        {
            bool OfflineOrderDetailDeleted = false;
            try
            {
                sqlConn.Open();
                string query;

                query = "DeleteOfflineOrderDetail";
                SqlCommand sqlcmd = new SqlCommand(query, sqlConn);
                sqlcmd.CommandType = CommandType.StoredProcedure;

                //Assigning OfflineOrderDetailID

                sqlcmd.Parameters.AddWithValue("@offlineOrderDetailID", deleteOfflineOrderDetailID).DbType = DbType.Guid;


                sqlcmd.ExecuteNonQuery();

                OfflineOrderDetailDeleted = true;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                sqlConn.Close();
            }
            return OfflineOrderDetailDeleted;
        }

        /// <summary>
        /// Clears unmanaged resources such as db connections or file streams.
        /// </summary>
        public void Dispose()
        {
            //No unmanaged resources currently
        }
    }

}