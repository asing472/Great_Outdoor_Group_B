﻿using System;
using System.Collections.Generic;
using System.Text;
using Capgemini.GreatOutdoor.Entities;
using Capgemini.GreatOutdoor.Exceptions;
using Capgemini.GreatOutdoor.Contracts.DALContracts;
using Capgemini.GreatOutdoor.Helpers;
using System.Data.SqlClient;
using System.Data;

namespace Capgemini.GreatOutdoor.DataAccessLayer

{/// <summary>
 /// Contains data access layer methods for inserting, updating, deleting systemUsers from OfflineOrder collection.
 /// </summary>
    public class OfflineOrderDAL : OfflineOrderDALBase, IDisposable

    {
        SqlConnection sqlConnection = new SqlConnection(Properties.Settings.Default.dbCon);
        public static List<OfflineOrder> OfflineOrderList1 = new List<OfflineOrder>();

        /// <summary>
        /// Adds new Offline Order to OfflineOrder collection.
        /// </summary>
        /// <param name="newOfflineOrder">Contains the Offline Orders details to be added.</param>
        /// <returns>Determinates whether the new Offline Order is added.</returns>
        public (bool, Guid) AddOfflineOrderDAL(OfflineOrder newOfflineOrder)
        {
            bool OfflineOrderAdded = false;
            Guid OfflineOrderID;
            try
            {

                OfflineOrderID = Guid.NewGuid();
                newOfflineOrder.OfflineOrderID = OfflineOrderID;

                sqlConnection.Open();
                string query = "TeamB.AddOfflineOrder";
                SqlCommand sqlCommand = new SqlCommand(query);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.Parameters.AddWithValue("@retailerID", newOfflineOrder.RetailerID).DbType = DbType.Guid;
                sqlCommand.Parameters.AddWithValue("@offlineOrderID", newOfflineOrder.OfflineOrderID).DbType = DbType.Guid;
                sqlCommand.Parameters.AddWithValue("@salesPersonID", newOfflineOrder.SalesPersonID).DbType = DbType.Guid;
                sqlCommand.Parameters.AddWithValue("@totalQuantity", newOfflineOrder.TotalQuantity);
                sqlCommand.Parameters.AddWithValue("@totalOrderAmount", newOfflineOrder.TotalOrderAmount);
                sqlConnection.Close();
                OfflineOrderAdded = true;
            }
            catch (SystemException ex)
            {
                throw new OfflineOrderException(ex.Message);
            }
            return (OfflineOrderAdded, OfflineOrderID);

        }
        // <summary>
        /// Gets all offline orders from the collection.
        /// </summary>
        /// <returns>Returns list of all offline order.</returns>
        public List<OfflineOrder> GetAllOfflineOrdersDAL()
        {
            List<OfflineOrder> searchOfflineOrder = new List<OfflineOrder>();
            // Create object of sqlCommand
            SqlCommand sqlCommand = new SqlCommand("TeamB.GetAllOfflineOrder", sqlConnection);
            sqlCommand.CommandType = CommandType.StoredProcedure;


            //Create object of sqlAdapter
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
            sqlDataAdapter.SelectCommand = sqlCommand;

            //Create DataBase
            DataSet dataSet = new DataSet();
            sqlDataAdapter.Fill(dataSet);

            //Load into Collection

            DataRow dataRow;
            for (int i = 0; i < dataSet.Tables[0].Rows.Count; i++)
            {
                dataRow = dataSet.Tables[0].Rows[i];

                OfflineOrder tempofflineOrder = new OfflineOrder();

                tempofflineOrder.OfflineOrderID = new Guid(Convert.ToString(dataRow["OfflineOrderID"]));
                tempofflineOrder.RetailerID = new Guid(Convert.ToString(dataRow["RetailerID"]));
                tempofflineOrder.SalesPersonID = new Guid(Convert.ToString(dataRow["SalesPersonID"]));
                tempofflineOrder.TotalQuantity = Convert.ToInt32(dataRow["TotalQuantity"]);
                tempofflineOrder.TotalOrderAmount = Convert.ToDouble(dataRow["TotalOrderAmount"]);


                searchOfflineOrder.Add(tempofflineOrder);

            }
            sqlConnection.Close();
            return searchOfflineOrder;

        }
        /// <summary>
        /// Gets Offline Order based on OfflineOrderID.
        /// </summary>
        /// <param name="searchOfflineOrderID">Represents OfflineOrderID to search.</param>
        /// <returns>Returns SystemUser object.</returns>
        public OfflineOrder GetOfflineOrderByOfflineOrderIDDAL(Guid searchOfflineOrderID)
        {
            OfflineOrder matchingOfflineOrder = new OfflineOrder();
            try
            {

                // Create object of sqlCommand
                SqlCommand sqlCommand = new SqlCommand("TeamB.GetOfflineOrderByOfflineOrderID", sqlConnection);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                SqlParameter OfflineOrderIDParam = new SqlParameter("@offlinerOrderid", searchOfflineOrderID);
                OfflineOrderIDParam.DbType = DbType.Guid;
                sqlCommand.Parameters.Add(OfflineOrderIDParam);




                //Create object of sqlAdapter
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
                sqlDataAdapter.SelectCommand = sqlCommand;

                //Create DataBase
                DataSet dataSet = new DataSet();
                sqlDataAdapter.Fill(dataSet);

                //Load into Collection

                DataRow dataRow;
                dataRow = dataSet.Tables[0].Rows[0];

                matchingOfflineOrder.OfflineOrderID = new Guid(Convert.ToString(dataRow["OfflineOrderID"]));
                matchingOfflineOrder.RetailerID = new Guid(Convert.ToString(dataRow["RetailerID"]));
                matchingOfflineOrder.SalesPersonID = new Guid(Convert.ToString(dataRow["SalesPersonID"]));
                matchingOfflineOrder.TotalQuantity = Convert.ToInt32(dataRow["TotalQuantity"]);
                matchingOfflineOrder.TotalOrderAmount = Convert.ToDouble(dataRow["TotalOrderAmount"]);

                sqlConnection.Close();

            }
            catch (Exception)
            {
                throw;
            }
            return matchingOfflineOrder;
        }

        /// <summary>
        /// Get list of Offline orders using retailerId
        /// </summary>
        /// <param name="RetailerID">Using Retailer Id to search offline orders.</param>
        /// <returns>list of offline order</returns>
        public List<OfflineOrder> GetOfflineOrderByRetailerIDDAL(Guid retailerID)
        {
            List<OfflineOrder> searchOfflineOrder = new List<OfflineOrder>();
            try
            {
                // Create object of sqlCommand
                SqlCommand sqlCommand = new SqlCommand("TeamB.GetOfflineOrderByRetailerID", sqlConnection);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                SqlParameter RetailerIDParam = new SqlParameter("@retailerID", retailerID);
                RetailerIDParam.DbType = DbType.Guid;
                sqlCommand.Parameters.Add(RetailerIDParam);



                //Create object of sqlAdapter
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
                sqlDataAdapter.SelectCommand = sqlCommand;

                //Create DataBase
                DataSet dataSet = new DataSet();
                sqlDataAdapter.Fill(dataSet);




                //Load into Collection

                DataRow dataRow;
                for (int i = 0; i < dataSet.Tables[0].Rows.Count; i++)
                {
                    dataRow = dataSet.Tables[0].Rows[i];

                    OfflineOrder tempofflineOrder = new OfflineOrder();

                    tempofflineOrder.OfflineOrderID = new Guid(Convert.ToString(dataRow["OfflineOrderID"]));
                    tempofflineOrder.RetailerID = new Guid(Convert.ToString(dataRow["RetailerID"]));
                    tempofflineOrder.SalesPersonID = new Guid(Convert.ToString(dataRow["SalesPersonID"]));
                    tempofflineOrder.TotalQuantity = Convert.ToInt32(dataRow["TotalQuantity"]);
                    tempofflineOrder.TotalOrderAmount = Convert.ToDouble(dataRow["TotalOrderAmount"]);


                    searchOfflineOrder.Add(tempofflineOrder);

                }
                sqlConnection.Close();
            }
            catch (SystemException ex)
            {
                throw new OfflineOrderException(ex.Message);
            }
            return searchOfflineOrder;
        }

        /// <summary>
        /// Get list of Offline orders using SalesPersonId
        /// </summary>
        /// <param name="salespersonID">Using Sales Person Id to search offline orders.</param>
        /// <returns>list of offline order</returns>
        public List<OfflineOrder> GetOfflineOrderBySalespersonIDDAL(Guid salespersonID)
        {
            List<OfflineOrder> searchOfflineOrder = new List<OfflineOrder>();
            try
            {
                // Create object of sqlCommand
                SqlCommand sqlCommand = new SqlCommand("TeamB.GetOfflineOrderBySalesPersonID", sqlConnection);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                SqlParameter SalesPersonIDParam = new SqlParameter("@salesPersonID", salespersonID);
                SalesPersonIDParam.DbType = DbType.Guid;
                sqlCommand.Parameters.Add(SalesPersonIDParam);



                //Create object of sqlAdapter
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
                sqlDataAdapter.SelectCommand = sqlCommand;

                //Create DataBase
                DataSet dataSet = new DataSet();
                sqlDataAdapter.Fill(dataSet);




                //Load into Collection

                DataRow dataRow;
                for (int i = 0; i < dataSet.Tables[0].Rows.Count; i++)
                {
                    dataRow = dataSet.Tables[0].Rows[i];

                    OfflineOrder tempofflineOrder = new OfflineOrder();

                    tempofflineOrder.OfflineOrderID = new Guid(Convert.ToString(dataRow["OfflineOrderID"]));
                    tempofflineOrder.RetailerID = new Guid(Convert.ToString(dataRow["RetailerID"]));
                    tempofflineOrder.SalesPersonID = new Guid(Convert.ToString(dataRow["SalesPersonID"]));
                    tempofflineOrder.TotalQuantity = Convert.ToInt32(dataRow["TotalQuantity"]);
                    tempofflineOrder.TotalOrderAmount = Convert.ToDouble(dataRow["TotalOrderAmount"]);


                    searchOfflineOrder.Add(tempofflineOrder);

                }
                sqlConnection.Close();

            }
            catch (SystemException ex)
            {
                throw new OfflineOrderException(ex.Message);
            }
            return searchOfflineOrder;
        }

        public bool UpdateOfflineorderDAL(OfflineOrder updateOfflineOrder)
        {
            bool OfflineOrderUpdated = false;
            try
            {


                sqlConnection.Open();
                string query;

                query = "TeamB.UpdateOfflineOrder";
                SqlCommand sqlcmd = new SqlCommand(query, sqlConnection);
                sqlcmd.CommandType = CommandType.StoredProcedure;

                //Assigning OfflineOrderDetailID

                sqlcmd.Parameters.AddWithValue("@offlineOrderid", updateOfflineOrder.OfflineOrderID).DbType = DbType.Guid;
                sqlcmd.Parameters.AddWithValue("@totalQuantity", updateOfflineOrder.TotalQuantity);
                sqlcmd.Parameters.AddWithValue("@totalOrderAmount", updateOfflineOrder.TotalOrderAmount);

                sqlcmd.ExecuteNonQuery();
                OfflineOrderUpdated = true;
                sqlConnection.Close();

            }
            catch (SystemException ex)
            {
                throw new OfflineOrderException(ex.Message);
            }
            return OfflineOrderUpdated;

        }
        /// <summary>
        /// Deletes OfflineOrder based on OfflineOrderID.
        /// </summary>
        /// <param name="deleteOfflineOrderID">Represents OfflineOrderID to delete.</param>
        /// <returns>Determinates whether the existing OfflineOrder is deleted.</returns>
        public bool DeleteOfflineOrderDAL(Guid deleteOfflineOrderID)
        {
            bool OfflineOrderDeleted = false;
            try
            {
                sqlConnection.Open();
                string query;

                query = "TeamB.DeleteOfflineOrder";
                SqlCommand sqlcmd = new SqlCommand(query, sqlConnection);
                sqlcmd.CommandType = CommandType.StoredProcedure;

                //Assigning OfflineOrderDetailID

                sqlcmd.Parameters.AddWithValue("@offlineOrderid", deleteOfflineOrderID).DbType = DbType.Guid;


                sqlcmd.ExecuteNonQuery();
            }
            catch (Exception)
            {
                throw;
            }
            return OfflineOrderDeleted;
        }
        /// <summary>
        /// Clears unmanaged resources such as db connections or file streams.
        /// </summary>
        public void Dispose()
        {
            //No unmanaged resources currently
        }


    }
}