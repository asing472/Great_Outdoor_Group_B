﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Capgemini.GreatOutdoor.BusinessLayer;
using Capgemini.GreatOutdoor.Entities;
using Capgemini.GreatOutdoor.Helpers;


namespace Capgemini.GreatOutdoor
{
    /// <summary>
    /// Interaction logic for OfflineOrder.xaml
    /// </summary>
    public partial class OfflineOrder : Window
    {
        public OfflineOrder()
        {
            InitializeComponent();
        }

        RetailerBL retailerBL = new RetailerBL();
        ProductBL productBL = new ProductBL();
        List<Retailer> retailers = new List<Retailer>();
        List<Product> products = new List<Product>();

        private async void Window_Loaded(object sender, RoutedEventArgs e)
        {
            var retailers = await retailerBL.GetAllRetailersBL();
            var products = await productBL.GetAllProductsBL();
            cmbRetailer.ItemsSource = retailers;
            cmdProduct.ItemsSource = products;
            cmbRetailer.DisplayMemberPath = "RetailerName";
            cmbRetailer.SelectedValuePath = "RetailerID";
            cmdProduct.DisplayMemberPath = "ProductName";
            cmdProduct.SelectedValuePath = "ProductID";
        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            MessageBox.Show(cmbRetailer.SelectedValue.ToString());
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void ComboBox_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {

        }

        private void ComboBox_SelectionChanged_2(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {

        }

        
    }
}
