﻿using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;
using Capgemini.GreatOutdoor.Entities;
using Capgemini.GreatOutdoor.Contracts;
using Capgemini.GreatOutdoor.Helpers;

namespace Capgemini.GreatOutdoor.DataAccessLayer
{
    /// <summary>
    /// Contains data access layer methods for inserting, updating orders from order collection.
    /// </summary>
    public class OrderDAL : OrderDALBase, IDisposable
    {
        /// <summary>
        /// Adds new order to ordersList collection.
        /// </summary>
        /// <param name="newOrder">Contains the order details to be added.</param>
        /// <returns>Determinates whether the new order is added.</returns>
        public override bool AddOrderDAL(Order newOrder)
        {
            bool orderAdded = false;
            try
            {
                newOrder.OrderId = Guid.NewGuid();
                newOrder.DateOfOrder = DateTime.Now;
                newOrder.LastModifiedDateTime = DateTime.Now;
                orderList.Add(newOrder);
                orderAdded = true;
            }
            catch (Exception)
            {
                throw;
            }
            return orderAdded;
        }

        /// <summary>
        /// Constructor for OrderDAL
        /// </summary>
        public OrderDAL()
        {
            Serialize();
            Deserialize();
        }


        /// <summary>
        /// Gets Order based on OrderID.
        /// </summary>
        /// <param name="searchOrderID">Represents OrderID to search.</param>
        /// <returns>Returns Order object.</returns>
        public override Order GetOrderByOrderIDDAL(Guid searchOrderID)
        {
            Order matchingOrder = null;
            try
            {
                //Find Order based on searchOrderID
                matchingOrder = orderList.Find(
                    (item) => { return item.OrderId == searchOrderID; }
                );
            }
            catch (Exception)
            {
                throw;
            }
            return matchingOrder;
        }

        /// <summary>
        /// Updates Order based on OrderID.
        /// </summary>
        /// <param name="updateOrder">Represents Order details like OrderID</param>
        /// <returns>Determinates whether the existing Order is updated.</returns>
        
        public override List<Order> GetOrderByRetailerIDDAL(Guid retailerID)
        {
            List<Order> matchingRetailers = new List<Order>();
            try
            {
                //Find all order Based on Retailer Name
                matchingRetailers= orderList.FindAll(
                    (item)=>{ return item.RetailerID == retailerID; }
                );
            }
            catch (Exception)
            {

                throw;
            }
            return matchingRetailers;
        }
        public override bool UpdateOrderDAL(Order updateOrder)
        {
            bool orderUpdated = false;
            try
            {
                //Find Order based on OrderID
                Order matchingOrder = GetOrderByOrderIDDAL(updateOrder.OrderId);

                if (matchingOrder != null)
                {
                    //Update admin details
                    ReflectionHelpers.CopyProperties(updateOrder, matchingOrder, new List<string>() { "cart" });
                    matchingOrder.LastModifiedDateTime = DateTime.Now;

                    orderUpdated = true;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return orderUpdated;
        }


        public override bool UpdateOrderDispatchedStatusDAL(Guid orderId)
        {
            bool orderDispatched = false;
            try
            {
                //Find order based on orderID
                Order matchingOrder = orderList.Find(
                    (item) => { return item.OrderId == orderId; }
                );
                if (matchingOrder != null)
                {
                    //order is delivered
                    if (matchingOrder.DateOfOrder.AddDays(2) >= DateTime.Now)
                        orderDispatched = true;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return orderDispatched;
        }

        public override bool UpdateOrderShippedStatusDAL(Guid orderId)
        {
            bool orderShipped = false;
            try
            {
                //Find order based on orderID
                Order matchingOrder = orderList.Find(
                    (item) => { return item.OrderId == orderId; }
                );
                if (matchingOrder != null)
                {
                    //order is delivered
                    if (matchingOrder.DateOfOrder.AddDays(5) >= DateTime.Now && matchingOrder.DateOfOrder.AddDays(2) < DateTime.Now)
                        orderShipped = true;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return orderShipped;
        }

        public override bool UpdateOrderDeliveredStatusDAL(Guid orderId)
        {
            bool orderDelivered = false;
            try
            {
                //Find order based on orderID
                Order matchingOrder = orderList.Find(
                    (item) => { return item.OrderId == orderId; }
                );
                if (matchingOrder != null)
                {
                    //order is delivered
                    if (matchingOrder.DateOfOrder.AddDays(6) >= DateTime.Now)
                        orderDelivered = true;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return orderDelivered;
        }

        /// <summary>
        /// Deletes systemUser based on SystemUserID.
        /// </summary>
        /// <param name="deleteOrderID">Represents SystemUserID to delete.</param>
        /// <returns>Determinates whether the existing systemUser is updated.</returns>
        public override bool DeleteOrderDAL(Guid deleteOrderID)
        {
            bool orderDeleted = false;
            try
            {
                //Find Order based on orderID
                Order matchingOrder = orderList.Find(
                    (item) => { return item.OrderId == deleteOrderID; }
                );

                if (matchingOrder != null)
                {
                    //Delete SystemUser from the collection
                    orderList.Remove(matchingOrder);
                    orderDeleted = true;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return orderDeleted;
        }

        /// <summary>
        /// Clears unmanaged resources such as db connections or file streams.
        /// </summary>
        public void Dispose()
        {
            //No unmanaged resources currently
        }
    }
}
