import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mainlogo',
  templateUrl: './mainlogo.component.html',
  styleUrls: ['./mainlogo.component.scss']
})
export class MainlogoComponent implements OnInit {
  constructor() {
  }

  ngOnInit() {
  }
}
