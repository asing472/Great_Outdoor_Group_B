import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-salesPerson-home',
  templateUrl: './salesPerson-home.component.html',
  styleUrls: ['./salesPerson-home.component.scss']
})
export class SalesPersonHomeComponent implements OnInit
{
  constructor()
  {
  }

  ngOnInit()
  {
  }
}


