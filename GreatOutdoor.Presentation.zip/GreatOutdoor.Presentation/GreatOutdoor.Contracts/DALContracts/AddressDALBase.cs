﻿using System;
using System.Collections.Generic;
using System.IO;
using Capgemini.GreatOutdoor.Entities;
using Newtonsoft.Json;

namespace Capgemini.GreatOutdoor.Contracts.DALContracts
{
    /// <summary>
    /// This abstract class acts as a base for AddressDAL class
    /// //Developed ByPrafull
    //base Interface for AddrssDAL
    /// </summary>
    public abstract class AddressDALBase
    {
        //Collection of Addresss
        protected static List<Address> addressList = new List<Address>();
        //Methods for CRUD operations
        public abstract (bool,Guid) AddAddressDAL(Address newAddress);
        public abstract List<Address> GetAllAddresssDAL();
        public abstract Address GetAddressByAddressIDDAL(Guid searchAddressID);
        public abstract List<Address> GetAddressByRetailerIDDAL(Guid retailerID);
        public abstract bool UpdateAddressDAL(Address updateAddress);
        public abstract bool DeleteAddressDAL(Guid deleteAddressID);    
    }
}


