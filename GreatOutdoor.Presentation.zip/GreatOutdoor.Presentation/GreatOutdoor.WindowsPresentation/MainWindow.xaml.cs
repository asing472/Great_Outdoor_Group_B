﻿using Capgemini.GreatOutdoor.BusinessLayer;
using Capgemini.GreatOutdoor.Contracts.BLContracts;
using Capgemini.GreatOutdoor.Entities;
using Capgemini.GreatOutdoor.Exceptions;
using Capgemini.GreatOutdoor.Helpers;
using Capgemini.GreatOutdoor.PresentationLayer;
using System;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;


namespace GreatOutdoor.WindowsPresentation
{
    /// <summary>
    /// developed by sravani
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        /// <summary>
        /// after clicking login button validates user
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                (UserType userType, IUser currentUser) = await ShowLoginScreen();

                //Set current user details into CommonData (global data)
                CommonData.CurrentUser = currentUser;
                CommonData.CurrentUserType = userType;
                //Invoke Admin's Menu
                if (userType == UserType.Admin)
                {
                    Hide();
                    Window window = new AdminWindow();
                    window.Show();
                }
                //Invoke SalesPerson's Menu

                else if (userType == UserType.SalesPerson)
                {
                    Hide();
                    Window window = new SalesPersonWindow();
                    window.Show();
                }
                //Invoke Retailer's Menu
                else if (userType == UserType.Retailer)
                {
                    Hide();
                    Window window = new RetailerWindow();
                    window.Show();
                }

                else if (userType == UserType.Anonymous)
                {
                    MessageBox.Show("Invalid Email or Password");
                }
            }
            catch (Exception)
            {
                throw;
            }



        }
        /// <summary>
        /// checks user entered valid email and password
        /// </summary>
        /// <returns></returns>
        private async Task<(UserType, IUser)> ShowLoginScreen()
        {
            string email = txtUserID.Text;
            string password = txtPassword.Password.ToString();
            using (IRetailerBL RetailerBL = new RetailerBL())
            {
                //Invoke GetRetailerByEmailAndPasswordBL for checking email and password of Retailer
                Retailer retailer = await RetailerBL.GetRetailerByEmailAndPasswordBL(email, password);
                if (retailer != null)
                {
                    return (UserType.Retailer, retailer);
                }
            }
            using (IAdminBL adminBL = new AdminBL())
            {
                //Invoke GetAdminByEmailAndPasswordBL for checking email and password of Admin
                Admin admin = await adminBL.GetAdminByEmailAndPasswordBL(email, password);
                if (admin != null)
                {
                    return (UserType.Admin, admin);
                }
            }

            using (ISalesPersonBL SalesPersonBL = new SalesPersonBL())
            {
                //Invoke GetSalesPersonByEmailAndPasswordBL for checking email and password of SalesPerson
                SalesPerson SalesPerson = await SalesPersonBL.GetSalesPersonByEmailAndPasswordBL(email, password);
                if (SalesPerson != null)
                {
                    return (UserType.SalesPerson, SalesPerson);
                }
            }

            return (UserType.Anonymous, null);
        }

        private void Btnreset_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Name_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Email_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Mobile_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
        /// <summary>
        /// retailer registartion form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void btnSignUp_Click(object sender, RoutedEventArgs e)
        {

            try
            {

                Retailer newRetailer = new Retailer();
                newRetailer.RetailerName = txtName.Text;
                newRetailer.RetailerMobile = txtMobile.Text;
                newRetailer.Email = txtEmail.Text;
                newRetailer.Password = txtNewPassword.Password.ToString();
                newRetailer.RetailerID = default(Guid);
                RetailerBL rb = new RetailerBL();

                bool retailerAdded;
                Guid newRetailerGuid;
                (retailerAdded, newRetailerGuid) = await rb.AddRetailerBL(newRetailer);
                if (retailerAdded)
                {
                    MessageBox.Show($"Retailer Add/n Your user ID : {newRetailer.Email}");
                }
                else
                    Console.WriteLine("Retailer Not Added");

            }
            catch (GreatOutdoorException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
