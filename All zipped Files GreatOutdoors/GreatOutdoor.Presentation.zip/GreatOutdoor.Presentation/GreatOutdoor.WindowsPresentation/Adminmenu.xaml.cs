﻿using Capgemini.GreatOutdoor.BusinessLayer;
using Capgemini.GreatOutdoor.Entities;
using Capgemini.GreatOutdoor.Exceptions;
using Capgemini.GreatOutdoor.PresentationLayer;
using System;
using Capgemini.GreatOutdoor.Contracts.BLContracts;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;

namespace GreatOutdoor.WindowsPresentation
{
    /// <summary>
    /// Interaction logic for Adminmenu.xaml
    /// developed by sravani
    /// </summary>
    public partial class Adminmenu : Window
    {
        public Adminmenu()
        {
            InitializeComponent();
        }

        /// <summary>
        /// viewing sales reports
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void Salesreports_Click(object sender, RoutedEventArgs e)
        {
            ViewSalesReportsBL vr = new ViewSalesReportsBL();
            List<ViewSalesReports> SalesReports = await vr.ViewAllSalesReportsBL();
            DataTable SalesReportstable = new DataTable();
            SalesReportstable = ConvertToDataTable<ViewSalesReports>(SalesReports);
            dgvdata.ItemsSource = SalesReportstable.DefaultView;

        }
        /// <summary>
        /// converts the list of objects into data table format
        /// </summary>
        /// <typeparam name="SalesPerson"></typeparam>
        /// <param name="data"></param>
        /// <returns></returns>
        public DataTable ConvertToDataTable<SalesPerson>(IList<SalesPerson> data)
        {
            PropertyDescriptorCollection properties =
               TypeDescriptor.GetProperties(typeof(SalesPerson));
            DataTable table = new DataTable();
            foreach (PropertyDescriptor prop in properties)
                table.Columns.Add(prop.Name, Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType);
            foreach (SalesPerson item in data)
            {
                DataRow row = table.NewRow();
                foreach (PropertyDescriptor prop in properties)
                    row[prop.Name] = prop.GetValue(item) ?? DBNull.Value;
                table.Rows.Add(row);
            }
            return table;

        }
        /// <summary>
        /// views all salespersons profile
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void Viewsalesprofile_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using (ISalesPersonBL SalesPersonBL = new SalesPersonBL())
                {
                    //Get and display list of system users.
                    List<SalesPerson> SalesPersons = await SalesPersonBL.GetAllSalesPersonsBL();

                    if (SalesPersons != null && SalesPersons?.Count > 0)
                    {
                        DataTable salespersonstable = new DataTable();
                        salespersonstable = ConvertToDataTable<SalesPerson>(SalesPersons);
                        dgvdata.ItemsSource = salespersonstable.DefaultView;

                    }
                }
            }
            catch (Exception)
            {
                throw;

            }

        }

        private void dgvdata_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
        /// <summary>
        /// opens admin menu
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Menu_Admin_Click(object sender, RoutedEventArgs e)
        {
            Hide();
            Window window = new Adminmenu();
            window.Show();

        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {

        }


        //private async void ViewRetailerreports_Click(object sender, RoutedEventArgs e)
        //{
        //    RetailerBL retailerBL = new RetailerBL();
        //    List<Retailer> retailers = await retailerBL.GetAllRetailersBL();
        //    List<RetailerReport> retailerreports = new List<RetailerReport>();
        //    RetailerReport item;
        //    foreach (var retailer in retailers)
        //    {
        //        item = await retailerBL.GetRetailerReportByRetailIDBL(retailer.RetailerID);
        //        retailerreports.Add(item);

        //    }
        //    DataTable RetailerReportstable = new DataTable();
        //    RetailerReportstable = ConvertToDataTable<RetailerReport>(retailerreports);
        //    dgvdata.ItemsSource = RetailerReportstable.DefaultView;


        //}
    }
}
