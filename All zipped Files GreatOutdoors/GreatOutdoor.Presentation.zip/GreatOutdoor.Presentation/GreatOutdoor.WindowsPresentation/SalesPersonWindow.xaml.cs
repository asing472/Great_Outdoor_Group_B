﻿using Capgemini.GreatOutdoor.BusinessLayer;
using Capgemini.GreatOutdoor.Entities;
using Capgemini.GreatOutdoor.PresentationLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GreatOutdoor.WindowsPresentation
{
    /// <summary>
    /// Interaction logic for SalesPersonWindow.xaml
    /// </summary>
    public partial class SalesPersonWindow : Window
    {
        public SalesPersonWindow()
        {
            InitializeComponent();
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {

        }



        private void Menu_Address_Click(object sender, RoutedEventArgs e)
        {
            Hide();
            Window window = new AddressWindow();
            window.Show();
        }

        private void OnlineReturn_Click(object sender, RoutedEventArgs e)
        {

        }

        private async void DeleteAccount_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                using (SalesPersonBL SalesPersonBL = new SalesPersonBL())
                {
                    SalesPerson SalesPerson = await SalesPersonBL.GetSalesPersonByEmailBL(CommonData.CurrentUser.Email);
                    bool isDeleted = false;
                    isDeleted = await SalesPersonBL.DeleteSalesPersonBL(SalesPerson.SalesPersonID);
                    if (isDeleted)
                    {
                        MessageBox.Show("Account Deleted");
                        Hide();
                        Window window = new MainWindow();
                        window.Show();
                    }
                }

            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
