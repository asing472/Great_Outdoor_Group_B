﻿using Capgemini.GreatOutdoor.BusinessLayer;
using Capgemini.GreatOutdoor.Contracts;
using Capgemini.GreatOutdoor.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GreatOutdoor.WindowsPresentation
{
    /// <summary>
    /// Interaction logic for CartWindow.xaml
    /// </summary>
    public partial class CartWindow : Window
    {
        public CartWindow()
        {
            InitializeComponent();
        }
        private void BtnConfirmCart_Click(object sender, RoutedEventArgs e)
        {
            //OrderWindow object to get orderdetails and order object
            OrderWindow OrderWindow = new OrderWindow();
            List<OrderDetail> orderDetails = OrderWindow.orderDetails;
            Order order = OrderWindow.order;
            double TotalAmount = 0;
            int Quantity = 0;
            //to get the total amount and quantity of order
            foreach (OrderDetail orderDetail in orderDetails)
            {
                TotalAmount += orderDetail.TotalAmount;
                Quantity += orderDetail.ProductQuantityOrdered;
            }
            order.TotalQuantity = Quantity;
            order.OrderAmount = TotalAmount;
            //assigning total aquantity and amount to order object
            IOrderBL orderBL = new OrderBL();
            orderBL.UpdateOrderBL(order);
            MessageBox.Show($"Order placed! \n Order Amount= {order.OrderAmount} \n Total Quantity= {order.TotalQuantity}");
        }

        private void BtnGoToMenu_Click(object sender, RoutedEventArgs e)
        {
            Hide();
            Window window = new OrderWindow();
            window.Show();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            OrderWindow OrderWindow = new OrderWindow();
            List<OrderDetail> orderDetails = OrderWindow.orderDetails;
            gridOrderDetails.ItemsSource = orderDetails;

        }
    }
}
