﻿using System.Windows;

namespace GreatOutdoor.WindowsPresentation
{
    /// <summary>
    /// developed by sravani
    /// Interaction logic for AdminWindow.xaml
    /// </summary>
    public partial class AdminWindow : Window
    {
        public AdminWindow()
        {
            InitializeComponent();
        }
        /// <summary>
        /// invokes admin menu
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Menu_Admin_Click(object sender, RoutedEventArgs e)
        {
            Hide();
            Window window = new Adminmenu();
            window.Show();
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {


        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {

        }
    }
}
