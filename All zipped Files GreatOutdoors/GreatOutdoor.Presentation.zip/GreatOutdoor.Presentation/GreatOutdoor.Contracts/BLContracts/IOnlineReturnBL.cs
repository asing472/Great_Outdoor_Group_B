﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Capgemini.GreatOutdoor.Entities;
using Capgemini.GreatOutdoor.Helpers;

namespace Capgemini.GreatOutdoor.Contracts.BLContracts
{
    //Developed By Ayush Agrawal
    //base Interface for OnlineReturnBL
    public interface IOnlineReturnBL : IDisposable
    {
        Task<(bool,Guid)> AddOnlineReturnBL(OnlineReturn newOnlineReturn);
        Task<List<OnlineReturn>> GetAllOnlineReturnsBL();
        Task<OnlineReturn> GetOnlineReturnByOnlineReturnIDBL(Guid searchOnlineReturnID);
        Task<List<OnlineReturn>> GetOnlineReturnsByPurposeBL(string purpose);
        Task<bool> UpdateOnlineReturnBL(OnlineReturn updateOnlineReturn);
        Task<bool> DeleteOnlineReturnBL(Guid deleteOnlinereturnID);
    }
}

