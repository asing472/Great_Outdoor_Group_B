﻿using System;
using System.Collections.Generic;
using System.IO;
using Capgemini.GreatOutdoor.Entities;
using Newtonsoft.Json;

namespace Capgemini.GreatOutdoor.Contracts.DALContracts
{
    /// <summary>
    /// This abstract class acts as a base for RetailerDAL class
    /// //Developed By Prafull
    //base Interface for RetailerDAL
    /// </summary>
    public abstract class RetailerDALBase
    {
        //Collection of Retailers
        protected static List<Retailer> retailerList = new List<Retailer>() { new Retailer() { RetailerID = Guid.NewGuid(), Email = "prafull@capgemini.com", RetailerName = "prafull", Password = "prafull", CreationDateTime = DateTime.Now, LastModifiedDateTime = DateTime.Now } };
        

        //Methods for CRUD operations
        public abstract (bool,Guid) AddRetailerDAL(Retailer newRetailer);
        public abstract List<Retailer> GetAllRetailersDAL();
        public abstract Retailer GetRetailerByRetailerIDDAL(Guid searchRetailerID);
        public abstract List<Retailer> GetRetailersByNameDAL(string retailerName);
        public abstract Retailer GetRetailerByEmailDAL(string email);
        public abstract Retailer GetRetailerByEmailAndPasswordDAL(string email, string password);
        public abstract bool UpdateRetailerDAL(Retailer updateRetailer);
        public abstract bool UpdateRetailerPasswordDAL(Retailer updateRetailer);
        public abstract bool DeleteRetailerDAL(Guid deleteRetailerID);
    }
}


