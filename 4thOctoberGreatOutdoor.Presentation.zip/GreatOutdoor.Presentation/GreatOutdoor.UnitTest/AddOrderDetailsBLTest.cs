﻿using Capgemini.GreatOutdoor.BusinessLayer;
using Capgemini.GreatOutdoor.Entities;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Threading.Tasks;

namespace Capgemini.GreatOutdoor.UnitTests
{
    [TestClass]
    public class AddOrderDetailsBLTest
    {
        /// <summary>
        /// Add Order Detail to the Collection if it is valid.
        /// </summary>
        [TestMethod]
        public async Task AddValidOrder()
        {
            //Arrange
            OrderDetailBL orderDetailBL = new OrderDetailBL();
            OrderDetail orderDetail = new OrderDetail() { OrderId = Guid.NewGuid(), ProductID = Guid.NewGuid(), TotalAmount = 10, ProductQuantityOrdered = 10 };
            bool isAdded = false;
            Guid newGuid;
            string errorMessage = null;

            //Act
            try
            {
                (isAdded, newGuid) = await orderDetailBL.AddOrderDetailsBL(orderDetail);
                orderDetail.OrderId = newGuid;
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// Product ID should be unique and present in database
        /// </summary>
        [TestMethod]
        public async Task ProductIDNotMatch()
        {
            //Arrange
            OrderDetailBL orderDetailBL = new OrderDetailBL();
            OrderDetail orderDetail = new OrderDetail() { OrderId = Guid.NewGuid(), ProductID = Guid.NewGuid(), TotalAmount = 10, ProductQuantityOrdered = 10 };
            bool isAdded = false;
            Guid newGuid;
            string errorMessage = null;

            //Act
            try
            {
                (isAdded, newGuid) = await orderDetailBL.AddOrderDetailsBL(orderDetail);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }


        /// <summary>
        /// Total Amount of Product can't be negative
        /// </summary>
        [TestMethod]
        public async Task TotalAmountCannotBeNegative()
        {
            //Arrange
            OrderDetailBL orderDetailBL = new OrderDetailBL();
            OrderDetail orderDetail = new OrderDetail() { OrderId = Guid.NewGuid(), ProductID = Guid.NewGuid(), TotalAmount = 10, ProductQuantityOrdered = 10 };
            bool isAdded = false;
            Guid newGuid;
            string errorMessage = null;

            //Act
            try
            {
                (isAdded, newGuid) = await orderDetailBL.AddOrderDetailsBL(orderDetail);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// Total Quantity of Product can't be negative
        /// </summary>
        [TestMethod]
        public async Task TotalQuantityCannotBeNegative()
        {
            //Arrange
            OrderDetailBL orderDetailBL = new OrderDetailBL();
            OrderDetail orderDetail = new OrderDetail() { OrderId = Guid.NewGuid(), ProductID = Guid.NewGuid(), TotalAmount = 10, ProductQuantityOrdered = 10 };
            bool isAdded = false;
            Guid newGuid;
            string errorMessage = null;

            //Act
            try
            {
                (isAdded, newGuid) = await orderDetailBL.AddOrderDetailsBL(orderDetail);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

    }
}

