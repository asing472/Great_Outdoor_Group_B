import { Component, OnInit } from '@angular/core';
// Create By Prafull Sharma on 08/10/2019
@Component({
  selector: 'app-retailer-home',
  templateUrl: './retailer-home.component.html',
  styleUrls: ['./retailer-home.component.scss']
})
export class RetailerHomeComponent implements OnInit {
  constructor() {
  }

  ngOnInit() {
  }
}


