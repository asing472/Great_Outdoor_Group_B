// About Page Component Type Script
import { Component, OnInit } from '@angular/core';
// Create By Prafull Sharma on 08/10/2019
@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.scss']
})
export class AboutComponent implements OnInit {
  constructor() {
  }

  ngOnInit() {
  }
}


