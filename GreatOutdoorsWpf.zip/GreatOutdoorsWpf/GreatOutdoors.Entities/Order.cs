﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GreatOutdoors.Entities
{
    public class Order
    {
        public Guid OrderId { get; set; } //ID of the order
        //public Guid RetailerID { get; set; } //ID of the retailer
        public DateTime DateOfOrder { get; set; } //Date of placing order
        public int TotalQuantity { get; set; } //Total quantity of the products ordererd
        public DateTime LastModifiedDateTime { get; set; }//date of order modification
        public double OrderAmount { get; set; }//total cost of the order
        //public double OrderNumber { get; set; } = 0;//order no of the retailer
    }
}
