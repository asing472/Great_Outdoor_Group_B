﻿using System;
/// <summary>
/// developed by sravani
/// </summary>
namespace Capgemini.GreatOutdoor.Entities
{
    /// <summary>
    /// Interface for Admin Entity
    /// </summary>
    public interface IAdmin
    {
        Guid AdminID { get; set; }
        string AdminName { get; set; }
        string Email { get; set; }
        string Password { get; set; }
        DateTime CreationDateTime { get; set; }
        DateTime LastModifiedDateTime { get; set; }
    }

    /// <summary>
    /// Represents Admin
    /// </summary>
    public class Admin : IAdmin
    {
        public Guid AdminID { get; set; }
        
        public string AdminName { get; set; }

        public string Email { get; set; }
        
        public string Password { get; set; }

        public DateTime CreationDateTime { get; set; }
        public DateTime LastModifiedDateTime { get; set; }

        /* Constructor */
        public Admin()
        {
            AdminID = default(Guid);
            AdminName = null;
            Email = null;
            Password = null;
            CreationDateTime = default(DateTime);
            LastModifiedDateTime = default(DateTime);
        }
    }
}
