﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GreatOutdoors.Entities
{
    public class OfflineOrder
    {

        public Guid OfflineOrderID { get; set; }
        public Guid RetailerID { get; set; }
        public Guid SalesPersonID { get; set; }
        public double TotalQuantity { get; set; }
        public double TotalOrderAmount { get; set; }
        public DateTime CreationDateTime { get; set; }
        public DateTime LastModifiedDateTime { get; set; }
    }
}

