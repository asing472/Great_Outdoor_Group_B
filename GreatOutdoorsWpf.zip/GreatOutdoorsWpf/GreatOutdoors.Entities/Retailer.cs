﻿using System;


namespace GreatOutdoor.Entities
{
    /// <summary>
    /// Interface for Retailer Entity
    /// </summary>
    public interface IRetailer
    {
        Guid RetailerID { get; set; }
        string RetailerName { get; set; }
        string Email { get; set; }
        string Password { get; set; }
        string RetailerMobile { get; set; }
        DateTime CreationDateTime { get; set; }
        DateTime LastModifiedDateTime { get; set; }
    }

    /// <summary>
    /// Represents Retailer
    /// </summary>
    public class Retailer : IRetailer
    {
        /* Auto-Implemented Properties */
       
        public Guid RetailerID { get; set; }

        public string RetailerName { get; set; }
        
        public string Email { get; set; }
        public string Password { get; set; }
        public string RetailerMobile { get; set; }
        public DateTime CreationDateTime { get; set; }
        public DateTime LastModifiedDateTime { get; set; }

        /* Constructor */
        public Retailer()
        {
            RetailerID = default(Guid);
            RetailerName = null;
            Email = null;
            Password = null;
            RetailerMobile = null;
            CreationDateTime = default(DateTime);
            LastModifiedDateTime = default(DateTime);
        }
    }
}
