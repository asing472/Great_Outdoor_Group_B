﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GreatOutdoors.Entities
{
    public class SalesPerson
    {

        public Guid SalesPersonID { get; set; }
        public string SalesPersonName { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string SalesPersonMobile { get; set; }
        public DateTime CreationDateTime { get; set; }
        public DateTime LastModifiedDateTime { get; set; }
    }
}
