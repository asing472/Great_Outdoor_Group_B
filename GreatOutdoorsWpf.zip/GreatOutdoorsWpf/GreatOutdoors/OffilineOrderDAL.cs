﻿using System;
using System.Data.SqlClient;
using GreatOutdoors.Entities;
using System.Data;

namespace GreatOutdoors
{
    public class OfflineOrderDAL
    {
        SqlConnection sqlConn = new SqlConnection(Properties.Settings.Default.dbCon);

        public (bool, Guid) AddOfflineOrder(OfflineOrder offlineOrder)
        {
            Guid offlineOrderID = new Guid();
            bool offlineOrderAdded = false;

            try
            {
                // Adding Connection to the database

                sqlConn.Open();
                string query;

                query = "EXEC AddOfflineOrder ((@offlineOrderID, @retailerID, @salesPersonID, @totalOrderAmount,@totalQuantity)";
                SqlCommand sqlcmd = new SqlCommand(query, sqlConn);
                sqlcmd.CommandType = CommandType.StoredProcedure;
                sqlcmd.Parameters.AddWithValue("@offlineOrderID", offlineOrderID);
                sqlcmd.Parameters.AddWithValue("@retailerID", offlineOrder.RetailerID);
                sqlcmd.Parameters.AddWithValue("@salesPersonID", offlineOrder.SalesPersonID);
                sqlcmd.Parameters.AddWithValue("@totalOrderAmount", offlineOrder.TotalOrderAmount);
                sqlcmd.Parameters.AddWithValue("@totalQuantity", offlineOrder.TotalQuantity);

                sqlcmd.ExecuteNonQuery();
            }
            catch
            {

            }
            finally
            {
                sqlConn.Close();
            }
            return (offlineOrderAdded, offlineOrderID);

        }

        //public List<OfflineOrder> GetAllOfflineOrdersDAL()
        //{
        //    List<OfflineOrder> offlineOrderList;
        //    string query;
        //    sqlConn.Open();
        //    query = "EXEC GetAllOfflineOrder ()";


        //    return offlineOrderList;

        //}
    }
}
