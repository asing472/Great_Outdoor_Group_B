﻿using System;
using System.Data.SqlClient;
using GreatOutdoors.Entities;
using System.Data;

namespace GreatOutdoors
{
    public class SalesPersonDAL
    {
        public SalesPersonDAL()
        {

        }

        public (bool, Guid) AddSalesPersonDAL(SalesPerson newSalesPerson)
        {
            bool salesPersonAdded = false;
            try
            {
                newSalesPerson.SalesPersonID = Guid.NewGuid();
                newSalesPerson.CreationDateTime = DateTime.Now;
                newSalesPerson.LastModifiedDateTime = DateTime.Now;
                salesPersonAdded = true;
                SqlConnection sqlConn = new SqlConnection(Properties.Settings.Default.dbCon);
                sqlConn.Open();
                string query = "exec AddSalesPerson(@salesPersonID, @salesPersonName, @email, @password, @salesPersonMobile, @creationDateTime @lastModifiedDateTime)";
                SqlCommand sqlCmd = new SqlCommand(query);
                sqlCmd.CommandType = CommandType.Text;
                sqlCmd.Parameters.AddWithValue("@salesPersonID", newSalesPerson.SalesPersonID);
                sqlCmd.Parameters.AddWithValue("@salesPersonName", newSalesPerson.SalesPersonName);
                sqlCmd.Parameters.AddWithValue("@email", newSalesPerson.Email);
                sqlCmd.Parameters.AddWithValue("@salesPersonMobile", newSalesPerson.SalesPersonMobile);
                sqlCmd.Parameters.AddWithValue("@password", newSalesPerson.Password);
                sqlCmd.Parameters.AddWithValue("@creationDateTime", newSalesPerson.CreationDateTime);
                sqlCmd.Parameters.AddWithValue("@lastModifiedDateTime", newSalesPerson.LastModifiedDateTime);
                sqlConn.Close();
                return (salesPersonAdded, newSalesPerson.SalesPersonID);
            }
            catch (Exception exp)
            {
                throw;
            }



        }


    }
}
