﻿using System;

using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using GreatOutdoors.Entities;
using System.Data;

namespace GreatOutdoors.DataAccesslayer
{
    //Order Dal done by Akhil
    public class OrderDAL
    {
        public OrderDAL()
        {

        }

        public (bool,Guid) AddOrderDAL(Order newOrder)
        {
            bool orderAdded = false;
            try
            {
                newOrder.OrderId = Guid.NewGuid();
                newOrder.DateOfOrder = DateTime.Now;
                newOrder.LastModifiedDateTime = DateTime.Now;
                orderAdded = true;
                SqlConnection sqlConnection = new SqlConnection(Properties.Settings.Default.dbCon);
                sqlConnection.Open();
                string query = "exec AddOrder(@orderId,@dateOfOrder,@lastModifiedDate,@totalAmount,@totalQuantity)";
                SqlCommand sqlCommand = new SqlCommand(query);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.Parameters.AddWithValue("@orderId", newOrder.OrderId);
                sqlCommand.Parameters.AddWithValue("@dateOfOrder", newOrder.DateOfOrder);
                sqlCommand.Parameters.AddWithValue("@lastModifiedDate", newOrder.LastModifiedDateTime);
                sqlCommand.Parameters.AddWithValue("@totalAmount",newOrder.OrderAmount);
                sqlCommand.Parameters.AddWithValue("@totalQuantity",newOrder.TotalQuantity);
                sqlConnection.Close();
                return (orderAdded, newOrder.OrderId);
            }
            catch (Exception)
            {

                throw;
            }
            
        }

        public void UpdateOrder(Order order)
        {
            try
            {
                SqlConnection sqlConnection = new SqlConnection(Properties.Settings.Default.dbCon);
                sqlConnection.Open();
                string query = "exec UpdateOrder(@orderId,@totalAmount,@totalQuantity,@lastModifiedDate)";
                SqlCommand sqlCommand = new SqlCommand(query);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.Parameters.AddWithValue("@orderId", order.OrderId);
                sqlCommand.Parameters.AddWithValue("@totalAmount", order.OrderAmount);
                sqlCommand.Parameters.AddWithValue("@totalQuantity", order.TotalQuantity);
                sqlCommand.Parameters.AddWithValue("@lastModifiedDate", order.LastModifiedDateTime);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public void DeleteOrder(Order order)
        {
            try
            {
                SqlConnection sqlConnection = new SqlConnection(Properties.Settings.Default.dbCon);
                sqlConnection.Open();
                string query = "exec DeleteOrder(@orderId)";
                SqlCommand sqlCommand = new SqlCommand(query);
                sqlCommand.CommandType = CommandType.StoredProcedure;
                sqlCommand.Parameters.AddWithValue("@orderId", order.OrderId);
               
            }
            catch (Exception)
            {
                throw;
            }
        }

        public List<Order> GetAllOrders()
        {
            try
            {
                Order order = new Order();
                List<Order> orders = new List<Order>();
                SqlConnection sqlConnection = new SqlConnection(Properties.Settings.Default.dbCon);
                sqlConnection.Open();
                string query = "exec GetAllOrders";
                DataSet dataSet = new DataSet(query);
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(query, sqlConnection);
                SqlCommandBuilder sqlCommandBuilder = new SqlCommandBuilder(sqlDataAdapter);
                sqlDataAdapter.Fill(dataSet);
                for(int i=0;i< dataSet.Tables[0].Rows.Count; i++)
                {
                   // order.OrderId=dataSet.Tables[0].Columns[0].
                }
                return orders;
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
    //----------------------------------------------------------------------------------------------//

}
