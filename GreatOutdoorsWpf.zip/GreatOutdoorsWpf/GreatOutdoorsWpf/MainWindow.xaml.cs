﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace GreatOutdoorsWpf
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void NumericOnly(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !IsValid(((TextBox)sender).Text + e.Text);
        }
        public static bool IsValid(string str)
        {
            int i;
            return (int.TryParse(str, out i) && i >= 1);
        }

       
        


        private void CmbProducts_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void BtnAddToCart_Click(object sender, RoutedEventArgs e)
        {
            
        }

        

        private void BtnGoToCart_Click(object sender, RoutedEventArgs e)
        {
            Hide();
            Window window = new Cart();
            window.Show();
        }
    }
}
