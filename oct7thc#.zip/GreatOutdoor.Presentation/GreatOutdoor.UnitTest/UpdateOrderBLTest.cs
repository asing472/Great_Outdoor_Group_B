﻿using Capgemini.GreatOutdoor.BusinessLayer;
using Capgemini.GreatOutdoor.Entities;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Threading.Tasks;

namespace Capgemini.GreatOutdoor.UnitTests
{
    [TestClass]
    public class UpdateOrderBLTest
    {
        /// <summary>
        /// UpdateOrder in the Collection if it is valid.
        /// </summary>
        [TestMethod]
        public async Task UpdateValidOrder()
        {
            //Arrange
            OrderBL orderBL = new OrderBL();
            Order order = new Order() { OrderAmount = 10, TotalQuantity = 10, };
            bool isAdded = false;
            Guid newGuid;
            string errorMessage = null;

            //Act
            try
            {
                Retailer retailer = new Retailer() { RetailerID = Guid.NewGuid(), RetailerName = "Abhishekk", RetailerMobile = "9039607064", Password = "Abhishek@2", Email = "abhi.rajawat01@gmail.com" };

                RetailerBL retailerBL = new RetailerBL();
                bool isAdded1 = false;
                Guid newGuid1;
                (isAdded1, newGuid1) = await retailerBL.AddRetailerBL(retailer);
                retailer.RetailerID = newGuid1;
                order.RetailerID = newGuid1;
                (isAdded, newGuid) = await orderBL.AddOrderBL(order);
                order.OrderAmount = 5;
                await orderBL.UpdateOrderBL(order);

            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// OrderAmount Cannot be Negative.
        /// </summary>
        [TestMethod]
        public async Task OrderAmountCannotBeNegative()
        {
            //Arrange
            OrderBL orderBL = new OrderBL();
            Order order = new Order() { OrderAmount = 10, TotalQuantity = 10, };
            bool isAdded = false;
            Guid newGuid;
            string errorMessage = null;

            //Act
            try
            {
                Retailer retailer = new Retailer() { RetailerID = Guid.NewGuid(), RetailerName = "Abhishekk", RetailerMobile = "9039607064", Password = "Abhishek@2", Email = "abhi.rajawat01@gmail.com" };

                RetailerBL retailerBL = new RetailerBL();
                bool isAdded1 = false;
                Guid newGuid1;
                (isAdded1, newGuid1) = await retailerBL.AddRetailerBL(retailer);
                retailer.RetailerID = newGuid1;
                order.RetailerID = newGuid1;
                (isAdded, newGuid) = await orderBL.AddOrderBL(order);
                order.OrderAmount = -5;
                await orderBL.UpdateOrderBL(order);

            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// Order won't be updated if OrderNumber is negative.
        /// </summary>
        [TestMethod]
        public async Task OrderNumberCannotBeNegative()
        {
            //Arrange
            OrderBL orderBL = new OrderBL();
            Order order = new Order() { OrderAmount = 10, TotalQuantity = 10, };
            bool isAdded = false;
            Guid newGuid;
            string errorMessage = null;

            //Act
            try
            {
                Retailer retailer = new Retailer() { RetailerID = Guid.NewGuid(), RetailerName = "Abhishekk", RetailerMobile = "9039607064", Password = "Abhishek@2", Email = "abhi.rajawat01@gmail.com" };

                RetailerBL retailerBL = new RetailerBL();
                bool isAdded1 = false;
                Guid newGuid1;
                (isAdded1, newGuid1) = await retailerBL.AddRetailerBL(retailer);
                retailer.RetailerID = newGuid1;
                order.RetailerID = newGuid1;
                (isAdded, newGuid) = await orderBL.AddOrderBL(order);
                order.OrderNumber = -5;
                await orderBL.UpdateOrderBL(order);

            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }
    }

}