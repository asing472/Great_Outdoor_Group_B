﻿using System.Collections.Generic;
using Capgemini.GreatOutdoor.Entities;
/// <summary>
/// Developed by sravani
/// </summary>
namespace Capgemini.GreatOutdoor.Contracts.DALContracts
{
    public abstract class ViewRetailerReportsDALBase
    {
        public static List<ViewSalesReports> viewSales = new List<ViewSalesReports>();
    }
}
