﻿using System;
using System.Collections.Generic;

namespace Capgemini.GreatOutdoor.Helpers
{
    /// <summary>
    /// 
    /// </summary>
    public enum UserType
    {
        Admin, SystemUser, Distributor, Supplier, Anonymous
    }
}