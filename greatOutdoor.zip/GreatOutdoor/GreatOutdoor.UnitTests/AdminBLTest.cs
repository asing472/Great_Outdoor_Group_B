﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Capgemini.GreatOutdoor.UnitTests
{
    [TestClass]
    public class AdminBLTest
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
