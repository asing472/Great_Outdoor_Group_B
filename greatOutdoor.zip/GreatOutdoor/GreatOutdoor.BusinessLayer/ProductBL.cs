﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using System.Text.RegularExpressions;
using Capgemini.GreatOutdoor.Contracts.BLContracts;
using Capgemini.GreatOutdoor.Contracts.DALContracts;
using Capgemini.GreatOutdoor.DataAccessLayer;
using Capgemini.GreatOutdoor.Entities;
using Capgemini.GreatOutdoor.Exceptions;
using Capgemini.GreatOutdoor.Helpers.ValidationAttributes;

namespace Capgemini.GreatOutdoor.BusinessLayer
{
    /// <summary>
    /// Contains data access layer methods for inserting, updating or ddeleting products
    /// </summary>
    public class ProductBL : BLBase<Product>, IProductBL, IDisposable
    {
        //fields
        ProductDALBase productDAL;

        /// <summary>
        /// Constructor
        /// </summary>
        public ProductBL()
        {
            this.productDAL = new ProductDAL();
        }

        /// <summary>
        /// Gets all products from the collection.
        /// </summary>
        /// <returns>Returns the list of all the products</returns>
        public async Task<List<Product>> GetAllProductsBL()
        {
            List<Product> productsList = null;

            try
            {
                await Task.Run(() =>
                {
                    productsList = productDAL.GetAllProductsDAL();

                });
            }

            catch (Exception)
            {
                throw;
            }

            return productsList;
        }

        /// <summary>
        /// Get product based on productID
        /// </summary>
        /// <param name="productID">Represents product ID to be searched.</param>
        /// <returns>Returns product object</returns>
        public async Task<Product> GetProductByProductIDBL(Guid productID)
        {
            Product matchingProduct = null;

            try
            {
                await Task.Run(() =>
                {
                    matchingProduct = productDAL.GetProductByProductIDDAL(productID);
                });
            }

            catch (Exception)
            {
                throw;
            }
            return matchingProduct;
        }

        /// <summary>
        /// Updates product description based on ProductID.
        /// </summary>
        /// <param name="updateProduct">Respresents product description only</param>
        /// <returns>Tells whether the description is updated</returns>
        public async Task<bool> UpdateProductDescriptionBL(Product updateProduct)
        {
            bool descriptionUpdated = false;

            try
            {
                if (await GetProductByProductIDBL(updateProduct.ProductID) != null)
                {
                    this.productDAL.UpdateProductDescriptionDAL(updateProduct);
                    descriptionUpdated = true;
                    Serialize();

                }

            }

            catch (Exception)
            {
                throw;
            }

            return descriptionUpdated;
        }

        /// <summary>
        /// Updates product price based on ProductID.
        /// </summary>
        /// <param name="updateProduct">Represents product price only</param>
        /// <returns>Tells whether the product price is updated</returns>
        public async Task<bool> UpdateProductPriceBL(Product updateProduct)
        {
            bool priceUpdated = false;

            try
            {
                if (await GetProductByProductIDBL(updateProduct.ProductID) != null)
                {
                    this.productDAL.UpdateProductPriceDAL(updateProduct);
                    priceUpdated = true;
                    Serialize();

                }

            }

            catch (Exception)
            {
                throw;
            }

            return priceUpdated;
        }

        /// <summary>
        /// Adds new product to Product collection.
        /// </summary>
        /// <param name="addProduct">Contains the product details of the code to be added</param>
        /// <returns>Tells whether the product is added</returns>
        public async Task<bool> AddProductBL(Product addProduct)
        {
            bool productAdded = false;
            try
            {
                if (await Validate(addProduct))
                {
                    await Task.Run(() =>
                    {
                        this.productDAL.AddProductDAL(addProduct);
                        productAdded = true;
                        Serialize();
                    });
                }
            }
            catch (Exception)
            {
                throw;
            }
            return productAdded;
        }

        public async Task<bool> DeleteProductBL(Guid deleteProductID)
        {
            bool productDeleted = false;

            try
            {
                await Task.Run(() =>
                {
                    productDeleted = productDAL.DeleteProductDAL(deleteProductID);
                    Serialize();
                });
            }

            catch (Exception)
            {
                throw;
            }

            return productDeleted;

        }

        /// <summary>
        /// Invokes Serialize method of DAL.
        /// </summary>
        public static void Serialize()
        {
            try
            {
                ProductDAL.Serialize();
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        ///Invokes Deserialize method of DAL.
        /// </summary>
        public static void Deserialize()
        {
            try
            {
                ProductDAL.Deserialize();
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// Disposes DAL object(s).
        /// </summary>
        public void Dispose()
        {
            ((ProductDAL)productDAL).Dispose();
        }
    }
}
