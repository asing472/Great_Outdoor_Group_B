﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capgemini.GreatOutdoor.Entities
{
    public class Order
    {
        public Guid OrderId { get; set; } //ID of the order
        public Guid RetailerID { get; set; } //ID of the retailer
        public DateTime DateOfOrder { get; set; } //Date of placing order
        public Guid CartProductId { get; set; } //ID of the CartProduct
        public DateTime LastModifiedDateTime { get; set; }//date of order modification
        public double OrderAmount { get; set; }//total cost of the order
        public enum OrderStatus //Gives the status of the order
        {
            Order_Confirmed,
            Order_Dispatched,
            Shipped,
            Delivered
        }
    }
}
