﻿using System;
using System.Collections.Generic;
using Capgemini.GreatOutdoor.Entities;

namespace Capgemini.GreatOutdoor.Contracts.DALContracts
{
    /// <summary>
    /// This abstract class acts as a base for OnlineReturnDAL class
    ///  //Developed By Ayush Agrawal
    //base Interface for OnlineReturnDAL
    /// </summary>
    public abstract class OnlineReturnDALBase
    {
        //Collection of OnlineReturnList
        protected static List<OnlineReturn> onlineReturnList = new List<OnlineReturn>();
        private static string fileName = "OnlineReturns.json";

        //Methods for CRUD operations
        public abstract (bool, Guid) AddOnlineReturnDAL(OnlineReturn newOnlineReturn);
        public abstract List<OnlineReturn> GetAllOnlineReturnsDAL();
        public abstract OnlineReturn GetOnlineReturnByOnlineReturnIDDAL(Guid searchOnlineReturnID);
        public abstract List<OnlineReturn> GetOnlineReturnByRetailerIDDAL(Guid retailerID);
        public abstract List<OnlineReturn> GetOnlineReturnsByPurposeDAL(string purpose);
        public abstract bool UpdateOnlineReturnDAL(OnlineReturn updateOnlineReturn);
        public abstract bool DeleteOnlineReturnDAL(Guid deleteOnlineReturnID);
        
        /// <summary>
        /// Static Constructor.
        /// </summary>
        static OnlineReturnDALBase()
        {

        }
    }
}

