﻿using System;
using System.Collections.Generic;
using Capgemini.GreatOutdoor.Entities;

/// <summary>
/// developed by sravani
/// </summary>
namespace Capgemini.GreatOutdoor.Contracts.DALContracts
{
    /// <summary>
    /// This abstract class acts as a base for AdminDAL class
    /// </summary>
    public abstract class AdminDALBase
    {
        //Methods
        public abstract Admin GetAdminByAdminEmailDAL(string Email);
        public abstract Admin GetAdminByEmailAndPasswordDAL(string email, string password);
        public abstract bool UpdateAdminDAL(Admin updateAdmin);
        public abstract bool UpdateAdminPasswordDAL(Admin updateAdmin);
    }
}


