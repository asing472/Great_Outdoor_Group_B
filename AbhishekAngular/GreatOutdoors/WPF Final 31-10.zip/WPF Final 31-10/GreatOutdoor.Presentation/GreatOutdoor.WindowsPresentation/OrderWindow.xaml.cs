﻿using Capgemini.GreatOutdoor.BusinessLayer;
using Capgemini.GreatOutdoor.Contracts;
using Capgemini.GreatOutdoor.Contracts.BLContracts;
using Capgemini.GreatOutdoor.Entities;
using Capgemini.GreatOutdoor.PresentationLayer;
using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;


namespace GreatOutdoor.WindowsPresentation
{
    //Order Page Developed by C Akhil Chowdary
    /// <summary>
    /// Interaction logic for OrderWindow.xaml
    /// </summary>
    public partial class OrderWindow : Window
    {
        //Order Object
        public static Order order = new Order();
        //retailer object
        public static Retailer retailer = new Retailer();
        //OrderDetails List to store products ordered
        public  List<OrderDetail> orderDetails = new List<OrderDetail>();
        //constructor
        public OrderWindow()
        {

            InitializeComponent();
        }
        //method to give number as a input to quantity textbox
        private void NumericOnly(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !IsValid(((TextBox)sender).Text + e.Text);
        }
        public static bool IsValid(string str)
        {
            int i;
            return (int.TryParse(str, out i) && i >= 1 && i <= 99);
        }
        //Dropdown item change event
        private async void CmbProducts_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            txtTotal.SelectedText = "";
            IProductBL productBL = new ProductBL();
            //getting product details by the id of the selected product
            Guid searchID = Guid.Parse(cmbProducts.SelectedValue.ToString());
            Product product = await productBL.GetProductByProductIDBL(searchID);
            //displaying product's price
            txtPrice.SelectedText = (product.ProductPrice).ToString();
            //txtQuantity.SelectedText = Convert.ToString(0);

        }

        private async void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //getting adrresses of a retailer based on his id
            IAddressBL addressBL = new AddressBL();
            List<Address> addresses = new List<Address>();
            IRetailerBL retailerBL = new RetailerBL();
            retailer = await retailerBL.GetRetailerByEmailBL(CommonData.CurrentUser.Email);
            addresses = await addressBL.GetAddressByRetailerIDBL(retailer.RetailerID);
            // creating an Order by initializing all possible fields using presentation layer
            IOrderBL orderBL = new OrderBL();
            bool isAdded;
            Guid OrderId;
            order.TotalQuantity = 1;
            order.OrderAmount = 1;
            order.RetailerID = retailer.RetailerID;
            (isAdded, OrderId) = await orderBL.AddOrderBL(order);
            //OrderDetail object to store Order Details
            OrderDetail orderDetail = new OrderDetail();
            IProductBL productBL = new ProductBL();
            List<Product> products = new List<Product>();
            //getting all products
            products = await productBL.GetAllProductsBL();
            //assigning all products to product combobox
            cmbProducts.ItemsSource = products;
            cmbProducts.DisplayMemberPath = "ProductName";
            cmbProducts.SelectedValuePath = "ProductID";
            //assigning addresses to adddress combobox
            cmbAddress.ItemsSource = addresses;
            cmbAddress.DisplayMemberPath = "AddressLine1";
            cmbAddress.SelectedValuePath = "AddressID";
        }

        private void BtnAddToCart_Click(object sender, RoutedEventArgs e)
        {
            if (cmbAddress.SelectedIndex == -1)
                MessageBox.Show("Please select address");
            else if (cmbProducts.SelectedIndex == -1)
                MessageBox.Show("Please select a product");
            else if (txtQuantity.Text == "")
                MessageBox.Show("Please Enter Quantity");
            else
            {
                //assigning the possible fields to orderdetail object from presentation layer
                IOrderDetailBL orderDetailBL = new OrderDetailBL();
                OrderDetail orderDetail = new OrderDetail();
                orderDetail.ProductName = cmbProducts.Text;
                orderDetail.ProductID = Guid.Parse((cmbProducts.SelectedValue).ToString());
                orderDetail.ProductPrice = Convert.ToDouble(txtPrice.Text);
                orderDetail.ProductQuantityOrdered = Convert.ToInt32(txtQuantity.Text);
                orderDetail.TotalAmount = Convert.ToDouble(txtTotal.Text);
                orderDetail.AddressId = Guid.Parse(cmbAddress.SelectedValue.ToString());
                orderDetail.OrderId = order.OrderId;
                //adding to database
                orderDetailBL.AddOrderDetailsBL(orderDetail);
                //adding to list
                orderDetails.Add(orderDetail);
                MessageBox.Show("Product Added!!");
                btnGoTocart.IsEnabled = true;
                txtQuantity.SelectedText = "";
                txtPrice.SelectedText = Convert.ToString(0);
                txtQuantity.Text = Convert.ToString(0);
            }
        }

        private void BtnGoTocart_Click(object sender, RoutedEventArgs e)
        {
            //going to cart page
            Hide();
            Window window = new CartWindow();
            window.Show();
        }



        private void TxtQuantity_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (txtQuantity.Text == "")
            {
                MessageBox.Show("Enter a Number in Quantity");
            }

            //giving total amount based on quantity input
            else
                txtTotal.Text = (Convert.ToDouble(txtPrice.Text) * Convert.ToInt32(txtQuantity.Text)).ToString();
        }

        private void CmbAddress_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //dropdown list to display addresses of retailer
            IAddressBL addressBL = new AddressBL();
            Guid searchID = Guid.Parse(cmbAddress.SelectedValue.ToString());
            Address address = new Address();
            address.AddressID = Guid.Parse(cmbAddress.SelectedValue.ToString());
        }

        private void BtnHome_Click(object sender, RoutedEventArgs e)
        {
            Hide();
            Window window = new RetailerWindow();
            window.Show();
        }
    }
}