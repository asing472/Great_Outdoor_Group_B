﻿using Capgemini.GreatOutdoor.BusinessLayer;
using Capgemini.GreatOutdoor.Entities;
using Capgemini.GreatOutdoor.Exceptions;
using Capgemini.GreatOutdoor.PresentationLayer;
using System;
using Capgemini.GreatOutdoor.Contracts.BLContracts;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;

namespace GreatOutdoor.WindowsPresentation
{
    /// <summary>
    /// Interaction logic for Adminmenu.xaml
    /// developed by sravani
    /// </summary>
    public partial class Adminmenu : Window
    {
        public Adminmenu()
        {
            InitializeComponent();
        }

        /// <summary>
        /// viewing sales reports
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void Salesreports_Click(object sender, RoutedEventArgs e)
        {
            ViewSalesReportsBL vr = new ViewSalesReportsBL();
            List<ViewSalesReports> SalesReports = await vr.ViewAllSalesReportsBL();
            DataTable SalesReportstable = new DataTable();
            SalesReportstable = ConvertToDataTable<ViewSalesReports>(SalesReports);
            dgvdata.ItemsSource = SalesReportstable.DefaultView;

        }
        /// <summary>
        /// converts the list of objects into data table format
        /// </summary>
        /// <typeparam name="SalesPerson"></typeparam>
        /// <param name="data"></param>
        /// <returns></returns>
        public DataTable ConvertToDataTable<SalesPerson>(IList<SalesPerson> data)
        {
            PropertyDescriptorCollection properties =
               TypeDescriptor.GetProperties(typeof(SalesPerson));
            DataTable table = new DataTable();
            foreach (PropertyDescriptor prop in properties)
                table.Columns.Add(prop.Name, Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType);
            foreach (SalesPerson item in data)
            {
                DataRow row = table.NewRow();
                foreach (PropertyDescriptor prop in properties)
                    row[prop.Name] = prop.GetValue(item) ?? DBNull.Value;
                table.Rows.Add(row);
            }
            return table;

        }
        /// <summary>
        /// views all salespersons profile
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void Viewsalesprofile_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using (ISalesPersonBL SalesPersonBL = new SalesPersonBL())
                {
                    //Get and display list of system users.
                    List<SalesPerson> SalesPersons = await SalesPersonBL.GetAllSalesPersonsBL();

                    if (SalesPersons != null && SalesPersons?.Count > 0)
                    {
                        DataTable salespersonstable = new DataTable();
                        salespersonstable = ConvertToDataTable<SalesPerson>(SalesPersons);
                        dgvdata.ItemsSource = salespersonstable.DefaultView;

                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
              

            }

        }

        private void dgvdata_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
        /// <summary>
        /// opens admin menu
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Menu_Admin_Click(object sender, RoutedEventArgs e)
        {
            Hide();
            Window window = new Adminmenu();
            window.Show();

        }

        

       

       
        private void ViewAllProducts_Click(object sender, RoutedEventArgs e)
        {
            Hide();
            Window win = new ProductWindow();
            win.Show();

        }

        private void LogOut_Click(object sender, RoutedEventArgs e)
        {
            Hide();
            Window window = new MainWindow();
            window.Show();
        }

        private async void ViewAllRetailers_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using (IRetailerBL RetailerBL = new RetailerBL())
                {
                    //Get and display list of system users.
                    List<Retailer> retailers = await RetailerBL.GetAllRetailersBL();

                    if (retailers != null && retailers?.Count > 0)
                    {
                        DataTable retailerstable = new DataTable();
                        retailerstable = ConvertToDataTable<Retailer>(retailers);
                        dgvdata.ItemsSource = retailerstable.DefaultView;

                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);


            }
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
