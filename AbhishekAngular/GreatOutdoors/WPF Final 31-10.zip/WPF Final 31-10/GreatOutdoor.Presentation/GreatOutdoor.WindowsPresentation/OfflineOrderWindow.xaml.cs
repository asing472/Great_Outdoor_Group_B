﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Capgemini.GreatOutdoor.BusinessLayer;
using Capgemini.GreatOutdoor.Entities;



namespace GreatOutdoor.WindowsPresentation
{
    //Developed By : Abhishek
    //Use case: Upload Offline Orders 
    //Project: GreatOutdoors

    /// <summary>
    /// Interaction logic for OfflineOrder.xaml
    /// </summary>
    public partial class OfflineOrderWindow : Window
    {
        public OfflineOrderWindow()
        {
            InitializeComponent();
        }


        //Creating reference variable of entities and Business Layer
        Guid offlineOrderGuid;
        RetailerBL retailerBL = new RetailerBL();
        ProductBL productBL = new ProductBL();
        List<Retailer> retailers = new List<Retailer>();
        List<Product> products = new List<Product>();
        List<OfflineOrderDetail> offlineOrderDetails = new List<OfflineOrderDetail>();
        Product currentProduct = new Product();
        OfflineOrderDetail currentOfflineOrderDetail = new OfflineOrderDetail();
        OfflineOrder currentOrder = new OfflineOrder();
        OfflineOrderBL offlineOrderBL = new OfflineOrderBL();
        OfflineOrderDetailBL offlineOrderDetailBL = new OfflineOrderDetailBL();

        //Data loaded in window using business layer object
        private async void Window_Loaded(object sender, RoutedEventArgs e)
        {
            var retailers = await retailerBL.GetAllRetailersBL();
            var products = await productBL.GetAllProductsBL();

            //Defining Itemsource for combobox of Retailers and products

            cmbRetailer.ItemsSource = retailers;
            cmdProduct.ItemsSource = products;

            //Display Member path for showing value in Combobox
            //Selected value in combobox will select as ID because selected value path is ID not name

            cmbRetailer.DisplayMemberPath = "RetailerName";
            cmbRetailer.SelectedValuePath = "RetailerID";
            cmdProduct.DisplayMemberPath = "ProductName";
            cmdProduct.SelectedValuePath = "ProductID";

        }

        //Retailer comboBox value function
        private async void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            try
            {  //Add Bl object of offlineOrder 
                OfflineOrderBL offlineOrderBL = new OfflineOrderBL();
                currentOrder.RetailerID = Guid.Parse(cmbRetailer.SelectedValue.ToString());
                currentOrder.SalesPersonID = Guid.Parse("9A38AE9C-4E8C-41E3-872F-5FD823C8E9B9");
                currentOrder.TotalOrderAmount = 100;
                currentOrder.TotalQuantity = 100;
                bool value;
                //Adding Ofline Order by calling add method of OfflineOrderBl 
                (value, offlineOrderGuid) = await offlineOrderBL.AddOfflineOrderBL(currentOrder);
                currentOrder.TotalOrderAmount -= 100;
                currentOrder.TotalQuantity -= 100;
            }
            catch (Exception)
            {

                throw;
            }

        }
        // Event on Product Selection
        private async void CmdProduct_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                currentProduct = await productBL.GetProductByProductIDBL(Guid.Parse(cmdProduct.SelectedValue.ToString()));
                txtUnitPrice.SelectedText = currentProduct.ProductPrice.ToString();
                currentOfflineOrderDetail.UnitPrice = currentProduct.ProductPrice;
                currentOfflineOrderDetail.ProductID = currentProduct.ProductID;
                currentOfflineOrderDetail.ProductName = currentProduct.ProductName;
                txtQuantity.SelectedText = Convert.ToString(1);

            }
            catch (Exception)
            {

                throw;
            }


        }
        //Event on Text quantity used
        private void TxtQuantity_TextChanged(object sender, TextChangedEventArgs e)
        {
            try
            {
                if (txtQuantity.Text == "")
                {
                    MessageBox.Show("Ënter Number");
                }
                else
                {
                    currentOfflineOrderDetail.Quantity = Convert.ToInt32(txtQuantity.Text);
                    txtTotalPrice.SelectedText = (currentOfflineOrderDetail.UnitPrice * currentOfflineOrderDetail.Quantity).ToString();
                    currentOfflineOrderDetail.TotalPrice = Convert.ToDouble(txtTotalPrice.SelectedText);
                }
            }
            catch (Exception)
            {
                throw;
            }
            
        }

        // Event on Add button Click
        private async void btnAddProduct_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (offlineOrderGuid == default(Guid))
                {
                    MessageBox.Show("Please select Retailer");
                }
                else
                {
                    
                    currentOfflineOrderDetail.OfflineOrderID = offlineOrderGuid;
                    await offlineOrderDetailBL.AddOfflineOrderDetailBL(currentOfflineOrderDetail);
                    currentOrder.TotalQuantity += currentOfflineOrderDetail.Quantity;
                    currentOrder.TotalOrderAmount += currentOfflineOrderDetail.TotalPrice;
                    await offlineOrderBL.UpdateOfflineOrderBL(currentOrder);
                    MessageBox.Show("Order Detail Added ");
                    offlineOrderDetails = await offlineOrderDetailBL.GetOfflineOrderDetailByOfflineOrderIDBL(offlineOrderGuid);
                    datagridOrderdetail.ItemsSource = offlineOrderDetails;
                    txtQuantity.Text = "";
                    txtUnitPrice.SelectedText = Convert.ToString(0);
                    txtTotalPrice.SelectedText = Convert.ToString(0);
                    txtTotalOrderAmount.SelectedText = Convert.ToString(currentOrder.TotalOrderAmount);
                    txtTotalQuantity.SelectedText = Convert.ToString(currentOrder.TotalQuantity);
                }


            }
            catch (Exception)
            {

                throw;
            }

        }
        //Event For Numeric Only in Quantity Text
        private void NumericOnly(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !IsValid(((TextBox)sender).Text + e.Text);
        }
        public static bool IsValid(string str)
        {
            int i;
            return (int.TryParse(str, out i) && i >= 1 && i <= 99);
        }

        //Event on Button Next Click
        private void BtnNext_Click(object sender, RoutedEventArgs e)
        {
            orderDetailsTabItem.IsSelected = true;
        }

        private void BtnHome_Click(object sender, RoutedEventArgs e)
        {
            bool new1 = MessageBox.Show("Are you Sure", "GreatOurdoors", MessageBoxButton.YesNo)==MessageBoxResult.Yes;
            if (new1)
            {
                Hide();
                Window window = new SalesPersonWindow();
                window.Show();
            }
        }
          //Event ON on Button Click
        private void BtnLogout_Click(object sender, RoutedEventArgs e)
        {
            bool new1 = MessageBox.Show("Are you Sure", "GreatOurdoors", MessageBoxButton.YesNo) == MessageBoxResult.Yes;
            if (new1)
            {
                Hide();
                Window window = new MainWindow();
                window.Show();
            }
           
        }
    }
}
