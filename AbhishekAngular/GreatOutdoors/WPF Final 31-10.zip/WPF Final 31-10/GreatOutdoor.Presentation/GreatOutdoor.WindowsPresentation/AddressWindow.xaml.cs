﻿using Capgemini.GreatOutdoor.BusinessLayer;
using Capgemini.GreatOutdoor.Entities;
using Capgemini.GreatOutdoor.Exceptions;
using Capgemini.GreatOutdoor.PresentationLayer;
using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;


namespace GreatOutdoor.WindowsPresentation
{
    //Cretaed By Prafull on 25/10/2019
    /// <summary>
    /// Interaction logic for AddressWindow.xaml
    /// </summary>
    public partial class AddressWindow : Window
    {
        private const string MessageBoxText = "Are you sure want to update?";
        List<Address> addresses = new List<Address>();
        Guid AddressID = default(Guid);
        public AddressWindow()
        {
            //Initialize Object
            InitializeComponent();
            loaddata();
        }
        //method to give input to load Data
        private async void loaddata()
        {
            RetailerBL retailerBL = new RetailerBL();
            Retailer retailer = await retailerBL.GetRetailerByEmailBL(CommonData.CurrentUser.Email);
            try
            {
                // Cretating object of business layer      
                using (AddressBL addressBL = new AddressBL())
                {
                    addresses = await addressBL.GetAddressByRetailerIDBL(retailer.RetailerID);
                }
                dgvAddress.ItemsSource = addresses;

            }
            catch (Exception)
            {
                throw;
            }


        }

        //method to give  input to btnADD Click
        private async void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                //Read inputs
                Address address = new Address();
                RetailerBL retailerBL = new RetailerBL();
                Retailer retailer = await retailerBL.GetRetailerByEmailBL(CommonData.CurrentUser.Email);
                address.RetailerID = retailer.RetailerID;
                address.AddressLine1 = txtAddressLine1.Text;
                address.AddressLine2 = txtAddressLine2.Text;
                address.Landmark = txtLandMark.Text;
                address.City = txtCity.Text;
                address.State = txtState.Text;
                address.PinCode = txtPinCode.Text;
                //Invoke AddAddressBL method to add
                using (AddressBL addressBL = new AddressBL())
                {
                    bool isAdded = false;
                    Guid Address = default(Guid);
                    (isAdded, Address) = await addressBL.AddAddressBL(address);
                    if (isAdded)
                    {
                        MessageBox.Show("Address Added");
                    }
                    loaddata();
                }
            }
            catch (Exception ex)
            {
                ExceptionLogger.LogException(ex);
                MessageBox.Show(ex.Message);
            }
        }

        //method to bt update Click
        private async void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                //Read inputs
                Address address = new Address();
                RetailerBL retailerBL = new RetailerBL();
                Retailer retailer = await retailerBL.GetRetailerByEmailBL(CommonData.CurrentUser.Email);
                address.AddressID = AddressID;
                address.RetailerID = retailer.RetailerID;
                address.AddressLine1 = txtAddressLine1.Text;
                address.AddressLine2 = txtAddressLine2.Text;
                address.Landmark = txtLandMark.Text;
                address.City = txtCity.Text;
                address.State = txtState.Text;
                address.PinCode = txtPinCode.Text;
                //Invoke AddAddressBL method to add
                using (AddressBL addressBL = new AddressBL())
                {
                    if (MessageBox.Show("Are you sure want to Update?", "Great Outdoors", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                    {
                        bool isUpdated = false;

                        isUpdated = await addressBL.UpdateAddressBL(address);
                        if (isUpdated)
                        {
                            MessageBox.Show("Address Updated");
                        }

                    }


                }
                loaddata();
            }
            catch (Exception ex)
            {
                ExceptionLogger.LogException(ex);
                MessageBox.Show(ex.Message);
            }
        }
        //method to input to Delete Click
        private async void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (MessageBox.Show("Are you sure want to delete?", "Great Outdoors", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    using (AddressBL addressBL = new AddressBL())
                    {
                        bool isDeleted = false;
                        isDeleted = await addressBL.DeleteAddressBL(AddressID);
                        loaddata();
                        if (isDeleted)
                        {
                            MessageBox.Show("Address Deleted");
                        }
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Address Not Deleted");
            }
        }
        //method to giveto Address Combobox
        private void dgvAddress_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            int rowindex = dgvAddress.SelectedIndex;
            if (rowindex < 0)
            {
                return;
            }
            if (rowindex <= addresses.Count)
            {
                Address address = new Address();
                address = addresses[rowindex];
                AddressID = address.AddressID;
            }

            txtAddressLine1.Text = getCellData(dgvAddress, rowindex, 0);
            txtAddressLine2.Text = getCellData(dgvAddress, rowindex, 1);
            txtLandMark.Text = getCellData(dgvAddress, rowindex, 2);
            txtCity.Text = getCellData(dgvAddress, rowindex, 3);
            txtState.Text = getCellData(dgvAddress, rowindex, 4);
            txtPinCode.Text = getCellData(dgvAddress, rowindex, 5);

        }
        private string getCellData(DataGrid dgv, int rowindex, int cellindex)
        {
            Address address = new Address();
            DataGridRow drow =
                dgv.ItemContainerGenerator.ContainerFromIndex(rowindex) as DataGridRow;
            var cellContent =
                dgv.Columns[cellindex].GetCellContent(drow) as TextBlock;
            return cellContent.Text;
        }

        private void Menu_Address_Click(object sender, RoutedEventArgs e)
        {
            Hide();
            Window window = new AddressWindow();
            window.Show();
        }
        //method to give  input to Online Return Menu
        private void OnlineReturn_Click(object sender, RoutedEventArgs e)
        {
            Hide();
            Window window = new OnlineReturnsWindow();
            window.Show();
        }
        //method to  input to Delete Account Click
        private async void DeleteAccount_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                using (RetailerBL retailerBL = new RetailerBL())
                {
                    Retailer retailer = await retailerBL.GetRetailerByEmailBL(CommonData.CurrentUser.Email);
                    bool isDeleted = false;
                    isDeleted = await retailerBL.DeleteRetailerBL(retailer.RetailerID);
                    if (isDeleted)
                    {
                        MessageBox.Show("Account Deleted");
                        Hide();
                        Window window = new MainWindow();
                        window.Show();
                    }
                }

            }
            catch (Exception)
            {
                throw;
            }
        }

        //method to give  input to Order Click Menu

        private void Order_Click(object sender, RoutedEventArgs e)
        {
            Hide();
            Window window = new OrderWindow();
            window.Show();
        }

        // For Logout Click
        private void menuItemLogout_Click(object sender, RoutedEventArgs e)
        {
            Hide();
            Window window = new MainWindow();
            window.Show();
        }


        //Method for Back Click
        private void Menu_Back_Click(object sender, RoutedEventArgs e)
        {
            Hide();
            Window window = new RetailerWindow();
            window.Show();
        }
    }
}
