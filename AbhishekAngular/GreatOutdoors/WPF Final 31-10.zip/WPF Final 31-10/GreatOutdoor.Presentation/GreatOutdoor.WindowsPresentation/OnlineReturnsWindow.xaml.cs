﻿using Capgemini.GreatOutdoor.BusinessLayer;
using Capgemini.GreatOutdoor.Entities;
using Capgemini.GreatOutdoor.PresentationLayer;
using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;


namespace GreatOutdoor.WindowsPresentation
{
    /// <summary>
    /// Developed by - Ayush Agrawal
    /// Date- 24/10/2019
    /// Interaction logic for OnlineReturnsWindow.xaml
    /// </summary>
    public partial class OnlineReturnsWindow : Window
    {
        public OnlineReturnsWindow()
        {
            InitializeComponent();
            loadData();
        }
        OnlineReturnBL onlineReturnBL = new OnlineReturnBL();
        OnlineReturn onlineReturn1 = new OnlineReturn();
        OrderBL orderBL = new OrderBL();
        OrderDetail orderDetail = new OrderDetail();
        OrderDetailBL orderDetailBL = new OrderDetailBL();
        List<OrderDetail> orderdetails = new List<OrderDetail>();
        //Creating load Data Mthod
        private async void loadData()
        {
            try
            {
                RetailerBL retailerBL = new RetailerBL();
                Retailer retailer = await retailerBL.GetRetailerByEmailBL(CommonData.CurrentUser.Email);
                List<Order> orders = await orderBL.GetOrdersByRetailerIDBL(retailer.RetailerID);


                cmbOrderNumber.ItemsSource = orders;
                cmbOrderNumber.DisplayMemberPath = "OrderNumber";
                cmbOrderNumber.SelectedValuePath = "OrderNumber";
            }
            catch (Exception)
            {

                MessageBox.Show("Error");
            }

        }



        // Creating OrderNumber Selection Changed Method
        private async void OrderNumber_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                int ordernumber = Convert.ToInt32(cmbOrderNumber.SelectedValue);
                onlineReturn1.OrderNumber = ordernumber;
                Order order = await orderBL.GetOrderByOrderNumberBL(ordernumber);
                orderdetails = await orderDetailBL.GetOrderDetailsByOrderIDBL(order.OrderId);
                onlineReturn1.OrderID = order.OrderId;
                onlineReturn1.RetailerID = order.RetailerID;
                onlineReturn1.ProductNumber = 0;
                cmbProductID.ItemsSource = orderdetails;
                cmbProductID.DisplayMemberPath = "ProductName";
                cmbProductID.SelectedValuePath = "ProductID";
               

            }
            catch (Exception)
            {

                MessageBox.Show("Error1");
            }

        }
        //Creating Method for Converting to Data Table





        //Creating Method for ProductName selection Combo box  

        private async void ProductID_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                onlineReturn1.ProductID = new Guid(Convert.ToString(cmbProductID.SelectedValue));

                //creating object of ProductBL
                ProductBL productBL = new ProductBL();
                Product product = await productBL.GetProductByProductIDBL(onlineReturn1.ProductID);
                ProductPrice1.Text = Convert.ToString(product.ProductPrice);
                onlineReturn1.ProductPrice = product.ProductPrice;


            }
            catch (Exception)
            {

                MessageBox.Show("Processed");
            }



        }
        //Creating Method for Purpose selection Combo box  
        private void PurposeOfReturn_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cmbPurposeOfReturn.SelectedIndex >= 0)
            {
                onlineReturn1.Purpose = Convert.ToString((cmbPurposeOfReturn.SelectedItem as ComboBoxItem).Content);
            }
        }


        //Creating Method for Apply For online Return Combo box  

        private async void ApplyForReturn_Click(object sender, RoutedEventArgs e)
        {
            try
            {


                onlineReturn1.TotalAmount = onlineReturn1.QuantityOfReturn * Convert.ToDouble(ProductPrice1.Text);
                bool isAdded = false;
                Guid onlineReturnGuid = default(Guid);
                (isAdded, onlineReturnGuid) = await onlineReturnBL.AddOnlineReturnBL(onlineReturn1);
                if (isAdded)
                {
                    MessageBox.Show("Return Added");
                }
                else
                {
                    MessageBox.Show("Return Failed");
                }
                MessageBox.Show($"Online Return Confirmed  \n ReturnAmount ={onlineReturn1.TotalAmount}");
                View.IsSelected = true;
                List<OnlineReturn> onlineDetails = await onlineReturnBL.GetOnlineReturnByRetailerIDBL(onlineReturn1.RetailerID);
                dgvDetails.ItemsSource = onlineDetails;
                //var quant = txtQuantityOfReturn1.Text;
                //orderDetail.ProductQuantityOrdered = orderDetail.ProductQuantityOrdered - Convert.ToInt32(quant);
                //await orderDetailBL.UpdateOrderDetailsBL(orderDetail);
                //if(orderDetail.ProductQuantityOrdered<=0)
                //{
                //    await orderDetailBL.DeleteOrderDetailsBL(orderDetail.OrderId);
                //}
                txtQuantityOfReturn1.Text = "";
                ProductPrice1.Text = "";
                cmbPurposeOfReturn.SelectedIndex = -1;
                cmbOrderNumber.SelectedIndex = -1;
                cmbProductID.SelectedIndex = -1;




            }
            catch (Exception)
            {

                MessageBox.Show("Error3");
            }


        }

        private void TabControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {


        }


        private void TxtQuantityOfReturn1_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (txtQuantityOfReturn1.Text == "")
            {
                MessageBox.Show("Quantity Of Return is Empty");
            }

            else
            {
                //creating object of order Detail
                OrderDetail orderDetail1 = new OrderDetail();
                orderDetail1 = orderdetails.Find(
                (item) => { return item.ProductID == onlineReturn1.ProductID; });
                onlineReturn1.QuantityOfReturn = Convert.ToInt32(txtQuantityOfReturn1.Text);
                if (onlineReturn1.QuantityOfReturn <= orderDetail1.ProductQuantityOrdered)
                {
                    MessageBox.Show("Ok Entered Quantity is accepted");
                    MessageBox.Show($"Product Quantity Ordered \n { orderDetail1.ProductQuantityOrdered}");

                }
                else
                {
                    MessageBox.Show("Quantity Of Return must be less than or equal to Ordered Quantity");
                }

            }


            // txtReturnAmount.Text = Convert.ToString(Convert.ToInt32(txtQuantityOfReturn1.Text) * onlineReturn1.ProductPrice);
        }


        private async void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            // Empty values
            tabADD.IsSelected = true;
            txtQuantityOfReturn1.Text = "";
            ProductPrice1.Text = "";
            cmbPurposeOfReturn.SelectedIndex = -1;
            cmbOrderNumber.SelectedIndex = -1;
            cmbProductID.SelectedIndex = -1;
        }

        private void DgvDetails_AutoGeneratedColumns(object sender, EventArgs e)
        {

        }
        private void BtnHome_Click(object sender, RoutedEventArgs e)
        {
            bool new1 = MessageBox.Show("Are you Sure", "GreatOurdoors", MessageBoxButton.YesNo) == MessageBoxResult.Yes;
            if (new1)
            {
                Hide();
                Window window = new RetailerWindow();
                window.Show();
            }
        }
    }
}