﻿using Capgemini.GreatOutdoor.BusinessLayer;
using Capgemini.GreatOutdoor.Contracts;
using Capgemini.GreatOutdoor.Contracts.BLContracts;
using Capgemini.GreatOutdoor.Entities;
using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

//Developed By C AKhil Chowdary
//Cart Page
namespace GreatOutdoor.WindowsPresentation
{
    /// <summary>
    /// Interaction logic for CartWindow.xaml
    /// </summary>
    public partial class CartWindow : Window
    {
        //creating required instances and fields for this page
        IAddressBL addressBL = new AddressBL();
        List<Address> addresses = new List<Address>();
        OrderDetail orderDetail = new OrderDetail();
        IOrderDetailBL orderDetailBL = new OrderDetailBL();
        OrderWindow OrderWindow = new OrderWindow();
        List<OrderDetail> orderDetails = new List<OrderDetail>();
        Guid temp;
        int i;

        //constructor
        public CartWindow()
        {
            InitializeComponent();
        }

        //method to give number as a input to quantity textbox
        private void NumericOnly(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !IsValid(((TextBox)sender).Text + e.Text);
        }
        public static bool IsValid(string str)
        {
            int j;
            return (int.TryParse(str, out j) && j >= 1 && j <= 99);
        }

        //Click event for Confirm Cart Button
        private async void BtnConfirmCart_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Confirm Order?", "GreatOutdoors", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                //disabling textboxes and dropdowns
                txtProduct.IsEnabled = false;
                txtCartTotal.IsEnabled = false;
                txtCartTotal.Text = "0";
                txtCartQuantity.IsEnabled = false;
                cmbCartAddress.IsEnabled = false;
                btnUpdate.IsEnabled = false;
                //OrderWindow object to get orderdetails and order object
                OrderWindow OrderWindow = new OrderWindow();
                orderDetails = await orderDetailBL.GetOrderDetailsByOrderIDBL(OrderWindow.order.OrderId);
                Order order = OrderWindow.order;
                double TotalAmount = 0;
                int Quantity = 0;
                //to get the total amount and quantity of order
                foreach (OrderDetail orderDetail in orderDetails)
                {
                    TotalAmount += orderDetail.TotalAmount;
                    Quantity += orderDetail.ProductQuantityOrdered;
                }
                order.TotalQuantity = Quantity;
                order.OrderAmount = TotalAmount;
                //assigning total aquantity and amount to order object
                IOrderBL orderBL = new OrderBL();
                bool isOrdered= await orderBL.UpdateOrderBL(order);
                if (isOrdered)
                {
                    MessageBox.Show($"Order placed! \n Order Amount= {order.OrderAmount} \n Total Quantity= {order.TotalQuantity}");
                    btnConfirmCart.IsEnabled = false;
                    gridOrderDetails.IsEnabled = false;
                }
                
            }
        }

        //displaying items in the grid
        private async void Window_Loaded(object sender, RoutedEventArgs e)
        {
            orderDetails = await orderDetailBL.GetOrderDetailsByOrderIDBL(OrderWindow.order.OrderId);
            gridOrderDetails.ItemsSource = orderDetails;
        }

        //event for clicking Home Button
        private void BtnHome_Click(object sender, RoutedEventArgs e)
        {
            Hide();
            Window window = new RetailerWindow();
            window.Show();
        }

        //Event for Menu button click
        private void BtnGoToMenu_Click(object sender, RoutedEventArgs e)
        {
            Hide();
            Window window = new OrderWindow();
            window.Show();
        }

        //On Update button click
        private async void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            if (cmbCartAddress.SelectedIndex == -1)
                MessageBox.Show("Please enter address");
            else if (txtCartQuantity.Text == "")
                MessageBox.Show("Enter Valid Quantity");

            else if (MessageBox.Show("Are You Sure To Update?", "GreatOutdoors", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                //Getting Product details based on the name of selected product
                ProductBL productBL = new ProductBL();
                List<Product> products = await productBL.GetProductsByProductNameBL(txtProduct.Text.ToString());
                orderDetail.ProductID = products[0].ProductID;
                orderDetail.ProductName = products[0].ProductName;
                orderDetail.ProductPrice = products[0].ProductPrice;

                //Updating Orderdetails
                orderDetail.LastModifiedDateTime = DateTime.Now;
                orderDetail.DateOfOrder = OrderWindow.order.DateOfOrder;
                //Displaying total amount of selected product
                txtCartTotal.Text = (Convert.ToDouble(txtCartUnitPrice.Text) * Convert.ToInt32(txtCartQuantity.Text)).ToString();
                orderDetail.OrderDetailId = temp;
                orderDetail.ProductQuantityOrdered = Convert.ToInt32(txtCartQuantity.Text);
                orderDetail.TotalAmount = Convert.ToDouble(txtCartTotal.Text);
                orderDetail.AddressId = Guid.Parse(cmbCartAddress.SelectedValue.ToString());
                orderDetail.OrderId = OrderWindow.order.OrderId;
                //updating in database
                await orderDetailBL.UpdateOrderDetailsBL(orderDetail);
                orderDetails = await orderDetailBL.GetOrderDetailsByOrderIDBL(OrderWindow.order.OrderId);
                gridOrderDetails.ItemsSource = orderDetails;
            }
        }

        //updating data of selected product
        private string EditCellData(DataGrid dgv, int rowindex, int cellindex)
        {
            DataGridRow drow = dgv.ItemContainerGenerator.ContainerFromIndex(rowindex) as DataGridRow;
            var cellContent = dgv.Columns[cellindex].GetCellContent(drow) as TextBlock;
            return cellContent.Text;
        }

        private async void GridOrderDetails_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            i = gridOrderDetails.SelectedIndex;
            if (i < 0)
            {
                return;
            }
            else
            {
                if (i <= orderDetails.Count - 1)
                {
                    //enabling textboxes and dropdowns
                    txtProduct.IsEnabled = true;
                    txtCartTotal.IsEnabled = true;
                    txtCartTotal.Text = "0";
                    txtCartQuantity.IsEnabled = true;
                    cmbCartAddress.IsEnabled = true;
                    btnUpdate.IsEnabled = true;
                    temp = orderDetails[i].OrderDetailId;
                    //editing details
                    txtProduct.Text = GetCellData(gridOrderDetails, i, 0);
                    txtCartUnitPrice.Text = GetCellData(gridOrderDetails, i, 2);
                    txtCartTotal.Text = GetCellData(gridOrderDetails, i, 3);
                    txtCartQuantity.Text = GetCellData(gridOrderDetails, i, 1);
                    addresses = await addressBL.GetAddressByRetailerIDBL(OrderWindow.retailer.RetailerID);
                    //dropdown list for address
                    cmbCartAddress.ItemsSource = addresses;
                    cmbCartAddress.DisplayMemberPath = "AddressLine1";
                    cmbCartAddress.SelectedValuePath = "AddressID";
                    orderDetails.Remove(orderDetails[i]);
                }
                else
                    MessageBox.Show("Please select valid product");

            }
        }


        private string GetCellData(DataGrid dgv, int rowindex, int cellindex)
        {
            DataGridRow drow = dgv.ItemContainerGenerator.ContainerFromIndex(rowindex) as DataGridRow;
            var cellContent = dgv.Columns[cellindex].GetCellContent(drow) as TextBlock;
            return cellContent.Text;
        }


        //dropdown change event
        private void CmbCartAddress_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            orderDetail.AddressId = Guid.Parse(cmbCartAddress.SelectedValue.ToString());
        }

        //quantity change event
        private void TxtCartQuantity_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (txtCartQuantity.Text == "")
            {
                MessageBox.Show("Enter a Number in Quantity");
            }

            //giving total amount based on quantity input
            else
            {

                txtCartTotal.Text = (Convert.ToDouble(txtCartUnitPrice.Text) * Convert.ToInt32(txtCartQuantity.Text)).ToString();
                orderDetail.ProductQuantityOrdered = Convert.ToInt32(txtCartQuantity.Text);
                orderDetail.TotalAmount = Convert.ToDouble(txtCartTotal.Text);
            }
        }
    }
}